import React, { createContext, useContext, useEffect, useMemo, useState, ReactNode } from "react";
import {
  Booking,
  ExpenseItem,
  TourInstance,
  TourType,
  User,
  ChecklistItem,
  Customer,
  Partner,
  PlanItem,
} from "../types";

import {
  MOCK_BOOKINGS,
  MOCK_EXPENSES,
  MOCK_TOURS,
  MOCK_TOUR_TYPES,
  MOCK_USERS,
  MOCK_CHECKLIST,
  MOCK_CUSTOMERS,
  MOCK_PARTNERS,
  MOCK_PLANS,
} from "./mockData";

import { createDocWithId, deleteDocById, updateDocById } from "./firestoreCrud";
import { collection, getDocs } from "firebase/firestore";
import { db } from "./firebase";

interface AppState {
  currentUser: User | null;
  users: User[];
  tourTypes: TourType[];
  tours: TourInstance[];
  bookings: Booking[];
  expenses: ExpenseItem[];
  checklists: ChecklistItem[];
  customers: Customer[];
  partners: Partner[];
  plans: PlanItem[];
  isAuthenticated: boolean;

  // ✅ chờ load xong dữ liệu (Firestore) trước khi kiểm auth
  bootstrapped: boolean;
}

interface AppContextType extends AppState {
  login: (username: string, pass: string) => boolean;
  logout: () => void;

  addUser: (user: User) => void;
  updateUser: (user: User) => void;
  deleteUser: (id: string) => void;

  addTour: (tour: TourInstance) => void;
  updateTour: (tour: TourInstance) => void;
  deleteTour: (id: string) => void;

  addBooking: (booking: Booking) => void;
  updateBooking: (booking: Booking) => void;
  deleteBooking: (id: string) => void;

  addExpense: (expense: ExpenseItem) => void;
  deleteExpense: (id: string) => void;

  addChecklistItem: (item: ChecklistItem) => void;
  updateChecklistItem: (item: ChecklistItem) => void;
  deleteChecklistItem: (id: string) => void;

  addPartner: (partner: Partner) => void;
  deletePartner: (id: string) => void;

  addPlan: (plan: PlanItem) => void;
  deletePlan: (id: string) => void;

  updateCustomer: (customer: Customer) => void;
  deleteCustomer: (id: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // ===== Firestore workspace =====
  const workspaceId = "uptrail";

  // ===== Auth session (localStorage) =====
  const AUTH_KEY = "uptrail_ops_auth_v1";

  const readSavedUserId = () => {
    try {
      const raw = localStorage.getItem(AUTH_KEY);
      if (!raw) return null;
      const parsed = JSON.parse(raw) as { userId?: string };
      return parsed?.userId || null;
    } catch {
      return null;
    }
  };

  const saveUserId = (userId: string) => {
    try {
      localStorage.setItem(AUTH_KEY, JSON.stringify({ userId }));
    } catch {
      // ignore
    }
  };

  const clearSavedUserId = () => {
    try {
      localStorage.removeItem(AUTH_KEY);
    } catch {
      // ignore
    }
  };

  // ===== Auth state =====
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [bootstrapped, setBootstrapped] = useState(false);

  // ===== Data state (fallback MOCK) =====
  const [users, setUsers] = useState<User[]>(MOCK_USERS);
  const [tourTypes] = useState<TourType[]>(MOCK_TOUR_TYPES);
  const [tours, setTours] = useState<TourInstance[]>(MOCK_TOURS);
  const [bookings, setBookings] = useState<Booking[]>(MOCK_BOOKINGS);
  const [expenses, setExpenses] = useState<ExpenseItem[]>(MOCK_EXPENSES);
  const [checklists, setChecklists] = useState<ChecklistItem[]>(MOCK_CHECKLIST);
  const [customers, setCustomers] = useState<Customer[]>(MOCK_CUSTOMERS);
  const [partners, setPartners] = useState<Partner[]>(MOCK_PARTNERS);
  const [plans, setPlans] = useState<PlanItem[]>(MOCK_PLANS);

  // ===== Helpers =====
  const mergeUsersKeepMockAdmin = (fsUsers: User[] | null) => {
    // ✅ Luôn giữ MOCK_USERS (đặc biệt admin) dù Firestore có users
    // Ưu tiên dữ liệu Firestore theo id trùng (Firestore override), còn không thì thêm MOCK
    const map = new Map<string, User>();
    (fsUsers ?? []).forEach((u) => map.set(u.id, u));
    MOCK_USERS.forEach((u) => {
      if (!map.has(u.id)) map.set(u.id, u);
    });
    return Array.from(map.values());
  };

  const readCollection = async <T,>(entity: string): Promise<T[] | null> => {
    try {
      const colRef = collection(db, "workspaces", workspaceId, entity);
      const snap = await getDocs(colRef);
      if (snap.empty) return null;
      return snap.docs.map((d) => d.data() as T);
    } catch (err) {
      console.error(`[Firestore] read ${entity} failed`, err);
      return null;
    }
  };

  // ===== Bootstrap: load Firestore + restore login =====
  useEffect(() => {
    let mounted = true;

    (async () => {
      const savedUserId = readSavedUserId();

      const [
        fsUsersRaw,
        fsTours,
        fsBookings,
        fsExpenses,
        fsChecklists,
        fsCustomers,
        fsPartners,
        fsPlans,
      ] = await Promise.all([
        readCollection<User>("users"),
        readCollection<TourInstance>("tours"),
        readCollection<Booking>("bookings"),
        readCollection<ExpenseItem>("expenses"),
        readCollection<ChecklistItem>("checklists"),
        readCollection<Customer>("customers"),
        readCollection<Partner>("partners"),
        readCollection<PlanItem>("plans"),
      ]);

      if (!mounted) return;

      // ✅ Merge users: Firestore + MOCK (giữ admin)
      const mergedUsers = mergeUsersKeepMockAdmin(fsUsersRaw);
      setUsers(mergedUsers);

      if (fsTours) setTours(fsTours);
      if (fsBookings) setBookings(fsBookings);
      if (fsExpenses) setExpenses(fsExpenses);
      if (fsChecklists) setChecklists(fsChecklists);
      if (fsCustomers) setCustomers(fsCustomers);
      if (fsPartners) setPartners(fsPartners);
      if (fsPlans) setPlans(fsPlans);

      // ✅ Restore session after users ready
      if (savedUserId) {
        const found = mergedUsers.find((u) => u.id === savedUserId);
        if (found) {
          setCurrentUser(found);
          setIsAuthenticated(true);
        } else {
          clearSavedUserId();
          setCurrentUser(null);
          setIsAuthenticated(false);
        }
      }

      setBootstrapped(true);
    })();

    return () => {
      mounted = false;
    };
  }, []);

  // ===== Firestore upsert helpers =====
  const upsertFS = <T extends object>(entity: string, id: string, data: T) => {
    createDocWithId(workspaceId, entity, id, data).catch(console.error);
  };
  const updateFS = <T extends object>(entity: string, id: string, data: Partial<T>) => {
    updateDocById<T>(workspaceId, entity, id, data as T).catch(console.error);
  };
  const deleteFS = (entity: string, id: string) => {
    deleteDocById(workspaceId, entity, id).catch(console.error);
  };

  // ===== Auth actions =====
  const login = (username: string, pass: string) => {
    const u = (username ?? "").trim();
    const p = (pass ?? "").trim();

    const user = users.find((x) => (x.username ?? "").trim() === u && (x.password ?? "").trim() === p);
    if (user) {
      setCurrentUser(user);
      setIsAuthenticated(true);
      saveUserId(user.id); // ✅ keep login after refresh
      return true;
    }
    return false;
  };

  const logout = () => {
    setCurrentUser(null);
    setIsAuthenticated(false);
    clearSavedUserId();
  };

  // ===== Business helpers =====
  const syncCustomerFromBooking = (booking: Booking, allCustomers: Customer[]) => {
    const existing = allCustomers.find((c) => c.phone === booking.phone);

    if (existing) {
      return allCustomers.map((c) =>
        c.phone === booking.phone
          ? {
              ...c,
              name: booking.customerName,
              cccd: booking.cccd || c.cccd,
              birthDate: booking.birthDate || c.birthDate,
              hometown: booking.hometown || c.hometown,
            }
          : c
      );
    }

    const newCustomer: Customer = {
      id: booking.phone,
      name: booking.customerName,
      phone: booking.phone,
      cccd: booking.cccd,
      birthDate: booking.birthDate,
      hometown: booking.hometown,
      notes: booking.note,
    };

    return [...allCustomers, newCustomer];
  };

  // ===== User actions =====
  const addUser = (user: User) => {
    setUsers((prev) => [...prev, user]);
    upsertFS("users", user.id, user);
  };

  const updateUser = (updatedUser: User) => {
    setUsers((prev) => prev.map((u) => (u.id === updatedUser.id ? updatedUser : u)));
    if (currentUser?.id === updatedUser.id) setCurrentUser(updatedUser);
    upsertFS("users", updatedUser.id, updatedUser);
  };

  const deleteUser = (id: string) => {
    setUsers((prev) => prev.filter((u) => u.id !== id));
    deleteFS("users", id);
    if (currentUser?.id === id) logout();
  };

  // ===== Tour actions =====
  const addTour = (tour: TourInstance) => {
    setTours((prev) => [tour, ...prev]);
    upsertFS("tours", tour.id, tour);
  };

  const updateTour = (updatedTour: TourInstance) => {
    setTours((prev) => prev.map((t) => (t.id === updatedTour.id ? updatedTour : t)));
    upsertFS("tours", updatedTour.id, updatedTour);
  };

  const deleteTour = (id: string) => {
    setTours((prev) => prev.filter((t) => t.id !== id));
    deleteFS("tours", id);
  };

  // ===== Booking actions =====
  const addBooking = (booking: Booking) => {
    setBookings((prev) => [booking, ...prev]);
    upsertFS("bookings", booking.id, booking);

    setCustomers((prevCustomers) => {
      const nextCustomers = syncCustomerFromBooking(booking, prevCustomers);
      const customerId = booking.phone;
      const customer = nextCustomers.find((c) => c.phone === customerId);
      if (customer) upsertFS("customers", customerId, customer);
      return nextCustomers;
    });
  };

  const updateBooking = (updatedBooking: Booking) => {
    setBookings((prev) => prev.map((b) => (b.id === updatedBooking.id ? updatedBooking : b)));
    upsertFS("bookings", updatedBooking.id, updatedBooking);

    setCustomers((prevCustomers) => {
      const nextCustomers = syncCustomerFromBooking(updatedBooking, prevCustomers);
      const customerId = updatedBooking.phone;
      const customer = nextCustomers.find((c) => c.phone === customerId);
      if (customer) upsertFS("customers", customerId, customer);
      return nextCustomers;
    });
  };

  const deleteBooking = (id: string) => {
    setBookings((prev) => prev.filter((b) => b.id !== id));
    deleteFS("bookings", id);
  };

  // ===== Expense actions =====
  const addExpense = (expense: ExpenseItem) => {
    setExpenses((prev) => [expense, ...prev]);
    upsertFS("expenses", expense.id, expense);
  };

  const deleteExpense = (id: string) => {
    setExpenses((prev) => prev.filter((e) => e.id !== id));
    deleteFS("expenses", id);
  };

  // ===== Checklist actions =====
  const addChecklistItem = (item: ChecklistItem) => {
    setChecklists((prev) => [...prev, item]);
    upsertFS("checklists", item.id, item);
  };

  const updateChecklistItem = (updatedItem: ChecklistItem) => {
    setChecklists((prev) => prev.map((c) => (c.id === updatedItem.id ? updatedItem : c)));
    upsertFS("checklists", updatedItem.id, updatedItem);
  };

  const deleteChecklistItem = (id: string) => {
    setChecklists((prev) => prev.filter((c) => c.id !== id));
    deleteFS("checklists", id);
  };

  // ===== Partner actions =====
  const addPartner = (partner: Partner) => {
    setPartners((prev) => [...prev, partner]);
    upsertFS("partners", partner.id, partner);
  };

  const deletePartner = (id: string) => {
    setPartners((prev) => prev.filter((p) => p.id !== id));
    deleteFS("partners", id);
  };

  // ===== Plan actions =====
  const addPlan = (plan: PlanItem) => {
    setPlans((prev) => [...prev, plan]);
    upsertFS("plans", plan.id, plan);
  };

  const deletePlan = (id: string) => {
    setPlans((prev) => prev.filter((p) => p.id !== id));
    deleteFS("plans", id);
  };

  // ===== Customer actions =====
  const updateCustomer = (updatedCustomer: Customer) => {
    setCustomers((prev) => prev.map((c) => (c.id === updatedCustomer.id ? updatedCustomer : c)));
    upsertFS("customers", updatedCustomer.phone || updatedCustomer.id, updatedCustomer);
  };

  const deleteCustomer = (id: string) => {
    setCustomers((prev) => prev.filter((c) => c.id !== id));
    deleteFS("customers", id);
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        users,
        tourTypes,
        tours,
        bookings,
        expenses,
        checklists,
        customers,
        partners,
        plans,
        isAuthenticated,
        bootstrapped,
        login,
        logout,
        addUser,
        updateUser,
        deleteUser,
        addTour,
        updateTour,
        deleteTour,
        addBooking,
        updateBooking,
        deleteBooking,
        addExpense,
        deleteExpense,
        addChecklistItem,
        updateChecklistItem,
        deleteChecklistItem,
        addPartner,
        deletePartner,
        addPlan,
        deletePlan,
        updateCustomer,
        deleteCustomer,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useAppStore = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error("useAppStore must be used within an AppProvider");
  return context;
};
