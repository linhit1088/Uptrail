import { doc, getDoc, setDoc, serverTimestamp } from "firebase/firestore";
import { db } from "./firebase";

const REF = doc(db, "app_data", "main");

// Load dữ liệu khi mở web
export async function loadAppData<T>(fallback: T): Promise<T> {
  const snap = await getDoc(REF);
  if (!snap.exists()) return fallback;
  return snap.data().data as T;
}

// Save dữ liệu (ghi đè)
export async function saveAppData<T>(data: T): Promise<void> {
  await setDoc(
    REF,
    { data, updatedAt: serverTimestamp() },
    { merge: true }
  );
}
