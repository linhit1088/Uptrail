import {
  collection,
  doc,
  getDocs,
  addDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  serverTimestamp,
  query,
  orderBy,
} from "firebase/firestore";
import { db } from "./firebase";

/**
 * Cấu trúc lưu data:
 * workspaces/{workspaceId}/{entity}/{docId}
 * Ví dụ: workspaces/uptrail/bookings/abc123
 */
export function colRef(workspaceId: string, entity: string) {
  return collection(db, "workspaces", workspaceId, entity);
}

export async function listDocs<T>(workspaceId: string, entity: string) {
  // Nếu chưa có createdAt thì vẫn chạy được, nhưng orderBy có thể báo lỗi.
  // Mình vẫn để orderBy để data mới lên trước.
  const q = query(colRef(workspaceId, entity), orderBy("createdAt", "desc"));
  const snap = await getDocs(q);
  return snap.docs.map((d) => ({ id: d.id, ...(d.data() as T) }));
}

export async function createDoc<T extends object>(
  workspaceId: string,
  entity: string,
  data: T
) {
  const ref = await addDoc(colRef(workspaceId, entity), {
    ...data,
    createdAt: serverTimestamp(),
  });
  return ref.id;
}

export async function createDocWithId<T extends object>(
  workspaceId: string,
  entity: string,
  id: string,
  data: T
) {
  await setDoc(doc(db, "workspaces", workspaceId, entity, id), {
    ...data,
    createdAt: serverTimestamp(),
  });
}

export async function deleteDocById(
  workspaceId: string,
  entity: string,
  id: string
) {
  await deleteDoc(doc(db, "workspaces", workspaceId, entity, id));
}
export async function updateDocById<T extends object>(
  workspaceId: string,
  entity: string,
  id: string,
  data: Partial<T>
) {
  await updateDoc(doc(db, "workspaces", workspaceId, entity, id), {
    ...data,
    updatedAt: serverTimestamp(),
  });
}
