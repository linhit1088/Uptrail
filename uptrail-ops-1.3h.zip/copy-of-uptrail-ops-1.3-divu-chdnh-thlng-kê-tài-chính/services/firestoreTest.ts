import { createDoc, listDocs } from "./firestoreCrud";

const workspaceId = "uptrail";

export async function testFirestore() {
  const id = await createDoc(workspaceId, "test", {
    hello: "world",
    time: Date.now(),
  });

  const all = await listDocs<any>(workspaceId, "test");
  console.log("✅ Firestore OK. New id:", id);
  console.log("✅ Current docs:", all);
}