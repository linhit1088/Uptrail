import { db } from "./firebase";
import { collection, getDocs, query, orderBy } from "firebase/firestore";

export async function listDocs<T = any>(workspaceId: string, entity: string) {
  const colRef = collection(db, "workspaces", workspaceId, entity);
  // Nếu entity không có createdAt thì bỏ orderBy
  const q = query(colRef);
  const snap = await getDocs(q);
  return snap.docs.map(d => ({ id: d.id, ...d.data() } as T));
}
