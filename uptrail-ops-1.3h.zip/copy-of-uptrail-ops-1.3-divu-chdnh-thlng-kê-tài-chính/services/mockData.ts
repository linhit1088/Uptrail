
import { TourInstance, TourStatus, User, UserRole, TourType, Booking, ExpenseItem, ChecklistItem, Customer, Partner, PlanItem, PERMISSION_GROUPS } from '../types';

// Helper to get all permissions
const ALL_PERMISSIONS = PERMISSION_GROUPS.flatMap(g => g.items.map(i => i.code));

export const MOCK_USERS: User[] = [
  { 
    id: 'u1', 
    name: 'Nguyễn Văn Admin', 
    username: 'admin', 
    password: '123', 
    roles: [UserRole.ADMIN, UserRole.SALE, UserRole.LEADER, UserRole.ACCOUNTANT],
    permissions: ALL_PERMISSIONS // Admin full quyền
  },
  { 
    id: 'u2', 
    name: 'Trần Thị Sale', 
    username: 'sale', 
    password: '123', 
    roles: [UserRole.SALE],
    permissions: ['tour.view', 'booking.view', 'booking.add', 'booking.edit', 'customer.view', 'customer.edit'] 
  },
  { 
    id: 'u3', 
    name: 'Lê Văn Ops', 
    username: 'ops', 
    password: '123', 
    roles: [UserRole.OPS, UserRole.LEADER],
    permissions: ['tour.view', 'tour.edit', 'booking.view', 'finance.view_detail', 'finance.add_expense'] 
  },
  { 
    id: 'u4', 
    name: 'Hoàng Leader', 
    username: 'leader', 
    password: '123', 
    roles: [UserRole.LEADER],
    permissions: ['tour.view', 'booking.view'] 
  },
  { 
    id: 'u5', 
    name: 'Phạm Sale 2', 
    username: 'sale2', 
    password: '123', 
    roles: [UserRole.SALE, UserRole.ACCOUNTANT],
    permissions: ['tour.view', 'booking.view', 'booking.add', 'finance.view_overview', 'finance.export'] 
  },
  { 
    id: 'u6', 
    name: 'Kế Toán Trưởng', 
    username: 'ketoan', 
    password: '123', 
    roles: [UserRole.ACCOUNTANT],
    permissions: ['finance.view_overview', 'finance.view_detail', 'finance.export', 'tour.view', 'booking.view'] 
  },
];

export const MOCK_CUSTOMERS: Customer[] = [
  { id: 'c1', name: 'Nguyễn Văn Khách', phone: '0901234567', cccd: '001234567890', birthDate: '1995-05-15', hometown: 'Hà Nội', notes: 'Khách VIP, hay bo', totalSpent: 3500000 },
  { id: 'c2', name: 'Trần Thị B', phone: '0909876543', cccd: '001987654321', birthDate: '1998-10-20', hometown: 'Hải Phòng', notes: 'Hơi khó tính chuyện ăn uống' },
  { id: 'c3', name: 'Lê Văn C', phone: '0912345678', birthDate: '1990-01-01', notes: 'Khách quen giảm giá' },
  { id: 'c4', name: 'Hoàng D', phone: '0987654321', birthDate: '2000-12-12' }
];

export const MOCK_TOUR_TYPES: TourType[] = [
  { id: 'tt1', name: 'Kỳ Quan San', duration: '2N1Đ' },
  { id: 'tt2', name: 'Lảo Thẩn', duration: '2N1Đ' },
  { id: 'tt3', name: 'Nhìu Cồ San', duration: '2N1Đ' },
  { id: 'tt4', name: 'Tà Chì Nhù', duration: '2N1Đ' },
];

export const MOCK_TOURS: TourInstance[] = [
  {
    id: 't1',
    tourTypeId: 'tt1',
    code: 'KQS-0501',
    name: 'Kỳ Quan San Săn Mây',
    startDate: '2024-05-01',
    leaderId: 'u4',
    status: TourStatus.OPEN,
    isHidden: false,
    visibility: 'public',
    allowedUserIds: []
  },
  {
    id: 't2',
    tourTypeId: 'tt2',
    code: 'LT-0501',
    name: 'Lảo Thẩn Đại Chiến',
    startDate: '2024-05-01',
    leaderId: 'u4',
    status: TourStatus.LOCKED,
    isHidden: false,
    visibility: 'public',
    allowedUserIds: []
  },
  {
    id: 't3',
    tourTypeId: 'tt3',
    code: 'NCS-0602',
    name: 'Nhìu Cồ San Mùa Hoa',
    startDate: '2024-06-02',
    leaderId: undefined,
    status: TourStatus.OPEN,
    isHidden: false,
    visibility: 'public',
    allowedUserIds: []
  },
];

export const MOCK_BOOKINGS: Booking[] = [
  {
    id: 'b1',
    tourInstanceId: 't1',
    customerName: 'Nguyễn Văn Khách',
    nickname: 'Iron Man',
    gender: 'Nam',
    birthDate: '1995-05-15',
    phone: '0901234567',
    cccd: '001234567890',
    hometown: 'Hà Nội',
    pickupPoint: 'Ngã Tư Sở',
    saleId: 'u2',
    price: 3500000,
    deposit: 1000000,
    groupName: 'Nhóm A',
    note: 'Ăn chay'
  },
  {
    id: 'b2',
    tourInstanceId: 't1',
    customerName: 'Trần Thị B',
    nickname: 'Wonder Woman',
    gender: 'Nữ',
    birthDate: '1998-10-20',
    phone: '0909876543',
    cccd: '001987654321',
    hometown: 'Hải Phòng',
    pickupPoint: 'Đại học QG',
    saleId: 'u2',
    price: 3500000,
    deposit: 3500000,
    groupName: 'Nhóm A',
  },
  {
    id: 'b3',
    tourInstanceId: 't1',
    customerName: 'Lê Văn C',
    gender: 'Nam',
    birthDate: '1990-01-01',
    phone: '0912345678',
    saleId: 'u5',
    price: 3200000,
    deposit: 500000,
    note: 'Khách quen giảm giá'
  },
  {
    id: 'b4',
    tourInstanceId: 't2',
    customerName: 'Hoàng D',
    gender: 'Nam',
    birthDate: '2000-12-12',
    phone: '0987654321',
    saleId: 'u2',
    price: 2800000,
    deposit: 2800000,
  }
];

export const MOCK_EXPENSES: ExpenseItem[] = [
  {
    id: 'e1',
    tourInstanceId: 't1',
    category: 'Di chuyển',
    name: 'Xe giường nằm Hà Nội - Sapa',
    quantity: 1,
    unitPrice: 5000000,
    type: 'CHI',
    paymentMethod: 'Chuyển khoản'
  },
  {
    id: 'e2',
    tourInstanceId: 't1',
    category: 'Ăn uống',
    name: 'Ăn tối ngày 1',
    quantity: 15,
    unitPrice: 150000,
    type: 'CHI',
    paymentMethod: 'Tiền mặt'
  }
];

export const MOCK_CHECKLIST: ChecklistItem[] = [
  { id: 'c1', tourInstanceId: 't1', name: 'Đèn chiếu sáng', quantity: 1, isPrepared: true, isReturned: false },
  { id: 'c2', tourInstanceId: 't1', name: 'Đèn pin đội đầu', quantity: 15, isPrepared: true, isReturned: true },
  { id: 'c3', tourInstanceId: 't1', name: 'Bộ đàm', quantity: 3, isPrepared: false, isReturned: false },
  { id: 'c4', tourInstanceId: 't1', name: 'Bếp gas', quantity: 3, isPrepared: true, isReturned: false },
];

export const MOCK_PARTNERS: Partner[] = [
  { id: 'p1', tourInstanceId: 't1', category: 'Nhà Xe', name: 'Xe Sao Việt', phone: '0987654321', note: 'Đón 22:00 tại 789 Giải Phóng' },
  { id: 'p2', tourInstanceId: 't1', category: 'Nhà Nghỉ/Homestay', name: 'A Phủ Homestay', phone: '0912345678', note: 'Đã cọc 500k' },
  { id: 'p3', tourInstanceId: 't1', category: 'Porter', name: 'A Chư', phone: '0968686868', note: 'Trưởng nhóm porter' },
];

export const MOCK_PLANS: PlanItem[] = [
  { id: 'pl1', tourInstanceId: 't1', day: 1, time: '05:00', content: 'Có mặt tại Sapa, vệ sinh cá nhân', note: 'Nhắc khách mang đủ nước' },
  { id: 'pl2', tourInstanceId: 't1', day: 1, time: '07:00', content: 'Ăn sáng phở cốn sủi', note: '' },
  { id: 'pl3', tourInstanceId: 't1', day: 1, time: '08:00', content: 'Di chuyển vào điểm trek', note: 'Xe 16 chỗ đón tại bến xe' },
  { id: 'pl4', tourInstanceId: 't1', day: 2, time: '04:00', content: 'Dậy ăn sáng, check-in đỉnh', note: 'Mang đèn pin' },
];