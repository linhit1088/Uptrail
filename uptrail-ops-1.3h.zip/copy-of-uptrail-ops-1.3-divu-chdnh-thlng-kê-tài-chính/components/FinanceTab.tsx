import React, { useState } from 'react';
import { Plus, Trash2, ArrowUpCircle, ArrowDownCircle, Download } from 'lucide-react';
import { useAppStore } from '../services/store';
import { ExpenseItem, formatCurrency } from '../types';

interface FinanceTabProps {
  tourId: string;
}

export const FinanceTab: React.FC<FinanceTabProps> = ({ tourId }) => {
  const { expenses, bookings, addExpense, deleteExpense, tours } = useAppStore();
  
  // Calculate Revenue from Bookings automatically
  const tourBookings = bookings.filter(b => b.tourInstanceId === tourId);
  const totalRevenue = tourBookings.reduce((sum, b) => sum + b.price, 0);

  // Calculate Expenses
  const tourExpenses = expenses.filter(e => e.tourInstanceId === tourId && e.type === 'CHI');
  const totalCost = tourExpenses.reduce((sum, e) => sum + (e.quantity * e.unitPrice), 0);
  
  const profit = totalRevenue - totalCost;
  const currentTour = tours.find(t => t.id === tourId);

  // Form State
  const [newExpense, setNewExpense] = useState<Partial<ExpenseItem>>({
    type: 'CHI',
    category: 'Ăn uống',
    quantity: 1,
    unitPrice: 0,
    paymentMethod: 'Tiền mặt'
  });

  const handleAddExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if(!newExpense.name) return;

    addExpense({
      ...newExpense,
      id: Math.random().toString(36).substr(2, 9),
      tourInstanceId: tourId,
    } as ExpenseItem);

    setNewExpense({
        type: 'CHI',
        category: 'Ăn uống',
        quantity: 1,
        unitPrice: 0,
        name: '',
        note: '',
        paymentMethod: 'Tiền mặt'
    });
  };

  const handleExportFinanceReport = () => {
    // 1. Prepare Summary Data
    const summaryRows = [
        ["BAO CAO TAI CHINH TOUR"],
        [`Tour: ${currentTour?.name || ''}`],
        [`Ma Tour: ${currentTour?.code || ''}`],
        [],
        ["TONG QUAN"],
        ["Tong doanh thu", totalRevenue],
        ["Tong chi phi", totalCost],
        ["Loi nhuan", profit],
        []
    ];

    // 2. Prepare Revenue Detail Rows
    const revenueHeaders = ["CHI TIET THU (BOOKING)", "", "", ""];
    const revenueColHeaders = ["Khach hang", "SĐT", "Gia Tour", "Ghi chu"];
    const revenueRows = tourBookings.map(b => [
        `"${b.customerName}"`,
        `"${b.phone}"`,
        b.price,
        `"${b.note || ''}"`
    ]);

    // 3. Prepare Expense Detail Rows
    const expenseHeaders = ["CHI TIET CHI PHI", "", "", "", "", ""];
    const expenseColHeaders = ["Phan loai", "Khoan muc", "So luong", "Don gia", "Thanh tien", "Hinh thuc"];
    const expenseRows = tourExpenses.map(e => [
        `"${e.category}"`,
        `"${e.name}"`,
        e.quantity,
        e.unitPrice,
        e.quantity * e.unitPrice,
        `"${e.paymentMethod}"`
    ]);

    // Combine all
    const allRows = [
        ...summaryRows,
        revenueHeaders,
        revenueColHeaders,
        ...revenueRows,
        [],
        expenseHeaders,
        expenseColHeaders,
        ...expenseRows
    ];

    const csvContent = "\uFEFF" + allRows.map(e => e.join(",")).join("\n");
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `Tai_Chinh_${currentTour?.code || 'Tour'}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
          <h3 className="font-bold text-gray-800 text-lg">Quản lý Thu/Chi</h3>
          <button 
            onClick={handleExportFinanceReport}
            className="flex items-center space-x-2 bg-gray-100 hover:bg-gray-200 text-gray-700 px-3 py-2 rounded-lg text-sm font-medium transition-colors"
          >
              <Download size={16} />
              <span>Xuất Báo cáo</span>
          </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-green-50 p-5 rounded-xl border border-green-100">
          <div className="text-green-600 font-semibold mb-1 flex items-center">
            <ArrowUpCircle size={18} className="mr-2" /> Tổng Thu (Booking)
          </div>
          <div className="text-2xl font-bold text-green-700">{formatCurrency(totalRevenue)}</div>
          <div className="text-xs text-green-500 mt-1">Tự động tổng hợp từ {tourBookings.length} khách</div>
        </div>

        <div className="bg-red-50 p-5 rounded-xl border border-red-100">
          <div className="text-red-600 font-semibold mb-1 flex items-center">
             <ArrowDownCircle size={18} className="mr-2" /> Tổng Chi
          </div>
          <div className="text-2xl font-bold text-red-700">{formatCurrency(totalCost)}</div>
          <div className="text-xs text-red-500 mt-1">{tourExpenses.length} khoản chi</div>
        </div>

        <div className="bg-blue-50 p-5 rounded-xl border border-blue-100">
          <div className="text-blue-600 font-semibold mb-1">Lợi nhuận ước tính</div>
          <div className="text-2xl font-bold text-blue-700">{formatCurrency(profit)}</div>
          <div className="text-xs text-blue-500 mt-1">Margin: {totalRevenue ? Math.round((profit/totalRevenue)*100) : 0}%</div>
        </div>
      </div>

      {/* Expense Input Form */}
      <div className="bg-gray-50 p-4 rounded-lg border border-gray-200 mb-8">
        <h4 className="font-bold text-gray-700 mb-3">Nhập chi phí mới</h4>
        <form onSubmit={handleAddExpense} className="grid grid-cols-1 md:grid-cols-6 gap-3 items-end">
          <div className="md:col-span-1">
            <label className="block text-xs text-gray-500 mb-1">Loại</label>
            <select 
                className="w-full border rounded p-2 text-sm"
                value={newExpense.category}
                onChange={e => setNewExpense({...newExpense, category: e.target.value as any})}
            >
                <option value="Ăn uống">Ăn uống</option>
                <option value="Di chuyển">Di chuyển</option>
                <option value="Local">Local/Porter</option>
                <option value="Vé/Ngủ">Vé/Ngủ</option>
                <option value="Khác">Khác</option>
            </select>
          </div>
          <div className="md:col-span-2">
            <label className="block text-xs text-gray-500 mb-1">Khoản mục</label>
            <input 
                type="text" 
                placeholder="VD: Ăn tối nhà hàng A..."
                className="w-full border rounded p-2 text-sm"
                required
                value={newExpense.name || ''}
                onChange={e => setNewExpense({...newExpense, name: e.target.value})}
            />
          </div>
          <div className="md:col-span-1">
             <label className="block text-xs text-gray-500 mb-1">Số lượng</label>
             <input 
                type="number" 
                className="w-full border rounded p-2 text-sm"
                min="1"
                value={newExpense.quantity}
                onChange={e => setNewExpense({...newExpense, quantity: parseInt(e.target.value)})}
             />
          </div>
          <div className="md:col-span-1">
             <label className="block text-xs text-gray-500 mb-1">Đơn giá</label>
             <input 
                type="number" 
                className="w-full border rounded p-2 text-sm"
                value={newExpense.unitPrice}
                onChange={e => setNewExpense({...newExpense, unitPrice: parseInt(e.target.value)})}
             />
          </div>
          <div className="md:col-span-1">
             <button type="submit" className="w-full bg-teal-600 text-white p-2 rounded hover:bg-teal-700 text-sm font-medium transition-colors">
                + Thêm
             </button>
          </div>
        </form>
      </div>

      {/* Expense List */}
      <div>
        <h4 className="font-bold text-gray-700 mb-3">Bảng kê chi tiết</h4>
        <div className="overflow-x-auto border border-gray-200 rounded-lg">
          <table className="w-full text-sm text-left">
             <thead className="bg-gray-100 text-gray-600 font-semibold">
                <tr>
                    <th className="p-3">Nhóm</th>
                    <th className="p-3">Khoản mục</th>
                    <th className="p-3 text-right">SL</th>
                    <th className="p-3 text-right">Đơn giá</th>
                    <th className="p-3 text-right">Thành tiền</th>
                    <th className="p-3">Hình thức</th>
                    <th className="p-3 text-center">Xóa</th>
                </tr>
             </thead>
             <tbody className="divide-y divide-gray-100">
                {tourExpenses.map(e => (
                    <tr key={e.id} className="hover:bg-gray-50">
                        <td className="p-3">
                            <span className="px-2 py-1 bg-gray-200 rounded text-xs text-gray-700">{e.category}</span>
                        </td>
                        <td className="p-3 font-medium text-gray-800">{e.name}</td>
                        <td className="p-3 text-right text-gray-600">{e.quantity}</td>
                        <td className="p-3 text-right text-gray-600">{formatCurrency(e.unitPrice)}</td>
                        <td className="p-3 text-right font-medium text-gray-800">{formatCurrency(e.quantity * e.unitPrice)}</td>
                        <td className="p-3 text-gray-500 text-xs">{e.paymentMethod}</td>
                        <td className="p-3 text-center">
                            <button onClick={() => deleteExpense(e.id)} className="text-red-400 hover:text-red-600 p-1">
                                <Trash2 size={16} />
                            </button>
                        </td>
                    </tr>
                ))}
                {tourExpenses.length === 0 && (
                    <tr>
                        <td colSpan={7} className="p-8 text-center text-gray-400">Chưa có chi phí nào</td>
                    </tr>
                )}
             </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};