
import React, { useState } from 'react';
import { Plus, Trash2, CalendarClock, Clock, MapPin } from 'lucide-react';
import { useAppStore } from '../services/store';
import { PlanItem } from '../types';

interface PlanTabProps {
  tourId: string;
}

export const PlanTab: React.FC<PlanTabProps> = ({ tourId }) => {
  const { plans, addPlan, deletePlan } = useAppStore();
  const tourPlans = plans
    .filter(p => p.tourInstanceId === tourId)
    .sort((a, b) => {
        if (a.day !== b.day) return a.day - b.day;
        return a.time.localeCompare(b.time);
    });

  // Group plans by Day
  const groupedPlans = tourPlans.reduce((groups, plan) => {
    const day = plan.day;
    if (!groups[day]) groups[day] = [];
    groups[day].push(plan);
    return groups;
  }, {} as Record<number, PlanItem[]>);

  // Form State
  const [newPlan, setNewPlan] = useState<Partial<PlanItem>>({
    day: 1,
    time: '07:00',
    content: '',
    note: ''
  });

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPlan.content) return;

    addPlan({
      ...newPlan,
      id: Math.random().toString(36).substr(2, 9),
      tourInstanceId: tourId,
    } as PlanItem);

    setNewPlan({
      ...newPlan,
      content: '', // Keep day/time for faster entry
      note: ''
    });
  };

  return (
    <div className="p-4 md:p-6">
       <div className="mb-6 bg-indigo-50 border border-indigo-100 p-4 rounded-lg flex items-start space-x-3">
            <CalendarClock className="text-indigo-600 mt-1" size={20} />
            <div>
                <h4 className="font-bold text-indigo-800">Kế hoạch tổ chức</h4>
                <p className="text-sm text-indigo-600">Timeline chi tiết các hoạt động trong chuyến đi để Ops/Leader nắm bắt.</p>
            </div>
        </div>

      {/* Input Form */}
      <div className="bg-gray-50 p-4 rounded-lg border border-gray-200 mb-8 sticky top-0 z-10 shadow-sm">
        <h4 className="font-bold text-gray-700 mb-3 text-sm uppercase">Thêm hoạt động</h4>
        <form onSubmit={handleAdd} className="grid grid-cols-2 md:grid-cols-12 gap-3 items-end">
          <div className="col-span-1 md:col-span-2">
             <label className="block text-xs text-gray-500 mb-1">Ngày</label>
             <select 
                className="w-full border rounded p-2 text-sm focus:border-indigo-500 outline-none bg-white"
                value={newPlan.day}
                onChange={e => setNewPlan({...newPlan, day: parseInt(e.target.value)})}
             >
                {[1, 2, 3, 4, 5].map(d => <option key={d} value={d}>Ngày {d}</option>)}
             </select>
          </div>
          <div className="col-span-1 md:col-span-2">
             <label className="block text-xs text-gray-500 mb-1">Giờ</label>
             <input 
                type="time" 
                className="w-full border rounded p-2 text-sm focus:border-indigo-500 outline-none"
                value={newPlan.time}
                onChange={e => setNewPlan({...newPlan, time: e.target.value})}
             />
          </div>
          <div className="col-span-2 md:col-span-5">
             <label className="block text-xs text-gray-500 mb-1">Nội dung hoạt động</label>
             <input 
                type="text" 
                className="w-full border rounded p-2 text-sm focus:border-indigo-500 outline-none"
                required
                placeholder="VD: Tập trung tại điểm hẹn, Ăn sáng..."
                value={newPlan.content || ''}
                onChange={e => setNewPlan({...newPlan, content: e.target.value})}
             />
          </div>
          <div className="col-span-2 md:col-span-3">
             <label className="block text-xs text-gray-500 mb-1">Lưu ý</label>
             <div className="flex space-x-2">
                <input 
                    type="text" 
                    className="w-full border rounded p-2 text-sm focus:border-indigo-500 outline-none"
                    placeholder="Note..."
                    value={newPlan.note || ''}
                    onChange={e => setNewPlan({...newPlan, note: e.target.value})}
                />
                <button type="submit" className="bg-indigo-600 text-white p-2 rounded hover:bg-indigo-700 transition-colors w-10 flex items-center justify-center">
                    <Plus size={20}/>
                </button>
             </div>
          </div>
        </form>
      </div>

      {/* Timeline View */}
      <div className="space-y-8">
        {Object.keys(groupedPlans).map(day => (
            <div key={day} className="relative">
                <div className="sticky top-0 bg-white z-0 py-2 mb-2 border-b border-gray-100">
                    <h3 className="text-lg font-bold text-indigo-700 uppercase">Ngày {day}</h3>
                </div>
                
                <div className="ml-4 border-l-2 border-indigo-100 space-y-6 pb-4">
                    {groupedPlans[parseInt(day)].map(plan => (
                        <div key={plan.id} className="relative pl-6 group">
                            {/* Dot */}
                            <div className="absolute -left-[9px] top-1.5 w-4 h-4 rounded-full bg-white border-4 border-indigo-400 group-hover:border-indigo-600 transition-colors"></div>
                            
                            <div className="flex justify-between items-start group-hover:bg-gray-50 p-2 rounded-lg -ml-2 -mt-2 transition-colors">
                                <div className="flex-1">
                                    <div className="flex items-center text-sm font-bold text-gray-800 mb-1">
                                        <Clock size={14} className="mr-1 text-gray-400"/>
                                        {plan.time}
                                    </div>
                                    <div className="text-gray-900 font-medium">
                                        {plan.content}
                                    </div>
                                    {plan.note && (
                                        <div className="text-sm text-red-500 italic mt-1 flex items-start">
                                            <span className="mr-1">*</span> {plan.note}
                                        </div>
                                    )}
                                </div>
                                <button 
                                    onClick={() => deletePlan(plan.id)}
                                    className="opacity-0 group-hover:opacity-100 text-gray-300 hover:text-red-500 transition-all p-1"
                                >
                                    <Trash2 size={16} />
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        ))}
        
        {tourPlans.length === 0 && (
            <div className="text-center py-10 text-gray-400">
                Chưa có kế hoạch nào.
            </div>
        )}
      </div>
    </div>
  );
};
