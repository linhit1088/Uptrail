
import React, { useState } from 'react';
import { Plus, Trash2, Phone, Bus, Home, Utensils, User, MoreHorizontal, MessageCircle } from 'lucide-react';
import { useAppStore } from '../services/store';
import { Partner, PartnerCategory } from '../types';

interface PartnerTabProps {
  tourId: string;
}

export const PartnerTab: React.FC<PartnerTabProps> = ({ tourId }) => {
  const { partners, addPartner, deletePartner } = useAppStore();
  const tourPartners = partners.filter(p => p.tourInstanceId === tourId);

  // Form State
  const [newPartner, setNewPartner] = useState<Partial<Partner>>({
    category: 'Nhà Xe',
    name: '',
    phone: '',
    note: ''
  });

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPartner.name) return;

    addPartner({
      ...newPartner,
      id: Math.random().toString(36).substr(2, 9),
      tourInstanceId: tourId,
    } as Partner);

    setNewPartner({
      category: 'Nhà Xe',
      name: '',
      phone: '',
      note: ''
    });
  };

  const getIcon = (category: PartnerCategory) => {
    switch (category) {
      case 'Nhà Xe': return <Bus size={18} className="text-blue-600" />;
      case 'Nhà Nghỉ/Homestay': return <Home size={18} className="text-indigo-600" />;
      case 'Nhà Hàng': return <Utensils size={18} className="text-orange-600" />;
      case 'Porter': return <User size={18} className="text-green-600" />;
      default: return <MoreHorizontal size={18} className="text-gray-600" />;
    }
  };

  const getBorderColor = (category: PartnerCategory) => {
    switch (category) {
      case 'Nhà Xe': return 'border-l-blue-500';
      case 'Nhà Nghỉ/Homestay': return 'border-l-indigo-500';
      case 'Nhà Hàng': return 'border-l-orange-500';
      case 'Porter': return 'border-l-green-500';
      default: return 'border-l-gray-500';
    }
  };

  return (
    <div className="p-4 md:p-6">
      <div className="mb-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
         <div>
            <h3 className="font-bold text-gray-800 text-lg">Danh sách Đối tác</h3>
            <p className="text-sm text-gray-500">Liên hệ nhà xe, porter, điểm ngủ...</p>
         </div>
      </div>

      {/* Input Form */}
      <div className="bg-gray-50 p-4 rounded-lg border border-gray-200 mb-6">
        <h4 className="font-bold text-gray-700 mb-3 text-sm uppercase">Thêm đối tác mới</h4>
        <form onSubmit={handleAdd} className="grid grid-cols-1 md:grid-cols-12 gap-3 items-end">
          <div className="md:col-span-3">
            <label className="block text-xs text-gray-500 mb-1">Loại hình</label>
            <select 
                className="w-full border rounded p-2 text-sm focus:border-teal-500 outline-none bg-white"
                value={newPartner.category}
                onChange={e => setNewPartner({...newPartner, category: e.target.value as PartnerCategory})}
            >
                <option value="Nhà Xe">Nhà Xe</option>
                <option value="Nhà Nghỉ/Homestay">Nhà Nghỉ/Homestay</option>
                <option value="Nhà Hàng">Nhà Hàng</option>
                <option value="Porter">Porter</option>
                <option value="Khác">Khác</option>
            </select>
          </div>
          <div className="md:col-span-3">
             <label className="block text-xs text-gray-500 mb-1">Tên đối tác / Liên hệ</label>
             <input 
                type="text" 
                className="w-full border rounded p-2 text-sm focus:border-teal-500 outline-none"
                required
                placeholder="VD: Xe Sao Việt, A Chư..."
                value={newPartner.name || ''}
                onChange={e => setNewPartner({...newPartner, name: e.target.value})}
             />
          </div>
          <div className="md:col-span-2">
             <label className="block text-xs text-gray-500 mb-1">SĐT</label>
             <input 
                type="tel" 
                className="w-full border rounded p-2 text-sm focus:border-teal-500 outline-none"
                placeholder="09..."
                value={newPartner.phone || ''}
                onChange={e => setNewPartner({...newPartner, phone: e.target.value})}
             />
          </div>
          <div className="md:col-span-3">
             <label className="block text-xs text-gray-500 mb-1">Ghi chú (Cọc, giá...)</label>
             <input 
                type="text" 
                className="w-full border rounded p-2 text-sm focus:border-teal-500 outline-none"
                value={newPartner.note || ''}
                onChange={e => setNewPartner({...newPartner, note: e.target.value})}
             />
          </div>
          <div className="md:col-span-1">
             <button type="submit" className="w-full bg-teal-600 text-white p-2 rounded hover:bg-teal-700 text-sm font-medium transition-colors h-[38px] flex items-center justify-center">
                <Plus size={18}/>
             </button>
          </div>
        </form>
      </div>

      {/* List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {tourPartners.map(p => (
            <div key={p.id} className={`bg-white rounded-lg shadow-sm border border-gray-100 border-l-4 ${getBorderColor(p.category)} p-4 flex justify-between items-start`}>
                <div className="flex-1 pr-4">
                    <div className="flex items-center space-x-2 mb-1">
                        {getIcon(p.category)}
                        <span className="text-xs font-bold text-gray-500 uppercase tracking-wide">{p.category}</span>
                    </div>
                    <h4 className="font-bold text-gray-800 text-base">{p.name}</h4>
                    {p.phone && <div className="text-sm text-gray-600 font-mono mt-1">{p.phone}</div>}
                    {p.note && <div className="text-sm text-gray-500 italic mt-2 bg-gray-50 p-2 rounded">{p.note}</div>}
                </div>
                
                <div className="flex flex-col space-y-2">
                     {p.phone && (
                        <>
                            <a href={`tel:${p.phone}`} className="p-2 bg-green-50 text-green-600 rounded-lg hover:bg-green-100">
                                <Phone size={18} />
                            </a>
                            <a href={`https://zalo.me/${p.phone}`} target="_blank" rel="noreferrer" className="p-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100">
                                <MessageCircle size={18} />
                            </a>
                        </>
                     )}
                     <button onClick={() => deletePartner(p.id)} className="p-2 text-gray-300 hover:bg-red-50 hover:text-red-500 rounded-lg">
                        <Trash2 size={18} />
                     </button>
                </div>
            </div>
        ))}
        {tourPartners.length === 0 && (
            <div className="col-span-1 md:col-span-2 text-center py-12 text-gray-400 border-2 border-dashed border-gray-100 rounded-xl">
                Chưa có đối tác nào. Hãy thêm Nhà xe, Porter...
            </div>
        )}
      </div>
    </div>
  );
};
