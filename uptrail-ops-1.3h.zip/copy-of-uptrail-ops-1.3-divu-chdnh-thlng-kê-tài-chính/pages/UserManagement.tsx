
import React, { useState } from 'react';
import { Plus, Edit2, Trash2, Shield, User as UserIcon, AlertTriangle, X, CheckSquare, Square, Lock, Key } from 'lucide-react';
import { useAppStore } from '../services/store';
import { User, UserRole, PERMISSION_GROUPS } from '../types';

export const UserManagement: React.FC = () => {
  const { users, currentUser, addUser, updateUser, deleteUser } = useAppStore();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  
  // State cho Modal xác nhận xóa
  const [deleteId, setDeleteId] = useState<string | null>(null);

  // Chỉ Admin mới được vào trang này
  if (!currentUser?.roles.includes(UserRole.ADMIN)) {
    return <div className="p-8 text-center text-red-500">Bạn không có quyền truy cập trang này.</div>;
  }

  const handleEdit = (user: User) => {
    setEditingUser(user);
    setIsModalOpen(true);
  };

  const handleAdd = () => {
    setEditingUser(null);
    setIsModalOpen(true);
  };

  // Mở modal xác nhận xóa
  const confirmDelete = (e: React.MouseEvent, id: string) => {
    e.stopPropagation(); // Ngăn chặn sự kiện click lan truyền
    if (id === currentUser.id) {
        alert("Không thể xóa tài khoản đang đăng nhập!");
        return;
    }
    setDeleteId(id);
  };

  // Thực hiện xóa
  const handleDeleteAction = () => {
    if (deleteId) {
      deleteUser(deleteId);
      setDeleteId(null);
    }
  };

  const getRoleBadgeColor = (role: UserRole) => {
      switch(role) {
          case UserRole.ADMIN: return 'bg-purple-100 text-purple-700';
          case UserRole.SALE: return 'bg-green-100 text-green-700';
          case UserRole.OPS: return 'bg-blue-100 text-blue-700';
          case UserRole.LEADER: return 'bg-orange-100 text-orange-700';
          case UserRole.ACCOUNTANT: return 'bg-pink-100 text-pink-700';
          default: return 'bg-gray-100 text-gray-700';
      }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
           <h1 className="text-2xl font-bold text-gray-800">Quản lý tài khoản</h1>
           <p className="text-sm text-gray-500">Thêm, sửa, xóa tài khoản và phân quyền chi tiết</p>
        </div>
        <button 
            onClick={handleAdd}
            className="bg-teal-600 text-white px-4 py-2 rounded-lg flex items-center space-x-2 hover:bg-teal-700 transition-colors"
        >
            <Plus size={18} />
            <span>Thêm tài khoản</span>
        </button>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-gray-50 border-b border-gray-200 text-gray-600 text-xs uppercase font-semibold">
            <tr>
              <th className="px-6 py-4">Họ tên</th>
              <th className="px-6 py-4">Username</th>
              <th className="px-6 py-4">Vai trò</th>
              <th className="px-6 py-4 text-center">Quyền hạn</th>
              <th className="px-6 py-4 text-center">Hành động</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {users.map(user => (
              <tr key={user.id} className="hover:bg-gray-50 transition-colors">
                <td className="px-6 py-4 font-medium text-gray-900 flex items-center">
                   <div className={`p-2 rounded-full mr-3 ${user.roles.includes(UserRole.ADMIN) ? 'bg-purple-100 text-purple-600' : 'bg-gray-100 text-gray-500'}`}>
                      {user.roles.includes(UserRole.ADMIN) ? <Shield size={16} /> : <UserIcon size={16} />}
                   </div>
                   {user.name}
                </td>
                <td className="px-6 py-4 text-gray-600">{user.username}</td>
                <td className="px-6 py-4">
                  <div className="flex flex-wrap gap-1">
                      {user.roles.map(role => (
                        <span key={role} className={`px-2 py-1 rounded-full text-xs font-semibold ${getRoleBadgeColor(role)}`}>
                            {role}
                        </span>
                      ))}
                  </div>
                </td>
                <td className="px-6 py-4 text-center">
                    <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded-md font-mono" title={user.permissions?.join(', ')}>
                        {user.permissions?.length || 0} permissions
                    </span>
                </td>
                <td className="px-6 py-4 text-center">
                  <div className="flex justify-center space-x-2">
                    <button 
                        type="button"
                        onClick={() => handleEdit(user)} 
                        className="p-2 text-blue-600 hover:bg-blue-100 rounded-lg transition-colors"
                        title="Chỉnh sửa & Phân quyền"
                    >
                      <Edit2 size={16} />
                    </button>
                    <button 
                        type="button"
                        onClick={(e) => confirmDelete(e, user.id)} 
                        className="p-2 text-red-600 hover:bg-red-100 rounded-lg transition-colors"
                        title="Xóa tài khoản"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Delete Confirmation Modal */}
      {deleteId && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-[60] flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-sm overflow-hidden transform scale-100 transition-all">
            <div className="p-6 text-center">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <AlertTriangle className="text-red-600 w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">Xác nhận xóa?</h3>
              <p className="text-gray-500 mb-6">
                Bạn có chắc chắn muốn xóa tài khoản <b>{users.find(u => u.id === deleteId)?.name}</b>?
              </p>
              <div className="flex space-x-3">
                <button 
                  onClick={() => setDeleteId(null)}
                  className="flex-1 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 font-medium transition-colors"
                >
                  Hủy bỏ
                </button>
                <button 
                  onClick={handleDeleteAction}
                  className="flex-1 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 font-medium shadow-sm transition-colors"
                >
                  Xóa ngay
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {isModalOpen && (
        <UserModal 
          isOpen={isModalOpen} 
          onClose={() => setIsModalOpen(false)} 
          user={editingUser} 
        />
      )}
    </div>
  );
};

const UserModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    user: User | null;
}> = ({ isOpen, onClose, user }) => {
    const { addUser, updateUser } = useAppStore();
    const [formData, setFormData] = useState<Partial<User>>(user || {
        name: '',
        username: '',
        password: '',
        roles: [UserRole.SALE],
        permissions: []
    });

    // Helper: Select all permissions
    const togglePermission = (code: string) => {
        const current = formData.permissions || [];
        if (current.includes(code)) {
            setFormData({...formData, permissions: current.filter(p => p !== code)});
        } else {
            setFormData({...formData, permissions: [...current, code]});
        }
    };

    // Helper: Auto-fill permissions based on Role
    const applyRoleTemplate = (role: UserRole) => {
        let newPerms: string[] = [];
        const allPerms = PERMISSION_GROUPS.flatMap(g => g.items.map(i => i.code));

        switch(role) {
            case UserRole.ADMIN:
                newPerms = allPerms;
                break;
            case UserRole.SALE:
                newPerms = ['tour.view', 'booking.view', 'booking.add', 'booking.edit', 'customer.view', 'customer.edit'];
                break;
            case UserRole.OPS:
                newPerms = ['tour.view', 'tour.edit', 'booking.view', 'finance.view_detail', 'finance.add_expense'];
                break;
            case UserRole.ACCOUNTANT:
                newPerms = ['finance.view_overview', 'finance.view_detail', 'finance.export', 'tour.view', 'booking.view'];
                break;
            case UserRole.LEADER:
                 newPerms = ['tour.view', 'booking.view'];
                 break;
        }

        // Merge with existing unique
        const merged = Array.from(new Set([...(formData.permissions || []), ...newPerms]));
        setFormData({...formData, permissions: merged});
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!formData.name || !formData.username || (!user && !formData.password)) return;
        
        const userData = {
            ...formData,
            id: user ? user.id : Math.random().toString(36).substr(2, 9),
            roles: formData.roles || [],
            permissions: formData.permissions || []
        } as User;

        if (user) {
            updateUser(userData);
        } else {
            addUser(userData);
        }
        onClose();
    };

    const toggleRole = (role: UserRole) => {
        const currentRoles = formData.roles || [];
        if (currentRoles.includes(role)) {
            setFormData({...formData, roles: currentRoles.filter(r => r !== role)});
        } else {
            setFormData({...formData, roles: [...currentRoles, role]});
        }
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-xl shadow-xl w-full max-w-4xl max-h-[90vh] flex flex-col">
                <div className="p-6 border-b border-gray-100 flex justify-between items-center shrink-0">
                    <h2 className="text-xl font-bold text-gray-800">{user ? 'Sửa tài khoản & Phân quyền' : 'Thêm tài khoản mới'}</h2>
                    <button onClick={onClose} className="text-gray-400 hover:text-gray-600 transition-colors">
                        <X size={24} />
                    </button>
                </div>
                
                <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        {/* LEFT COLUMN: BASIC INFO */}
                        <div className="space-y-4">
                            <h3 className="font-bold text-gray-800 border-b pb-2 mb-4 flex items-center"><UserIcon size={18} className="mr-2"/> Thông tin cơ bản</h3>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Họ tên</label>
                                <input 
                                    type="text" 
                                    required
                                    className="w-full border rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-teal-500"
                                    value={formData.name}
                                    onChange={e => setFormData({...formData, name: e.target.value})}
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Tên đăng nhập</label>
                                <input 
                                    type="text" 
                                    required
                                    className="w-full border rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-teal-500"
                                    value={formData.username}
                                    onChange={e => setFormData({...formData, username: e.target.value})}
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Mật khẩu {user && '(Để trống nếu không đổi)'}</label>
                                <input 
                                    type="text" 
                                    required={!user}
                                    className="w-full border rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-teal-500"
                                    value={formData.password || ''}
                                    onChange={e => setFormData({...formData, password: e.target.value})}
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-2">Vai trò (Chức danh)</label>
                                <div className="space-y-2 border rounded-lg p-3">
                                    {Object.values(UserRole).map(role => {
                                        const isChecked = formData.roles?.includes(role);
                                        return (
                                            <div key={role} className="flex items-center justify-between group">
                                                <div 
                                                    className={`flex items-center cursor-pointer`}
                                                    onClick={() => toggleRole(role)}
                                                >
                                                    <div className={`mr-2 ${isChecked ? 'text-teal-600' : 'text-gray-400'}`}>
                                                        {isChecked ? <CheckSquare size={18} /> : <Square size={18} />}
                                                    </div>
                                                    <span className={`text-sm font-medium ${isChecked ? 'text-teal-800' : 'text-gray-600'}`}>
                                                        {role}
                                                    </span>
                                                </div>
                                                <button 
                                                    type="button"
                                                    onClick={() => applyRoleTemplate(role)}
                                                    className="text-[10px] bg-gray-100 hover:bg-teal-100 text-gray-600 hover:text-teal-700 px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity"
                                                >
                                                    Áp dụng quyền
                                                </button>
                                            </div>
                                        )
                                    })}
                                </div>
                                <p className="text-xs text-gray-400 mt-1">* Bấm "Áp dụng quyền" để tự động tích các quyền gợi ý cho vai trò này.</p>
                            </div>
                        </div>

                        {/* RIGHT COLUMN: DETAILED PERMISSIONS */}
                        <div>
                            <h3 className="font-bold text-gray-800 border-b pb-2 mb-4 flex items-center justify-between">
                                <span className="flex items-center"><Key size={18} className="mr-2"/> Phân quyền chi tiết</span>
                                <span className="text-xs font-normal text-gray-500 bg-gray-100 px-2 py-1 rounded">
                                    Đang chọn: {formData.permissions?.length || 0}
                                </span>
                            </h3>
                            
                            <div className="space-y-6 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
                                {PERMISSION_GROUPS.map(group => (
                                    <div key={group.prefix} className="bg-gray-50 rounded-lg p-3">
                                        <h4 className="text-sm font-bold text-gray-700 mb-2 uppercase">{group.groupName}</h4>
                                        <div className="space-y-2">
                                            {group.items.map(item => {
                                                const hasPerm = formData.permissions?.includes(item.code);
                                                return (
                                                    <div 
                                                        key={item.code} 
                                                        className="flex items-center cursor-pointer hover:bg-gray-100 p-1 rounded -ml-1"
                                                        onClick={() => togglePermission(item.code)}
                                                    >
                                                        <div className={`mr-2 ${hasPerm ? 'text-blue-600' : 'text-gray-300'}`}>
                                                            {hasPerm ? <CheckSquare size={16} /> : <Square size={16} />}
                                                        </div>
                                                        <span className={`text-sm ${hasPerm ? 'text-gray-800 font-medium' : 'text-gray-500'}`}>
                                                            {item.label}
                                                        </span>
                                                    </div>
                                                )
                                            })}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </form>

                <div className="p-6 border-t border-gray-100 bg-gray-50 rounded-b-xl flex justify-end space-x-3 shrink-0">
                     <button onClick={onClose} className="px-6 py-2 bg-white border border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-50">
                         Hủy
                     </button>
                     <button onClick={handleSubmit} className="px-6 py-2 bg-teal-600 text-white rounded-lg font-medium hover:bg-teal-700 shadow-sm">
                         Lưu cấu hình
                     </button>
                </div>
            </div>
        </div>
    );
};
