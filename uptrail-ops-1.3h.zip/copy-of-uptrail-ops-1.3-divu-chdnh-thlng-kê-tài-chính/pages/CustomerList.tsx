
import React, { useState } from 'react';
import { Search, User, Phone, MapPin, Calendar, CreditCard, Edit2, X, Star, Trash2, AlertTriangle, Save } from 'lucide-react';
import { useAppStore } from '../services/store';
import { Customer, formatCurrency, calculateAge } from '../types';

export const CustomerList: React.FC = () => {
  const { customers, bookings, tours, updateCustomer, deleteCustomer } = useAppStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  
  // Delete State
  const [deleteId, setDeleteId] = useState<string | null>(null);

  // Tính toán dữ liệu động mỗi khi render
  const enrichedCustomers = customers.map(c => {
    // Lấy tất cả booking của khách này (theo SĐT)
    const customerBookings = bookings.filter(b => b.phone === c.phone);
    const totalSpent = customerBookings.reduce((sum, b) => sum + b.price, 0);
    const tripCount = customerBookings.length;
    
    return {
      ...c,
      totalSpent,
      tripCount,
      bookings: customerBookings
    };
  });

  const filteredCustomers = enrichedCustomers.filter(c => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    c.phone.includes(searchTerm) ||
    (c.cccd && c.cccd.includes(searchTerm))
  );

  const confirmDelete = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setDeleteId(id);
  };

  const handleDelete = () => {
    if (deleteId) {
        if (selectedCustomer?.id === deleteId) {
            setSelectedCustomer(null);
        }
        deleteCustomer(deleteId);
        setDeleteId(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Danh sách Khách hàng</h1>
          <p className="text-sm text-gray-500">Quản lý hồ sơ, lịch sử đi tour và thói quen khách hàng</p>
        </div>
        <div className="relative w-full md:w-80">
          <Search className="absolute left-3 top-2.5 text-gray-400" size={18} />
          <input 
            type="text" 
            placeholder="Tìm tên, SĐT, CCCD..." 
            className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Customer List */}
        <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
          <table className="w-full text-left text-sm">
            <thead className="bg-gray-50 text-gray-600 font-semibold border-b border-gray-200">
              <tr>
                <th className="px-6 py-4">Khách hàng</th>
                <th className="px-6 py-4">SĐT / CCCD</th>
                <th className="px-6 py-4 text-center">Số Tour</th>
                <th className="px-6 py-4 text-right">Tổng chi</th>
                <th className="px-6 py-4">Ghi chú</th>
                <th className="px-4 py-4 w-10"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredCustomers.map(c => (
                <tr 
                    key={c.id} 
                    onClick={() => setSelectedCustomer(c)}
                    className={`cursor-pointer hover:bg-teal-50 transition-colors ${selectedCustomer?.id === c.id ? 'bg-teal-50' : ''}`}
                >
                  <td className="px-6 py-4">
                    <div className="font-medium text-gray-900">{c.name}</div>
                    <div className="text-xs text-gray-500">{c.birthDate ? `${new Date(c.birthDate).toLocaleDateString('vi-VN')} (${calculateAge(c.birthDate)}t)` : ''} {c.hometown ? `- ${c.hometown}` : ''}</div>
                  </td>
                  <td className="px-6 py-4 text-gray-600">
                    <div className="flex items-center"><Phone size={12} className="mr-1"/> {c.phone}</div>
                    {c.cccd && <div className="text-xs text-gray-400 mt-1">{c.cccd}</div>}
                  </td>
                  <td className="px-6 py-4 text-center">
                    <span className="bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full text-xs font-bold">{c.tripCount}</span>
                  </td>
                  <td className="px-6 py-4 text-right font-medium text-teal-600">
                    {formatCurrency(c.totalSpent)}
                  </td>
                  <td className="px-6 py-4">
                    {c.notes && (
                        <div className="flex items-start text-xs text-orange-600 bg-orange-50 p-1 rounded max-w-[150px] truncate">
                           <Star size={10} className="mr-1 mt-0.5 flex-shrink-0" /> 
                           <span className="truncate">{c.notes}</span>
                        </div>
                    )}
                  </td>
                  <td className="px-4 py-4 text-center">
                    <button 
                        onClick={(e) => confirmDelete(e, c.id)}
                        className="p-2 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-full transition-colors"
                        title="Xóa khách hàng"
                    >
                        <Trash2 size={16} />
                    </button>
                  </td>
                </tr>
              ))}
              {filteredCustomers.length === 0 && (
                <tr><td colSpan={6} className="text-center py-8 text-gray-400">Không tìm thấy khách hàng nào</td></tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Customer Detail Panel - Responsive Modal on Mobile */}
        <div className={`
             lg:col-span-1 
             ${selectedCustomer ? 'fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/50 lg:static lg:bg-transparent lg:p-0 lg:block' : 'hidden lg:block'}
        `}>
            {/* Click backdrop to close on mobile */}
            <div className="absolute inset-0 lg:hidden" onClick={() => setSelectedCustomer(null)}></div>

            {selectedCustomer ? (
                <div className="w-full max-w-lg relative z-10 lg:w-auto lg:max-w-none max-h-full flex flex-col">
                    <CustomerDetailPanel 
                        customer={enrichedCustomers.find(c => c.id === selectedCustomer.id)!} 
                        tours={tours}
                        onClose={() => setSelectedCustomer(null)}
                        onSave={(updated) => updateCustomer(updated)}
                    />
                </div>
            ) : (
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-8 text-center text-gray-400 h-full flex flex-col items-center justify-center">
                    <User size={48} className="mb-4 text-gray-200" />
                    <p>Chọn một khách hàng để xem chi tiết hồ sơ</p>
                </div>
            )}
        </div>
      </div>

       {/* Delete Confirmation Modal */}
       {deleteId && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-[60] flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-sm overflow-hidden p-6 text-center">
             <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <AlertTriangle className="text-red-600 w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">Xóa khách hàng?</h3>
              <p className="text-gray-500 mb-6">
                Bạn có chắc muốn xóa khách hàng này? Lưu ý: Các booking cũ vẫn sẽ được giữ lại nhưng sẽ mất liên kết hồ sơ.
              </p>
              <div className="flex space-x-3">
                <button 
                  onClick={() => setDeleteId(null)}
                  className="flex-1 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 font-medium"
                >
                  Hủy bỏ
                </button>
                <button 
                  onClick={handleDelete}
                  className="flex-1 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 font-medium"
                >
                  Xóa ngay
                </button>
              </div>
          </div>
        </div>
      )}
    </div>
  );
};

const CustomerDetailPanel: React.FC<{ 
    customer: Customer & { bookings: any[], tripCount: number, totalSpent: number }, 
    tours: any[],
    onClose: () => void,
    onSave: (c: Customer) => void
}> = ({ customer, tours, onClose, onSave }) => {
    // Mode Editing
    const [isEditingProfile, setIsEditingProfile] = useState(false);
    
    // Form State
    const [formData, setFormData] = useState<Partial<Customer>>({
        name: customer.name,
        phone: customer.phone,
        cccd: customer.cccd,
        birthDate: customer.birthDate,
        hometown: customer.hometown,
        notes: customer.notes
    });

    // Reset form when customer changes
    React.useEffect(() => {
        setFormData({
            name: customer.name,
            phone: customer.phone,
            cccd: customer.cccd,
            birthDate: customer.birthDate,
            hometown: customer.hometown,
            notes: customer.notes
        });
        setIsEditingProfile(false);
    }, [customer]);

    const handleSave = () => {
        onSave({ 
            ...customer, 
            ...formData 
        } as Customer);
        setIsEditingProfile(false);
    }

    return (
        <div className="bg-white rounded-xl shadow-lg border border-teal-100 overflow-hidden sticky lg:top-6 w-full max-h-[85vh] lg:max-h-none flex flex-col">
            <div className="bg-teal-600 p-6 text-white relative shrink-0">
                <button onClick={onClose} className="absolute top-4 right-4 text-teal-200 hover:text-white"><X size={20}/></button>
                <div className="flex items-center space-x-4">
                    <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center text-2xl font-bold">
                        {customer.name.charAt(0)}
                    </div>
                    <div className="flex-1">
                        {isEditingProfile ? (
                             <input 
                                className="w-full bg-white/10 border border-white/30 rounded px-2 py-1 text-white placeholder-teal-200 focus:outline-none focus:bg-white/20 mb-1 font-bold"
                                value={formData.name}
                                onChange={e => setFormData({...formData, name: e.target.value})}
                             />
                        ) : (
                             <h2 className="text-xl font-bold">{customer.name}</h2>
                        )}
                        
                        <div className="text-teal-100 text-sm flex items-center mt-1">
                            <Phone size={14} className="mr-1"/> 
                            {isEditingProfile ? (
                                <input 
                                    className="bg-white/10 border border-white/30 rounded px-2 py-0.5 text-white text-xs w-32 focus:outline-none"
                                    value={formData.phone}
                                    onChange={e => setFormData({...formData, phone: e.target.value})}
                                />
                            ) : customer.phone}
                        </div>
                    </div>
                </div>
                
                {/* Toggle Edit Button */}
                <button 
                    onClick={() => isEditingProfile ? handleSave() : setIsEditingProfile(true)}
                    className="absolute bottom-4 right-4 bg-white/20 hover:bg-white/30 text-white p-2 rounded-lg transition-colors"
                    title={isEditingProfile ? "Lưu thay đổi" : "Chỉnh sửa hồ sơ"}
                >
                    {isEditingProfile ? <Save size={18} /> : <Edit2 size={18} />}
                </button>
            </div>

            <div className="p-6 space-y-6 overflow-y-auto">
                {/* Stats */}
                <div className="grid grid-cols-2 gap-4">
                    <div className="bg-blue-50 p-3 rounded-lg text-center">
                        <div className="text-xs text-blue-500 uppercase font-bold">Số Tour</div>
                        <div className="text-xl font-bold text-blue-700">{customer.tripCount}</div>
                    </div>
                    <div className="bg-green-50 p-3 rounded-lg text-center">
                        <div className="text-xs text-green-500 uppercase font-bold">Tổng Chi</div>
                        <div className="text-xl font-bold text-green-700">{(customer.totalSpent / 1000000).toFixed(1)}M</div>
                    </div>
                </div>

                {/* Info Fields */}
                <div className="space-y-3 text-sm text-gray-600">
                    <div className="flex justify-between items-center border-b border-gray-100 pb-2 h-9">
                        <span>Ngày sinh:</span>
                        {isEditingProfile ? (
                            <input 
                                type="date"
                                className="text-right border rounded px-2 py-1 w-32 text-gray-800"
                                value={formData.birthDate || ''}
                                onChange={e => setFormData({...formData, birthDate: e.target.value})}
                            />
                        ) : (
                            <span className="font-medium text-gray-800">
                                {customer.birthDate ? `${new Date(customer.birthDate).toLocaleDateString('vi-VN')} (${calculateAge(customer.birthDate)} tuổi)` : '---'}
                            </span>
                        )}
                    </div>
                    <div className="flex justify-between items-center border-b border-gray-100 pb-2 h-9">
                        <span>CCCD:</span>
                        {isEditingProfile ? (
                            <input 
                                className="text-right border rounded px-2 py-1 w-32 text-gray-800"
                                value={formData.cccd || ''}
                                onChange={e => setFormData({...formData, cccd: e.target.value})}
                            />
                        ) : (
                            <span className="font-medium text-gray-800">{customer.cccd || '---'}</span>
                        )}
                    </div>
                    <div className="flex justify-between items-center border-b border-gray-100 pb-2 h-9">
                        <span>Quê quán:</span>
                        {isEditingProfile ? (
                            <input 
                                className="text-right border rounded px-2 py-1 w-32 text-gray-800"
                                value={formData.hometown || ''}
                                onChange={e => setFormData({...formData, hometown: e.target.value})}
                            />
                        ) : (
                            <span className="font-medium text-gray-800">{customer.hometown || '---'}</span>
                        )}
                    </div>
                </div>

                {/* Notes */}
                <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-100">
                    <div className="flex justify-between items-center mb-2">
                        <h4 className="font-bold text-yellow-800 flex items-center"><Star size={14} className="mr-1"/> Ghi chú đặc biệt</h4>
                    </div>
                    
                    {isEditingProfile ? (
                        <textarea 
                            className="w-full p-2 text-sm border border-yellow-200 rounded focus:outline-teal-500 bg-white"
                            rows={3}
                            value={formData.notes || ''}
                            onChange={(e) => setFormData({...formData, notes: e.target.value})}
                            placeholder="Ghi chú về khách (ăn chay, khó tính...)"
                        />
                    ) : (
                        <p className="text-sm text-yellow-800 italic">{customer.notes || 'Chưa có ghi chú nào'}</p>
                    )}
                </div>

                {/* History */}
                <div>
                    <h4 className="font-bold text-gray-700 mb-3 flex items-center"><Calendar size={16} className="mr-2"/> Lịch sử đi tour</h4>
                    <div className="space-y-3 max-h-48 overflow-y-auto pr-1 scrollbar-thin">
                        {customer.bookings.map(b => {
                            const tour = tours.find(t => t.id === b.tourInstanceId);
                            return (
                                <div key={b.id} className="flex items-center justify-between text-sm bg-gray-50 p-2 rounded">
                                    <div>
                                        <div className="font-medium text-gray-800">{tour?.name || 'Unknown Tour'}</div>
                                        <div className="text-xs text-gray-500">{tour?.startDate}</div>
                                    </div>
                                    <div className="text-right">
                                        <div className="font-mono text-gray-600">{formatCurrency(b.price)}</div>
                                    </div>
                                </div>
                            )
                        })}
                    </div>
                </div>
            </div>
        </div>
    );
};