
import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, 
  Calendar, 
  Users, 
  FileText, 
  Wallet,
  Box,
  Handshake,
  CalendarClock
} from 'lucide-react';
import { useAppStore } from '../services/store';
import { UserRole } from '../types';
import { BookingTable } from '../components/BookingTable';
import { FinanceTab } from '../components/FinanceTab';
import { ChecklistTab } from '../components/ChecklistTab';
import { PartnerTab } from '../components/PartnerTab';
import { PlanTab } from '../components/PlanTab';

export const TourDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { tours, bookings, currentUser } = useAppStore();
  
  const [activeTab, setActiveTab] = useState<'bookings' | 'info' | 'checklist' | 'partners' | 'finances' | 'plans'>('bookings');

  const tour = tours.find(t => t.id === id);
  const tourBookings = bookings.filter(b => b.tourInstanceId === id);

  if (!tour) {
    return <div>Tour not found</div>;
  }

  const totalPax = tourBookings.length;
  const totalRevenue = tourBookings.reduce((sum, b) => sum + b.price, 0);
  const totalDeposit = tourBookings.reduce((sum, b) => sum + b.deposit, 0);
  const totalMissing = totalRevenue - totalDeposit;
  
  // Logic Permission updated for array roles
  const canViewFinance = currentUser?.roles.some(r => [UserRole.ADMIN, UserRole.OPS, UserRole.ACCOUNTANT].includes(r));
  const canViewChecklist = !currentUser?.roles.every(r => r === UserRole.SALE); // Nếu chỉ có mỗi role Sale thì ẩn
  const canViewPartners = !currentUser?.roles.every(r => r === UserRole.SALE);
  const canViewPlans = true; // Ai cũng xem được plan

  return (
    <div className="space-y-4 md:space-y-6 pb-20 md:pb-0">
      {/* Header */}
      <div className="flex flex-col space-y-3 md:space-y-4">
        <button 
          onClick={() => navigate('/tours')} 
          className="flex items-center text-gray-500 hover:text-gray-800 transition-colors w-fit text-sm md:text-base"
        >
          <ArrowLeft size={18} className="mr-1" /> Quay lại
        </button>

        <div className="bg-white rounded-xl p-4 md:p-6 shadow-sm border border-gray-100">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-4 md:mb-6">
            <div>
              <div className="flex flex-wrap items-center gap-2 mb-1">
                <h1 className="text-xl md:text-3xl font-bold text-gray-800 leading-tight">{tour.name}</h1>
                <span className="px-2 py-0.5 md:px-3 md:py-1 bg-teal-100 text-teal-800 rounded-full text-[10px] md:text-xs font-bold uppercase tracking-wide whitespace-nowrap">
                  {tour.status}
                </span>
              </div>
              <div className="flex flex-wrap items-center text-gray-500 gap-4 text-xs md:text-sm">
                <span className="flex items-center"><Calendar size={14} className="mr-1" /> {new Date(tour.startDate).toLocaleDateString('vi-VN')}</span>
                <span className="flex items-center font-mono bg-gray-100 px-2 py-0.5 rounded">{tour.code}</span>
              </div>
            </div>
            
            {/* Mobile Summary Row */}
            <div className="flex w-full md:w-auto overflow-x-auto gap-3 pb-1 md:pb-0">
                <div className="flex-1 bg-gray-50 p-2 md:p-3 rounded-lg min-w-[80px] text-center border border-gray-100">
                    <div className="text-[10px] md:text-xs text-gray-500 uppercase font-semibold">Khách</div>
                    <div className="text-lg md:text-xl font-bold text-gray-800">{totalPax}</div>
                </div>
                <div className="flex-1 bg-gray-50 p-2 md:p-3 rounded-lg min-w-[100px] text-center border border-gray-100">
                    <div className="text-[10px] md:text-xs text-gray-500 uppercase font-semibold">Thiếu</div>
                    <div className={`text-lg md:text-xl font-bold ${totalMissing > 0 ? 'text-red-600' : 'text-green-600'}`}>
                        {(totalMissing / 1000000).toFixed(1)}M
                    </div>
                </div>
            </div>
          </div>

          {/* Scrollable Tabs Navigation */}
          <div className="flex border-b border-gray-200 overflow-x-auto no-scrollbar -mx-4 px-4 md:mx-0 md:px-0">
            <button
              onClick={() => setActiveTab('bookings')}
              className={`flex-none flex items-center px-4 md:px-6 py-3 border-b-2 font-medium transition-colors text-sm md:text-base ${
                activeTab === 'bookings' 
                  ? 'border-teal-500 text-teal-600' 
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              <Users size={16} className="mr-2" />
              DS Khách
            </button>
            
            <button
              onClick={() => setActiveTab('info')}
              className={`flex-none flex items-center px-4 md:px-6 py-3 border-b-2 font-medium transition-colors text-sm md:text-base ${
                activeTab === 'info' 
                  ? 'border-teal-500 text-teal-600' 
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              <FileText size={16} className="mr-2" />
              Thông tin
            </button>

            {canViewChecklist && (
                <button
                onClick={() => setActiveTab('checklist')}
                className={`flex-none flex items-center px-4 md:px-6 py-3 border-b-2 font-medium transition-colors text-sm md:text-base ${
                    activeTab === 'checklist' 
                    ? 'border-teal-500 text-teal-600' 
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
                >
                <Box size={16} className="mr-2" />
                Checklist
                </button>
            )}

            {canViewPartners && (
                <button
                onClick={() => setActiveTab('partners')}
                className={`flex-none flex items-center px-4 md:px-6 py-3 border-b-2 font-medium transition-colors text-sm md:text-base ${
                    activeTab === 'partners' 
                    ? 'border-teal-500 text-teal-600' 
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
                >
                <Handshake size={16} className="mr-2" />
                Đối tác
                </button>
            )}
            
            {canViewFinance && (
              <button
                onClick={() => setActiveTab('finances')}
                className={`flex-none flex items-center px-4 md:px-6 py-3 border-b-2 font-medium transition-colors text-sm md:text-base ${
                  activeTab === 'finances' 
                    ? 'border-teal-500 text-teal-600' 
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                <Wallet size={16} className="mr-2" />
                Thu/Chi
              </button>
            )}

            {canViewPlans && (
              <button
                onClick={() => setActiveTab('plans')}
                className={`flex-none flex items-center px-4 md:px-6 py-3 border-b-2 font-medium transition-colors text-sm md:text-base ${
                  activeTab === 'plans' 
                    ? 'border-teal-500 text-teal-600' 
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                <CalendarClock size={16} className="mr-2" />
                Kế hoạch
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Content Area */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 min-h-[500px]">
        {activeTab === 'bookings' && <BookingTable tourId={tour.id} />}
        
        {activeTab === 'info' && (
          <div className="p-4 md:p-8 text-center text-gray-500">
            <h3 className="text-lg font-medium text-gray-800 mb-2">Thông tin & Ghi chú chung</h3>
            <div className="max-w-2xl mx-auto mt-4 text-left space-y-4">
                <div className="bg-blue-50 p-4 rounded-lg">
                    <span className="font-bold text-blue-800 block mb-1">Quy định hủy tour:</span>
                    <p className="text-sm text-blue-600">Hủy trước 7 ngày hoàn 70% cọc. Hủy sau 7 ngày mất cọc.</p>
                </div>
                <textarea 
                    className="w-full border p-4 rounded-lg h-32 text-sm focus:outline-teal-500" 
                    placeholder="Ghi chú chung cho cả đoàn..."
                ></textarea>
                <div className="flex justify-end">
                    <button className="px-4 py-2 bg-teal-600 text-white rounded hover:bg-teal-700 w-full md:w-auto">Lưu ghi chú</button>
                </div>
            </div>
          </div>
        )}

        {canViewChecklist && activeTab === 'checklist' && <ChecklistTab tourId={tour.id} />}
        
        {canViewPartners && activeTab === 'partners' && <PartnerTab tourId={tour.id} />}

        {canViewFinance && activeTab === 'finances' && <FinanceTab tourId={tour.id} />}

        {canViewPlans && activeTab === 'plans' && <PlanTab tourId={tour.id} />}
      </div>
    </div>
  );
};
