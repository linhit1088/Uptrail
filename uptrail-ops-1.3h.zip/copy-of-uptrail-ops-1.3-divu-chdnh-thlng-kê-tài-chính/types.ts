
export enum TourStatus {
  OPEN = 'Vẫn nhận khách',     // Màu xanh
  LOCKED = 'Ngừng nhận khách', // Màu đỏ
  FINISHED = 'Đã kết thúc',    // Màu đỏ
  DRAFT = 'Nháp',
  RUNNING = 'Đang chạy',
}

export enum UserRole {
  ADMIN = 'Admin',
  SALE = 'Sale',
  OPS = 'Ops',
  LEADER = 'Leader',
  ACCOUNTANT = 'Accountant', // New Role
}

// --- PERMISSION DEFINITIONS ---
export const PERMISSION_GROUPS = [
  {
    groupName: 'Quản lý Tour',
    prefix: 'tour',
    items: [
      { code: 'tour.view', label: 'Xem danh sách Tour' },
      { code: 'tour.create', label: 'Tạo Tour mới' },
      { code: 'tour.edit', label: 'Chỉnh sửa thông tin Tour' },
      { code: 'tour.delete', label: 'Xóa Tour' },
      { code: 'tour.hide', label: 'Ẩn/Hiện Tour' },
    ]
  },
  {
    groupName: 'Quản lý Booking (Khách)',
    prefix: 'booking',
    items: [
      { code: 'booking.view', label: 'Xem danh sách khách' },
      { code: 'booking.add', label: 'Thêm khách vào tour' },
      { code: 'booking.edit', label: 'Sửa thông tin khách' },
      { code: 'booking.delete', label: 'Xóa khách khỏi tour' },
      { code: 'booking.export', label: 'Xuất file danh sách' },
    ]
  },
  {
    groupName: 'Tài chính & Doanh thu',
    prefix: 'finance',
    items: [
      { code: 'finance.view_overview', label: 'Xem Dashboard tổng quan' },
      { code: 'finance.view_detail', label: 'Xem chi tiết thu/chi Tour' },
      { code: 'finance.add_expense', label: 'Thêm khoản chi' },
      { code: 'finance.delete_expense', label: 'Xóa khoản chi' },
      { code: 'finance.export', label: 'Xuất báo cáo tài chính' },
    ]
  },
  {
    groupName: 'Hồ sơ Khách hàng (CRM)',
    prefix: 'customer',
    items: [
      { code: 'customer.view', label: 'Xem danh sách CRM' },
      { code: 'customer.edit', label: 'Chỉnh sửa hồ sơ CRM' },
      { code: 'customer.delete', label: 'Xóa khách hàng CRM' },
    ]
  },
  {
    groupName: 'Hệ thống & Cài đặt',
    prefix: 'system',
    items: [
      { code: 'system.manage_users', label: 'Quản lý tài khoản User' },
      { code: 'system.settings', label: 'Cấu hình hệ thống' },
    ]
  }
];

export interface User {
  id: string;
  name: string;
  username: string;
  password?: string; // Optional for security in frontend display, but used for logic
  roles: UserRole[]; // Changed from single role to array
  permissions: string[]; // List of permission codes (e.g., 'tour.view', 'finance.export')
  avatar?: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  cccd?: string;
  birthDate?: string; // Changed from birthYear (YYYY-MM-DD)
  hometown?: string;
  notes?: string; // Ghi chú riêng: Khách khó, VIP...
  badHabits?: string; // Thói quen xấu/Lưu ý vận hành
  totalSpent?: number; // Tổng tiền đã chi (tính toán)
}

export interface TourType {
  id: string;
  name: string; // e.g., Kỳ Quan San
  duration: string; // e.g., 2N1Đ
  difficulty?: string;
}

export interface TourInstance {
  id: string;
  tourTypeId: string;
  code: string; // e.g., KQS 1-4/1
  name: string;
  startDate: string;
  leaderId?: string;
  status: TourStatus;
  isHidden?: boolean; // Đánh dấu ẩn tour (soft delete)
  visibility: 'public' | 'private'; // New: Chế độ xem
  allowedUserIds?: string[]; // New: Danh sách user được xem nếu private
}

export interface Booking {
  id: string;
  tourInstanceId: string;
  customerName: string;
  nickname?: string; // Tên huy chương
  gender: 'Nam' | 'Nữ' | 'Khác';
  birthDate?: string; // Changed from birthYear (YYYY-MM-DD)
  phone: string;
  cccd?: string;
  hometown?: string; // Tỉnh/Thường trú
  pickupPoint?: string;
  note?: string;
  saleId: string; // Sale phụ trách
  groupName?: string; // Nhóm
  
  // Finance
  price: number; // Giá chốt
  deposit: number; // Cọc
  // remaining calculated at runtime usually, but stored for ease here if needed
}

export interface ExpenseItem {
  id: string;
  tourInstanceId: string;
  category: 'Ăn uống' | 'Di chuyển' | 'Local' | 'Vé/Ngủ' | 'Khác';
  name: string;
  quantity: number;
  unitPrice: number;
  note?: string;
  paymentMethod: 'Tiền mặt' | 'Chuyển khoản';
  type: 'THU' | 'CHI';
}

export interface ChecklistItem {
  id: string;
  tourInstanceId: string;
  name: string;
  quantity: number;
  isPrepared: boolean; // Đã chuẩn bị/Lấy kho
  isReturned: boolean; // Đã trả/Mang về
  note?: string;
}

// --- NEW TYPES FOR PARTNERS ---
export type PartnerCategory = 'Nhà Xe' | 'Nhà Nghỉ/Homestay' | 'Nhà Hàng' | 'Porter' | 'Khác';

export interface Partner {
  id: string;
  tourInstanceId: string;
  category: PartnerCategory;
  name: string;
  phone?: string;
  contactPerson?: string; // Người liên hệ
  note?: string; // Ghi chú: Đã đặt cọc, giá deal...
}

// --- NEW TYPES FOR PLANS ---
export interface PlanItem {
  id: string;
  tourInstanceId: string;
  day: number; // Ngày 1, Ngày 2...
  time: string; // 08:00
  content: string; // Nội dung hoạt động
  note?: string; // Lưu ý quan trọng
}

export const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(amount);
};

// Helper for inputs to show "1.000.000"
export const formatNumberInput = (value: number | undefined) => {
    if (value === undefined || value === null) return '';
    return new Intl.NumberFormat('vi-VN').format(value);
};

export const calculateAge = (birthDateString?: string) => {
  if (!birthDateString) return 0;
  const birthDate = new Date(birthDateString);
  const today = new Date();
  let age = today.getFullYear() - birthDate.getFullYear();
  const m = today.getMonth() - birthDate.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
  return age;
};