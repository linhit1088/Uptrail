
import React, { useState } from 'react';
import { Search, Archive, User, Phone, MapPin, Calendar, ArrowRight, RefreshCw, X, Edit2 } from 'lucide-react';
import { useAppStore } from '../services/store';
import { calculateAge, formatCurrency, Booking, TourStatus, BookingHistoryLog } from '../types';
import { Link } from 'react-router-dom';
import { BookingModal } from '../components/BookingTable';

export const ReservationList: React.FC = () => {
  const { bookings, tours, updateBooking, currentUser } = useAppStore();
  const [searchTerm, setSearchTerm] = useState('');
  
  // Modal Transfer State
  const [transferBooking, setTransferBooking] = useState<Booking | null>(null);
  const [targetTourId, setTargetTourId] = useState('');

  // Edit Modal State
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editingBooking, setEditingBooking] = useState<Booking | null>(null);

  // Lọc khách hàng có status = RESERVED
  const reservedBookings = bookings.filter(b => b.status === 'RESERVED');
  
  const filteredReservations = reservedBookings.filter(b => 
    b.customerName.toLowerCase().includes(searchTerm.toLowerCase()) || 
    b.phone.includes(searchTerm)
  );

  const availableTours = tours.filter(t => 
    (t.status === TourStatus.OPEN || t.status === TourStatus.RUNNING) &&
    !t.isHidden
  );

  const handleOpenTransfer = (booking: Booking) => {
    setTransferBooking(booking);
    setTargetTourId('');
  };

  const handleOpenEdit = (booking: Booking) => {
      setEditingBooking(booking);
      setIsEditModalOpen(true);
  };

  const handleTransferAction = () => {
    if (!transferBooking || !targetTourId) return;
    
    const targetTour = tours.find(t => t.id === targetTourId);

    // Log history
    const log: BookingHistoryLog = {
        id: Math.random().toString(36).substr(2, 9),
        timestamp: new Date().toISOString(),
        action: 'RESTORE',
        detail: `Khôi phục từ bảo lưu sang tour ${targetTour?.code}`,
        performerName: currentUser?.name || 'Unknown'
    };

    updateBooking({
        ...transferBooking,
        tourInstanceId: targetTourId,
        status: 'ACTIVE',
        historyLogs: [...(transferBooking.historyLogs || []), log]
    });
    setTransferBooking(null);
    setTargetTourId('');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-800 flex items-center">
             <Archive className="mr-3 text-orange-600" /> Danh sách Bảo lưu
          </h1>
          <p className="text-sm text-gray-500">Quản lý khách hàng đang tạm hoãn, chờ đi tour sau.</p>
        </div>
        
        <div className="relative w-full md:w-80">
          <Search className="absolute left-3 top-2.5 text-gray-400" size={18} />
          <input 
            type="text" 
            placeholder="Tìm tên, SĐT..." 
            className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <table className="w-full text-left text-sm">
           <thead className="bg-gray-50 text-gray-600 font-semibold border-b border-gray-200 uppercase text-xs">
              <tr>
                 <th className="px-6 py-4">Khách hàng</th>
                 <th className="px-6 py-4">Liên hệ</th>
                 <th className="px-6 py-4 text-right">Đã cọc</th>
                 <th className="px-6 py-4">Ghi chú</th>
                 <th className="px-6 py-4 text-center">Hành động</th>
              </tr>
           </thead>
           <tbody className="divide-y divide-gray-100">
              {filteredReservations.map(b => (
                  <tr key={b.id} className="hover:bg-orange-50/30 transition-colors">
                     <td className="px-6 py-4">
                         <div className="font-bold text-gray-900">{b.customerName}</div>
                         <div className="text-xs text-gray-500 flex items-center mt-1">
                             <User size={12} className="mr-1"/> {b.birthDate ? `${calculateAge(b.birthDate)} tuổi` : '---'}
                             {b.nickname && <span className="ml-2 italic">"{b.nickname}"</span>}
                         </div>
                     </td>
                     <td className="px-6 py-4">
                         <div className="font-mono text-gray-600">{b.phone}</div>
                         <div className="text-xs text-gray-400 flex items-center mt-1">
                             <MapPin size={12} className="mr-1"/> {b.hometown || b.pickupPoint || '---'}
                         </div>
                     </td>
                     <td className="px-6 py-4 text-right">
                         <div className="font-bold text-teal-600">{formatCurrency(b.deposit)}</div>
                         <div className="text-xs text-gray-400">Giá cũ: {formatCurrency(b.price)}</div>
                     </td>
                     <td className="px-6 py-4">
                         <div className="text-gray-600 italic max-w-xs truncate">{b.note || 'Không có ghi chú'}</div>
                     </td>
                     <td className="px-6 py-4 text-center">
                         <div className="flex justify-center space-x-2">
                             <button 
                                type="button"
                                onClick={() => handleOpenTransfer(b)}
                                className="bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-1.5 rounded-lg text-xs font-bold shadow-sm flex items-center"
                                title="Thêm vào Tour"
                             >
                                 <RefreshCw size={14} className="mr-1"/> Thêm vào Tour
                             </button>
                             <button 
                                type="button"
                                onClick={() => handleOpenEdit(b)}
                                className="bg-gray-100 hover:bg-gray-200 text-gray-600 px-3 py-1.5 rounded-lg text-xs font-bold flex items-center"
                                title="Sửa thông tin"
                             >
                                 <Edit2 size={14} />
                             </button>
                         </div>
                     </td>
                  </tr>
              ))}
              {filteredReservations.length === 0 && (
                  <tr>
                      <td colSpan={5} className="text-center py-12 text-gray-400">
                          <Archive size={48} className="mx-auto mb-3 opacity-20"/>
                          <p>Không có khách hàng nào đang bảo lưu.</p>
                      </td>
                  </tr>
              )}
           </tbody>
        </table>
      </div>

      {/* Transfer Modal */}
      {transferBooking && (
          <div className="fixed inset-0 bg-black bg-opacity-60 z-[70] flex items-center justify-center p-4">
              <div className="bg-white rounded-xl shadow-2xl w-full max-w-md p-6 animate-in zoom-in-95 duration-200">
                  <div className="flex justify-between items-center mb-4">
                      <h3 className="text-lg font-bold text-gray-800">Chuyển khách vào Tour</h3>
                      <button type="button" onClick={() => setTransferBooking(null)} className="text-gray-400 hover:text-gray-600"><X size={20}/></button>
                  </div>
                  
                  <div className="mb-4 bg-orange-50 p-3 rounded-lg border border-orange-100">
                      <p className="text-xs text-orange-600 uppercase font-bold mb-1">Khách hàng bảo lưu</p>
                      <div className="font-bold text-gray-800 text-lg">{transferBooking.customerName}</div>
                      <div className="text-sm text-gray-600">Đã cọc: <span className="font-bold text-teal-600">{formatCurrency(transferBooking.deposit)}</span></div>
                  </div>

                  <div className="mb-6">
                      <label className="block text-sm font-medium text-gray-700 mb-2">Chọn tour muốn tham gia:</label>
                      {availableTours.length > 0 ? (
                          <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                              {availableTours.map(t => (
                                  <label key={t.id} className={`flex items-center justify-between p-3 border rounded-lg cursor-pointer transition-colors ${targetTourId === t.id ? 'border-indigo-500 bg-indigo-50' : 'border-gray-200 hover:bg-gray-50'}`}>
                                      <div className="flex items-center">
                                          <input 
                                              type="radio" 
                                              name="targetTour" 
                                              className="mr-3 text-indigo-600 focus:ring-indigo-500"
                                              checked={targetTourId === t.id}
                                              onChange={() => setTargetTourId(t.id)}
                                          />
                                          <div>
                                              <div className="font-medium text-gray-900 text-sm">{t.name}</div>
                                              <div className="text-xs text-gray-500 flex items-center mt-0.5">
                                                  <Calendar size={10} className="mr-1"/> 
                                                  {new Date(t.startDate).toLocaleDateString('vi-VN')}
                                                  <span className="mx-1">•</span>
                                                  {t.code}
                                              </div>
                                          </div>
                                      </div>
                                  </label>
                              ))}
                          </div>
                      ) : (
                          <div className="text-center p-4 bg-gray-50 rounded-lg text-gray-500 text-sm italic">
                              Hiện không có tour nào đang mở nhận khách.
                          </div>
                      )}
                  </div>

                  <div className="flex space-x-3">
                      <button type="button" onClick={() => setTransferBooking(null)} className="flex-1 py-2.5 bg-gray-100 text-gray-700 rounded-lg font-bold">Hủy</button>
                      <button 
                          type="button"
                          onClick={handleTransferAction} 
                          disabled={!targetTourId}
                          className={`flex-1 py-2.5 text-white rounded-lg font-bold flex items-center justify-center ${!targetTourId ? 'bg-gray-300 cursor-not-allowed' : 'bg-indigo-600 hover:bg-indigo-700 shadow-md'}`}
                      >
                          <RefreshCw size={18} className="mr-2"/> Xác nhận
                      </button>
                  </div>
              </div>
          </div>
      )}

      {/* Edit Modal reusing BookingModal */}
      {isEditModalOpen && editingBooking && (
          <BookingModal 
              isOpen={isEditModalOpen}
              onClose={() => setIsEditModalOpen(false)}
              booking={editingBooking}
              tourId={editingBooking.tourInstanceId} // Pass current tour ID even if reserved, modal handles data
          />
      )}
    </div>
  );
};
