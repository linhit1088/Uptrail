
import React, { useMemo, useState } from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Legend
} from 'recharts';
import { ArrowUpCircle, ArrowDownCircle, Wallet, Download, TrendingUp, Calendar, Filter, Archive, Plus, Trash2, Layers, PieChart } from 'lucide-react';
import { useAppStore } from '../services/store';
import { formatCurrency, GeneralExpense, UserRole } from '../types';

type TimeFilter = 'all' | 'day' | 'week' | 'month' | 'quarter' | 'year' | 'custom';

export const FinancePage: React.FC = () => {
  const { tours, bookings, expenses, generalExpenses, currentUser, addGeneralExpense, deleteGeneralExpense } = useAppStore();
  const [activeTab, setActiveTab] = useState<'tours' | 'general'>('tours');
  // Mặc định hiển thị tất cả để người dùng thấy ngay số liệu
  const [timeFilter, setTimeFilter] = useState<TimeFilter>('all');
  const [customStart, setCustomStart] = useState('');
  const [customEnd, setCustomEnd] = useState('');

  // General Expense Form State
  const [generalForm, setGeneralForm] = useState<Partial<GeneralExpense>>({
      category: '',
      name: '',
      amount: 0,
      date: new Date().toISOString().split('T')[0]
  });

  // Permission Check
  const canView = currentUser?.roles.some(r => [UserRole.ADMIN, UserRole.ACCOUNTANT, UserRole.OPS].includes(r));

  if (!canView) {
      return (
          <div className="flex flex-col items-center justify-center h-full text-gray-400">
              <Wallet size={48} className="mb-4" />
              <p>Bạn không có quyền truy cập báo cáo tài chính.</p>
          </div>
      )
  }

  // --- Filtering Logic ---
  const filteredTours = useMemo(() => {
      const now = new Date();
      return tours.filter(tour => {
          const d = new Date(tour.startDate);
          
          switch(timeFilter) {
              case 'custom':
                  if (customStart) {
                      const start = new Date(customStart);
                      if (d < start) return false;
                  }
                  if (customEnd) {
                      const end = new Date(customEnd);
                      end.setHours(23, 59, 59, 999);
                      if (d > end) return false;
                  }
                  return true;
              case 'day':
                  return d.getDate() === now.getDate() && 
                         d.getMonth() === now.getMonth() && 
                         d.getFullYear() === now.getFullYear();
              case 'week': {
                  const startOfWeek = new Date(now);
                  const day = startOfWeek.getDay() || 7; 
                  if(day !== 1) startOfWeek.setHours(-24 * (day - 1)); 
                  else startOfWeek.setHours(0,0,0,0);
                  
                  const endOfWeek = new Date(startOfWeek);
                  endOfWeek.setDate(endOfWeek.getDate() + 6);
                  endOfWeek.setHours(23,59,59,999);
                  return d >= startOfWeek && d <= endOfWeek;
              }
              case 'month':
                  return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
              case 'quarter': {
                  const currentQuarter = Math.floor(now.getMonth() / 3);
                  const tourQuarter = Math.floor(d.getMonth() / 3);
                  return currentQuarter === tourQuarter && d.getFullYear() === now.getFullYear();
              }
              case 'year':
                  return d.getFullYear() === now.getFullYear();
              case 'all':
              default:
                  return true;
          }
      }).sort((a, b) => new Date(b.startDate).getTime() - new Date(a.startDate).getTime());
  }, [tours, timeFilter, customStart, customEnd]);

  // --- Calculations based on Filtered Tours ---
  const filteredActiveBookings = useMemo(() => {
      const tourIds = new Set(filteredTours.map(t => t.id));
      return bookings.filter(b => tourIds.has(b.tourInstanceId) && b.status === 'ACTIVE');
  }, [bookings, filteredTours]);

  const filteredExpenses = useMemo(() => {
      const tourIds = new Set(filteredTours.map(t => t.id));
      return expenses.filter(e => tourIds.has(e.tourInstanceId) && e.type === 'CHI');
  }, [expenses, filteredTours]);

  // Filter General Expenses based on Time (Using Date field)
  const filteredGeneralExpenses = useMemo(() => {
      const now = new Date();
      return generalExpenses.filter(e => {
          const d = new Date(e.date);
          switch(timeFilter) {
              case 'custom':
                  if (customStart && d < new Date(customStart)) return false;
                  if (customEnd) {
                      const end = new Date(customEnd);
                      end.setHours(23, 59, 59, 999);
                      if (d > end) return false;
                  }
                  return true;
              case 'day':
                  return d.getDate() === now.getDate() && d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
              case 'month':
                  return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
              case 'year':
                  return d.getFullYear() === now.getFullYear();
              case 'all':
              default:
                  return true;
          }
      }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [generalExpenses, timeFilter, customStart, customEnd]);

  // 1. Global Stats
  const totalTourRevenue = filteredActiveBookings.reduce((sum, b) => sum + b.price, 0);
  const totalTourCost = filteredExpenses.reduce((sum, e) => sum + (e.quantity * e.unitPrice), 0);
  const totalGeneralCost = filteredGeneralExpenses.reduce((sum, e) => sum + e.amount, 0);
  
  // *** TỔNG CHI PHÍ TOÀN HỆ THỐNG ***
  const totalSystemCost = totalTourCost + totalGeneralCost;
  
  // *** LỢI NHUẬN RÒNG ***
  const netProfit = totalTourRevenue - totalSystemCost;
  const netMargin = totalTourRevenue > 0 ? Math.round((netProfit / totalTourRevenue) * 100) : 0;

  // 2. Reserved Fund (Money held)
  const totalReservedFund = useMemo(() => {
      return bookings
        .filter(b => b.status === 'RESERVED')
        .reduce((sum, b) => sum + b.deposit, 0);
  }, [bookings]);

  // 3. Tour Financials Detail
  const tourFinancials = useMemo(() => {
    return filteredTours.map(tour => {
        const currentTourBookings = bookings.filter(b => b.tourInstanceId === tour.id && b.status === 'ACTIVE');
        const currentTourExpenses = expenses.filter(e => e.tourInstanceId === tour.id && e.type === 'CHI');

        const revenue = currentTourBookings.reduce((sum, b) => sum + b.price, 0);
        const cost = currentTourExpenses.reduce((sum, e) => sum + (e.quantity * e.unitPrice), 0);
        const profit = revenue - cost;
        const margin = revenue > 0 ? Math.round((profit / revenue) * 100) : 0;
        const pax = currentTourBookings.length;

        return {
            id: tour.id,
            code: tour.code,
            name: tour.name,
            startDate: tour.startDate,
            revenue,
            cost,
            profit,
            margin,
            pax
        };
    });
  }, [filteredTours, bookings, expenses]);

  // 4. Chart Data
  const chartData = tourFinancials.slice(0, 15).reverse().map(t => ({
      name: t.code,
      DoanhThu: t.revenue,
      ChiPhi: t.cost,
      LoiNhuan: t.profit
  }));

  const handleAddGeneralExpense = (e: React.FormEvent) => {
      e.preventDefault();
      if (!generalForm.name || !generalForm.amount) return;
      
      addGeneralExpense({
          id: Math.random().toString(36).substr(2, 9),
          category: generalForm.category || 'Khác',
          name: generalForm.name,
          amount: Number(generalForm.amount),
          date: generalForm.date!,
          type: 'CHI' // Assume expenses are cost
      } as GeneralExpense);

      setGeneralForm({
          category: '',
          name: '',
          amount: 0,
          date: new Date().toISOString().split('T')[0]
      });
  };

  const handleDateChange = (start: string, end: string) => {
      setCustomStart(start);
      setCustomEnd(end);
      if (start || end) {
          setTimeFilter('custom');
      }
  };

  const FilterButton = ({ type, label }: { type: TimeFilter, label: string }) => (
      <button 
        onClick={() => {
            setTimeFilter(type);
            setCustomStart('');
            setCustomEnd('');
        }}
        className={`px-3 py-1.5 text-xs md:text-sm font-medium rounded-md transition-all whitespace-nowrap ${
            timeFilter === type 
            ? 'bg-teal-600 text-white shadow-sm' 
            : 'bg-white text-gray-600 hover:bg-gray-100 border border-transparent'
        }`}
      >
          {label}
      </button>
  );

  return (
    <div className="space-y-6 pb-20 md:pb-0">
      <div className="flex flex-col xl:flex-row justify-between items-start xl:items-end gap-4">
        <div>
           <h1 className="text-2xl font-bold text-gray-800">Tài chính hệ thống</h1>
           <p className="text-sm text-gray-500">Báo cáo hiệu quả kinh doanh toàn hệ thống</p>
        </div>
        
        <div className="flex flex-col md:flex-row gap-3 w-full xl:w-auto">
            {/* Custom Date Inputs */}
            <div className="flex space-x-2 items-center bg-white p-1 rounded-lg border border-gray-200">
                <input 
                    type="date" 
                    className="rounded-md px-2 py-1 text-sm outline-none focus:text-teal-700 w-32"
                    value={customStart}
                    onChange={(e) => handleDateChange(e.target.value, customEnd)}
                    title="Từ ngày"
                />
                <span className="text-gray-400">-</span>
                <input 
                    type="date" 
                    className="rounded-md px-2 py-1 text-sm outline-none focus:text-teal-700 w-32"
                    value={customEnd}
                    onChange={(e) => handleDateChange(customStart, e.target.value)}
                    title="Đến ngày"
                />
            </div>

            {/* Time Filter Control */}
            <div className="bg-gray-100 p-1 rounded-lg flex overflow-x-auto no-scrollbar">
                <FilterButton type="day" label="Hôm nay" />
                <FilterButton type="week" label="Tuần này" />
                <FilterButton type="month" label="Tháng này" />
                <FilterButton type="quarter" label="Quý này" />
                <FilterButton type="year" label="Năm nay" />
                <FilterButton type="all" label="Tất cả" />
            </div>
        </div>
      </div>

      {/* GLOBAL FINANCIAL SUMMARY - UPDATED WITH TOTAL SYSTEM COST */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
          
          {/* 1. Tổng Doanh Thu */}
          <div className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm">
              <div className="flex items-center text-green-600 mb-2">
                  <ArrowUpCircle size={20} className="mr-2"/>
                  <span className="text-xs font-bold uppercase tracking-wide">Doanh Thu Hệ Thống</span>
              </div>
              <div className="text-xl md:text-2xl font-bold text-gray-800 truncate" title={formatCurrency(totalTourRevenue)}>
                  {formatCurrency(totalTourRevenue)}
              </div>
              <div className="text-xs text-gray-400 mt-1">Từ {filteredActiveBookings.length} bookings active</div>
          </div>

          {/* 2. Tổng Chi Phí Hệ Thống (MỚI: Gộp cả Tour + Chung) */}
          <div className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm">
              <div className="flex items-center text-red-600 mb-2">
                  <ArrowDownCircle size={20} className="mr-2"/>
                  <span className="text-xs font-bold uppercase tracking-wide">Tổng Chi Phí</span>
              </div>
              <div className="text-xl md:text-2xl font-bold text-gray-800 truncate" title={formatCurrency(totalSystemCost)}>
                  {formatCurrency(totalSystemCost)}
              </div>
              <div className="text-xs text-red-400 mt-1 flex flex-col">
                  <span>Tour: {formatCurrency(totalTourCost)}</span>
                  <span>Chung: {formatCurrency(totalGeneralCost)}</span>
              </div>
          </div>

          {/* 3. Lợi Nhuận Ròng (MỚI: Đã trừ hết chi phí chung) */}
          <div className={`p-4 rounded-xl border shadow-sm ${netProfit >= 0 ? 'bg-green-50 border-green-100' : 'bg-red-50 border-red-100'}`}>
              <div className={`flex items-center mb-2 ${netProfit >= 0 ? 'text-green-700' : 'text-red-700'}`}>
                  <Wallet size={20} className="mr-2"/>
                  <span className="text-xs font-bold uppercase tracking-wide">Lợi Nhuận Ròng</span>
              </div>
              <div className={`text-xl md:text-2xl font-bold truncate ${netProfit >= 0 ? 'text-green-800' : 'text-red-800'}`} title={formatCurrency(netProfit)}>
                  {formatCurrency(netProfit)}
              </div>
              <div className="text-xs opacity-70 mt-1">
                  Đã trừ CP chung & Tour
              </div>
          </div>

           {/* 4. Margin & Stats */}
          <div className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm">
              <div className="flex items-center text-blue-600 mb-2">
                  <TrendingUp size={20} className="mr-2"/>
                  <span className="text-xs font-bold uppercase tracking-wide">Biên Lợi Nhuận</span>
              </div>
              <div className={`text-xl md:text-2xl font-bold truncate ${netMargin >= 0 ? 'text-blue-700' : 'text-red-600'}`}>
                  {netMargin}%
              </div>
              <div className="text-xs text-gray-400 mt-1">Tỷ suất thực tế</div>
          </div>

          {/* 5. Reserved Fund */}
          <div className="bg-orange-50 p-4 rounded-xl border border-orange-100 shadow-sm">
              <div className="flex items-center text-orange-600 mb-2">
                  <Archive size={20} className="mr-2"/>
                  <span className="text-xs font-bold uppercase tracking-wide">Quỹ Bảo Lưu</span>
              </div>
              <div className="text-xl md:text-2xl font-bold text-orange-700 truncate" title={formatCurrency(totalReservedFund)}>
                  {formatCurrency(totalReservedFund)}
              </div>
              <div className="text-xs text-orange-500 mt-1">Chưa ghi nhận doanh thu</div>
          </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-gray-200">
          <button 
            onClick={() => setActiveTab('tours')}
            className={`px-6 py-3 font-medium text-sm transition-colors border-b-2 ${activeTab === 'tours' ? 'border-teal-500 text-teal-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
          >
              <TrendingUp size={16} className="inline mr-2 -mt-0.5"/> Hiệu quả Tour
          </button>
          <button 
            onClick={() => setActiveTab('general')}
            className={`px-6 py-3 font-medium text-sm transition-colors border-b-2 ${activeTab === 'general' ? 'border-teal-500 text-teal-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
          >
              <Layers size={16} className="inline mr-2 -mt-0.5"/> Chi phí chung
          </button>
      </div>

      {activeTab === 'tours' && (
        <>
            {/* Chart */}
            <div className="bg-white p-4 md:p-6 rounded-xl border border-gray-100 shadow-sm">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-bold text-gray-800 flex items-center">
                        <Calendar size={18} className="mr-2 text-teal-600"/>
                        Biểu đồ hiệu quả từng Tour
                    </h3>
                </div>
                <div className="h-72 w-full">
                    {chartData.length > 0 ? (
                        <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={chartData} margin={{ top: 20, right: 0, left: 0, bottom: 5 }}>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                                <XAxis dataKey="name" tick={{fontSize: 12}} />
                                <YAxis tickFormatter={(val) => `${val/1000000}M`} width={40} tick={{fontSize: 12}}/>
                                <Tooltip formatter={(value: number) => formatCurrency(value)} />
                                <Legend />
                                <Bar dataKey="DoanhThu" fill="#0d9488" name="Doanh Thu" radius={[4, 4, 0, 0]} />
                                <Bar dataKey="ChiPhi" fill="#ef4444" name="Chi Phí" radius={[4, 4, 0, 0]} />
                                <Bar dataKey="LoiNhuan" fill="#3b82f6" name="Lợi Nhuận" radius={[4, 4, 0, 0]} />
                            </BarChart>
                        </ResponsiveContainer>
                    ) : (
                        <div className="h-full w-full flex flex-col items-center justify-center text-gray-400 text-sm text-center">
                            <Calendar size={32} className="mb-2 opacity-50"/>
                            <span>Không có tour nào trong khoảng thời gian này</span>
                        </div>
                    )}
                </div>
            </div>

            {/* Detailed Table */}
            <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
                <div className="p-4 border-b border-gray-100 flex justify-between items-center">
                    <h3 className="font-bold text-gray-800">Chi tiết các Tour trong kỳ</h3>
                    <span className="text-xs font-medium bg-gray-100 px-2 py-1 rounded text-gray-600">
                        {filteredTours.length} Tours
                    </span>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left">
                        <thead className="bg-gray-50 text-gray-600 font-semibold uppercase text-xs">
                            <tr>
                                <th className="px-4 py-3">Mã Tour</th>
                                <th className="px-4 py-3">Tên Tour</th>
                                <th className="px-4 py-3 text-center">Khách (Active)</th>
                                <th className="px-4 py-3 text-right">Doanh Thu</th>
                                <th className="px-4 py-3 text-right">Chi Phí Tour</th>
                                <th className="px-4 py-3 text-right">Lợi Nhuận Gộp</th>
                                <th className="px-4 py-3 text-right">Margin</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100">
                            {tourFinancials.map(t => (
                                <tr key={t.id} className="hover:bg-gray-50 transition-colors">
                                    <td className="px-4 py-3 font-mono text-gray-600">{t.code}</td>
                                    <td className="px-4 py-3 font-medium text-gray-800">
                                        {t.name}
                                        <div className="text-[10px] text-gray-400 font-normal">{new Date(t.startDate).toLocaleDateString('vi-VN')}</div>
                                    </td>
                                    <td className="px-4 py-3 text-center">{t.pax}</td>
                                    <td className="px-4 py-3 text-right text-teal-700">{formatCurrency(t.revenue)}</td>
                                    <td className="px-4 py-3 text-right text-red-600">{formatCurrency(t.cost)}</td>
                                    <td className="px-4 py-3 text-right font-bold text-blue-700">{formatCurrency(t.profit)}</td>
                                    <td className="px-4 py-3 text-right">
                                        <span className={`px-2 py-1 rounded text-xs font-bold ${t.margin >= 30 ? 'bg-green-100 text-green-700' : t.margin >= 10 ? 'bg-yellow-100 text-yellow-700' : 'bg-red-100 text-red-700'}`}>
                                            {t.margin}%
                                        </span>
                                    </td>
                                </tr>
                            ))}
                            {tourFinancials.length === 0 && (
                                <tr><td colSpan={7} className="text-center py-8 text-gray-400">Không có dữ liệu tour trong khoảng thời gian này</td></tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </>
      )}

      {activeTab === 'general' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Form Input */}
              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                  <h3 className="font-bold text-gray-800 mb-4 flex items-center">
                      <Plus size={18} className="mr-2 text-teal-600"/> Nhập chi phí chung
                  </h3>
                  <form onSubmit={handleAddGeneralExpense} className="space-y-4">
                      <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Ngày chi</label>
                          <input 
                              type="date" 
                              className="w-full border rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-teal-500"
                              required
                              value={generalForm.date}
                              onChange={e => setGeneralForm({...generalForm, date: e.target.value})}
                          />
                      </div>
                      <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Hạng mục (Nhập hoặc chọn)</label>
                          <input 
                              type="text"
                              list="expense-categories"
                              className="w-full border rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-teal-500 bg-white"
                              placeholder="VD: Văn phòng, Marketing..."
                              value={generalForm.category}
                              onChange={e => setGeneralForm({...generalForm, category: e.target.value})}
                              required
                          />
                          <datalist id="expense-categories">
                              <option value="Văn phòng">Văn phòng / Điện nước</option>
                              <option value="Marketing">Marketing / Ads</option>
                              <option value="Lương cứng">Lương nhân viên (Cứng)</option>
                              <option value="Thiết bị">Mua sắm thiết bị chung</option>
                              <option value="Khác">Khác</option>
                          </datalist>
                      </div>
                      <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Nội dung chi</label>
                          <input 
                              type="text" 
                              placeholder="VD: Thuê văn phòng T5..."
                              className="w-full border rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-teal-500"
                              required
                              value={generalForm.name}
                              onChange={e => setGeneralForm({...generalForm, name: e.target.value})}
                          />
                      </div>
                      <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Số tiền</label>
                          <input 
                              type="number" 
                              className="w-full border rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-teal-500"
                              required
                              value={generalForm.amount || ''}
                              onChange={e => setGeneralForm({...generalForm, amount: Number(e.target.value)})}
                          />
                      </div>
                      <button type="submit" className="w-full bg-teal-600 text-white py-2 rounded-lg font-bold hover:bg-teal-700 transition-colors shadow-sm">
                          Lưu khoản chi
                      </button>
                  </form>
              </div>

              {/* List */}
              <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden flex flex-col">
                  <div className="p-4 border-b border-gray-100 bg-gray-50 flex justify-between items-center">
                      <h3 className="font-bold text-gray-800">Danh sách chi phí chung (Kỳ này)</h3>
                      <div className="font-bold text-red-600 text-lg">
                          Tổng: {formatCurrency(totalGeneralCost)}
                      </div>
                  </div>
                  <div className="flex-1 overflow-auto max-h-[500px]">
                      <table className="w-full text-left text-sm">
                          <thead className="bg-white text-gray-500 sticky top-0 shadow-sm">
                              <tr>
                                  <th className="px-4 py-3 font-medium">Ngày</th>
                                  <th className="px-4 py-3 font-medium">Hạng mục</th>
                                  <th className="px-4 py-3 font-medium">Nội dung</th>
                                  <th className="px-4 py-3 font-medium text-right">Số tiền</th>
                                  <th className="px-4 py-3 font-medium text-center">Xóa</th>
                              </tr>
                          </thead>
                          <tbody className="divide-y divide-gray-100">
                              {filteredGeneralExpenses.map(item => (
                                  <tr key={item.id} className="hover:bg-gray-50">
                                      <td className="px-4 py-3 text-gray-600">{new Date(item.date).toLocaleDateString('vi-VN')}</td>
                                      <td className="px-4 py-3">
                                          <span className="bg-gray-100 text-gray-700 px-2 py-1 rounded text-xs font-medium">
                                              {item.category}
                                          </span>
                                      </td>
                                      <td className="px-4 py-3 text-gray-800">{item.name}</td>
                                      <td className="px-4 py-3 text-right font-bold text-red-600">{formatCurrency(item.amount)}</td>
                                      <td className="px-4 py-3 text-center">
                                          <button 
                                            onClick={() => deleteGeneralExpense(item.id)}
                                            className="text-red-300 hover:text-red-600 transition-colors"
                                          >
                                              <Trash2 size={16} />
                                          </button>
                                      </td>
                                  </tr>
                              ))}
                              {filteredGeneralExpenses.length === 0 && (
                                  <tr>
                                      <td colSpan={5} className="text-center py-10 text-gray-400">
                                          Chưa có chi phí chung nào trong khoảng thời gian này.
                                      </td>
                                  </tr>
                              )}
                          </tbody>
                      </table>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};
