
import React, { useState, useMemo } from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell,
  Legend,
  AreaChart,
  Area
} from 'recharts';
import { Users, DollarSign, AlertCircle, ArrowRight, Wallet, AlertTriangle, CheckCircle, X, Calendar, Download, Archive, Activity, Clock, List } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAppStore } from '../services/store';
import { formatCurrency, UserRole, SystemLog } from '../types';

export const Dashboard: React.FC = () => {
  const { bookings, users, tours, currentUser, updateBooking, systemLogs } = useAppStore();

  // State for Confirmation Modal
  const [confirmModal, setConfirmModal] = useState<{bookingId: string, customerName: string, missingAmount: number} | null>(null);
  
  // State for Time Filter
  const [timeFilter, setTimeFilter] = useState<'day' | 'month' | 'year' | 'custom'>('month');
  const [customStart, setCustomStart] = useState('');
  const [customEnd, setCustomEnd] = useState('');

  // State for Full Logs Modal
  const [isLogModalOpen, setIsLogModalOpen] = useState(false);

  // Calculate stats (Active Bookings Only for Revenue)
  const activeBookings = bookings.filter(b => (!b.status || b.status === 'ACTIVE'));
  const totalRevenue = activeBookings.reduce((sum, b) => sum + b.price, 0);
  const totalDeposit = activeBookings.reduce((sum, b) => sum + b.deposit, 0);
  const totalMissing = totalRevenue - totalDeposit;
  const totalPax = activeBookings.length;

  // Reserved Stats
  const reservedBookings = bookings.filter(b => b.status === 'RESERVED');
  const reservedCount = reservedBookings.length;
  const reservedDepositTotal = reservedBookings.reduce((sum, b) => sum + b.deposit, 0);

  // Alerts Logic
  const missingMoneyCount = activeBookings.filter(b => (b.price - b.deposit) > 0).length;
  const missingCCCDCount = activeBookings.filter(b => !b.cccd || b.cccd.trim() === '').length;

  // Filter Debtors (Khách còn thiếu tiền)
  const debtors = activeBookings
    .filter(b => (b.price - b.deposit) > 0)
    .sort((a, b) => (b.price - b.deposit) - (a.price - a.deposit))
    .slice(0, 5); // Top 5 on mobile is enough

  // Check Permissions: Admin or Accountant
  const canApprovePayment = currentUser && (
      currentUser.roles.includes(UserRole.ADMIN) || 
      currentUser.roles.includes(UserRole.ACCOUNTANT)
  );

  const handleFullDepositClick = (e: React.MouseEvent, bookingId: string) => {
    e.preventDefault();
    e.stopPropagation();
    const booking = bookings.find(b => b.id === bookingId);
    if (!booking) return;

    setConfirmModal({
        bookingId: booking.id,
        customerName: booking.customerName,
        missingAmount: booking.price - booking.deposit
    });
  };

  const confirmAction = () => {
      if (!confirmModal) return;
      const booking = bookings.find(b => b.id === confirmModal.bookingId);
      if (booking) {
          // Logic: Set deposit = price -> Remaining = 0 -> Disappears from list
          updateBooking({
              ...booking,
              deposit: booking.price 
          });
      }
      setConfirmModal(null);
  };

  const handleExportGeneralReport = () => {
      // Chuẩn bị dữ liệu Master Data để xuất Excel
      const headers = ["Mã Tour", "Tên Tour", "Ngày Khởi Hành", "Sale Phụ Trách", "Tên Khách Hàng", "Doanh Thu (Giá)", "Đã Thu", "Còn Thiếu"];
      
      const rows = activeBookings.map(b => {
          const tour = tours.find(t => t.id === b.tourInstanceId);
          const sale = users.find(u => u.id === b.saleId);
          const remaining = b.price - b.deposit;

          return [
              `"${tour?.code || ''}"`,
              `"${tour?.name || ''}"`,
              `"${tour?.startDate || ''}"`,
              `"${sale?.name || 'Không rõ'}"`,
              `"${b.customerName}"`,
              b.price,
              b.deposit,
              remaining
          ];
      });

      const csvContent = "\uFEFF" + [
          headers.join(","),
          ...rows.map(r => r.join(","))
      ].join("\n");

      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.setAttribute("href", url);
      const dateStr = new Date().toISOString().split('T')[0];
      link.setAttribute("download", `Bao_Cao_Tong_Hop_${dateStr}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
  };

  // --- CHART DATA PREPARATION ---

  // 1. Số khách theo Tour
  const tourPaxData = tours.map(tour => {
    const count = bookings.filter(b => b.tourInstanceId === tour.id && b.status !== 'RESERVED').length;
    return {
      name: tour.code, // Short name for XAxis
      fullName: tour.name,
      value: count
    };
  }).filter(t => t.value > 0)
    .sort((a, b) => b.value - a.value);

  // 2. Doanh thu theo Sale
  const saleRevenueData = users
    .filter(u => u.roles.includes(UserRole.SALE))
    .map(sale => {
        const saleBookings = bookings.filter(b => b.saleId === sale.id && b.status !== 'RESERVED');
        const revenue = saleBookings.reduce((sum, b) => sum + b.price, 0);
        return {
            name: sale.name, // Full name or split for chart
            shortName: sale.name.split(' ').pop(), // Last name for XAxis
            value: revenue
        };
    })
    .filter(item => item.value > 0)
    .sort((a, b) => b.value - a.value);

  // 3. Doanh thu theo Thời gian (New Feature)
  const timeData = useMemo(() => {
      const dataMap = new Map();

      bookings.filter(b => b.status !== 'RESERVED').forEach(b => {
          const tour = tours.find(t => t.id === b.tourInstanceId);
          if(!tour) return;
          const date = new Date(tour.startDate);
          
          // --- Filter Range Logic ---
          if (timeFilter === 'custom') {
              if (customStart) {
                  const start = new Date(customStart);
                  if (date < start) return;
              }
              if (customEnd) {
                  const end = new Date(customEnd);
                  end.setHours(23, 59, 59, 999);
                  if (date > end) return;
              }
          }

          let key = '';
          let label = '';
          let sortTime = 0;

          if(timeFilter === 'day' || timeFilter === 'custom') {
              key = tour.startDate; // YYYY-MM-DD
              label = `${date.getDate()}/${date.getMonth()+1}`;
              sortTime = date.getTime();
          } else if (timeFilter === 'month') {
              key = `${date.getFullYear()}-${date.getMonth()}`;
              label = `T${date.getMonth()+1}/${date.getFullYear()}`;
              sortTime = new Date(date.getFullYear(), date.getMonth(), 1).getTime();
          } else {
              key = `${date.getFullYear()}`;
              label = `${date.getFullYear()}`;
              sortTime = new Date(date.getFullYear(), 0, 1).getTime();
          }

          if(!dataMap.has(key)) {
              dataMap.set(key, { name: label, revenue: 0, pax: 0, sortTime });
          }
          const entry = dataMap.get(key);
          entry.revenue += b.price;
          entry.pax += 1;
      });

      return Array.from(dataMap.values()).sort((a, b) => a.sortTime - b.sortTime);
  }, [bookings, tours, timeFilter, customStart, customEnd]);

  const COLORS = ['#0d9488', '#0ea5e9', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

  // Custom Tooltip for Money
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-2 border border-gray-200 shadow-md rounded text-xs">
          <p className="font-bold">{label}</p>
          <p className="text-teal-600">
            Doanh thu: {formatCurrency(payload[0].value)}
          </p>
          {payload[1] && (
              <p className="text-blue-600">
                  Số khách: {payload[1].value}
              </p>
          )}
        </div>
      );
    }
    return null;
  };

  const handleDateChange = (start: string, end: string) => {
      setCustomStart(start);
      setCustomEnd(end);
      if (start || end) {
          setTimeFilter('custom');
      }
  };

  // Helper for System Log Rendering
  const getLogColor = (type: SystemLog['type']) => {
      switch(type) {
          case 'success': return 'bg-green-100 text-green-700';
          case 'warning': return 'bg-yellow-100 text-yellow-700';
          case 'danger': return 'bg-red-100 text-red-700';
          default: return 'bg-blue-100 text-blue-700';
      }
  };

  // Limited logs for widget
  const widgetLogs = systemLogs.slice(0, 10);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <h1 className="text-xl md:text-2xl font-bold text-gray-800">Tổng quan</h1>
        
        {/* Export Button */}
        {(currentUser?.roles.includes(UserRole.ADMIN) || currentUser?.roles.includes(UserRole.ACCOUNTANT)) && (
            <button 
                onClick={handleExportGeneralReport}
                className="flex items-center space-x-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm font-medium shadow-sm transition-colors w-full md:w-auto justify-center"
            >
                <Download size={18} />
                <span>Xuất Báo cáo Tổng hợp</span>
            </button>
        )}
      </div>

      {/* Main Grid Layout: Left (Stats) - Right (Activity) */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        
        {/* LEFT COLUMN: Main Stats & Charts (75% on Desktop) */}
        <div className="lg:col-span-3 space-y-6">
            
            {/* MOBILE ALERTS */}
            <div className="grid grid-cols-2 gap-3 md:hidden">
                <div className="bg-red-50 p-4 rounded-xl border border-red-100 flex flex-col justify-between">
                    <div className="flex items-center text-red-600 mb-2">
                        <Wallet size={20} className="mr-2" />
                        <span className="font-bold text-xs uppercase">Thiếu tiền</span>
                    </div>
                    <div className="text-2xl font-bold text-gray-800">{missingMoneyCount} <span className="text-sm font-normal text-gray-500">khách</span></div>
                </div>
                <div className="bg-orange-50 p-4 rounded-xl border border-orange-100 flex flex-col justify-between">
                    <div className="flex items-center text-orange-600 mb-2">
                        <AlertTriangle size={20} className="mr-2" />
                        <span className="font-bold text-xs uppercase">Thiếu CCCD</span>
                    </div>
                    <div className="text-2xl font-bold text-gray-800">{missingCCCDCount} <span className="text-sm font-normal text-gray-500">khách</span></div>
                </div>
            </div>

            {/* Stat Cards */}
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3 md:gap-4">
                {/* ... Existing Stat Cards ... */}
                <div className="bg-white p-4 md:p-6 rounded-xl shadow-sm border border-gray-100 flex flex-col">
                    <div className="text-gray-500 text-xs md:text-sm font-medium mb-1">Tổng khách</div>
                    <div className="flex items-center justify-between">
                        <span className="text-2xl md:text-3xl font-bold text-gray-800">{totalPax}</span>
                        <div className="p-1.5 md:p-2 bg-blue-50 text-blue-600 rounded-lg">
                        <Users size={20} />
                        </div>
                    </div>
                </div>

                <div className="bg-white p-4 md:p-6 rounded-xl shadow-sm border border-gray-100 flex flex-col">
                    <div className="text-gray-500 text-xs md:text-sm font-medium mb-1">Doanh thu</div>
                    <div className="flex items-center justify-between">
                        <span className="text-lg md:text-2xl font-bold text-gray-800" title={formatCurrency(totalRevenue)}>{formatCurrency(totalRevenue).replace('₫', '')}</span>
                        <div className="p-1.5 md:p-2 bg-green-50 text-green-600 rounded-lg">
                        <DollarSign size={20} />
                        </div>
                    </div>
                </div>

                <div className="bg-white p-4 md:p-6 rounded-xl shadow-sm border border-gray-100 flex flex-col">
                    <div className="text-gray-500 text-xs md:text-sm font-medium mb-1">Đã thu</div>
                    <div className="flex items-center justify-between">
                        <span className="text-lg md:text-2xl font-bold text-teal-600" title={formatCurrency(totalDeposit)}>{formatCurrency(totalDeposit).replace('₫', '')}</span>
                        <div className="p-1.5 md:p-2 bg-teal-50 text-teal-600 rounded-lg">
                        <DollarSign size={20} />
                        </div>
                    </div>
                </div>

                <div className="bg-white p-4 md:p-6 rounded-xl shadow-sm border border-gray-100 flex flex-col">
                    <div className="text-gray-500 text-xs md:text-sm font-medium mb-1">Còn thiếu</div>
                    <div className="flex items-center justify-between">
                        <span className="text-lg md:text-2xl font-bold text-red-600" title={formatCurrency(totalMissing)}>{formatCurrency(totalMissing).replace('₫', '')}</span>
                        <div className="p-1.5 md:p-2 bg-red-50 text-red-600 rounded-lg">
                        <AlertCircle size={20} />
                        </div>
                    </div>
                </div>

                <div className="bg-gradient-to-br from-orange-50 to-white p-4 md:p-6 rounded-xl shadow-sm border border-orange-100 flex flex-col col-span-2 md:col-span-1">
                    <div className="text-orange-600 text-xs md:text-sm font-bold uppercase mb-1 flex items-center">
                        <Archive size={14} className="mr-1"/> Bảo lưu
                    </div>
                    <div className="flex flex-col justify-end h-full">
                        <div className="flex items-baseline space-x-2">
                            <span className="text-2xl font-bold text-orange-700">{reservedCount}</span>
                            <span className="text-xs text-orange-500">khách</span>
                        </div>
                        <div className="text-sm font-bold text-teal-600 mt-1">
                            Đã cọc: {formatCurrency(reservedDepositTotal)}
                        </div>
                    </div>
                </div>
            </div>

            {/* TIME SERIES CHART */}
            <div className="bg-white p-4 md:p-6 rounded-xl shadow-sm border border-gray-100">
                <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center mb-6 gap-3">
                    <h3 className="text-lg font-bold text-gray-800 flex items-center mb-2 xl:mb-0">
                        <Calendar size={18} className="mr-2 text-teal-600"/>
                        Thống kê theo thời gian
                    </h3>
                    
                    <div className="flex flex-col md:flex-row gap-2 w-full xl:w-auto">
                        <div className="flex space-x-2 items-center">
                            <input 
                                type="date" 
                                className="border border-gray-300 rounded-md px-2 py-1 text-sm outline-none focus:border-teal-500"
                                value={customStart}
                                onChange={(e) => handleDateChange(e.target.value, customEnd)}
                            />
                            <span className="text-gray-400">-</span>
                            <input 
                                type="date" 
                                className="border border-gray-300 rounded-md px-2 py-1 text-sm outline-none focus:border-teal-500"
                                value={customEnd}
                                onChange={(e) => handleDateChange(customStart, e.target.value)}
                            />
                        </div>

                        <div className="flex bg-gray-100 p-1 rounded-lg overflow-x-auto no-scrollbar">
                            <button onClick={() => { setTimeFilter('day'); setCustomStart(''); setCustomEnd(''); }} className={`px-3 py-1 text-xs md:text-sm rounded-md transition-all font-medium whitespace-nowrap ${timeFilter === 'day' ? 'bg-white text-teal-700 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}>Ngày</button>
                            <button onClick={() => { setTimeFilter('month'); setCustomStart(''); setCustomEnd(''); }} className={`px-3 py-1 text-xs md:text-sm rounded-md transition-all font-medium whitespace-nowrap ${timeFilter === 'month' ? 'bg-white text-teal-700 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}>Tháng</button>
                            <button onClick={() => { setTimeFilter('year'); setCustomStart(''); setCustomEnd(''); }} className={`px-3 py-1 text-xs md:text-sm rounded-md transition-all font-medium whitespace-nowrap ${timeFilter === 'year' ? 'bg-white text-teal-700 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}>Năm</button>
                        </div>
                    </div>
                </div>
                <div className="h-72">
                    <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={timeData} margin={{ top: 10, right: 0, left: 10, bottom: 0 }}>
                        <defs>
                        <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#0d9488" stopOpacity={0.1}/>
                            <stop offset="95%" stopColor="#0d9488" stopOpacity={0}/>
                        </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                        <XAxis dataKey="name" tick={{fontSize: 11}} interval="preserveStartEnd" />
                        <YAxis tickFormatter={(value) => `${value / 1000000}M`} width={40} tick={{fontSize: 10}} />
                        <Tooltip content={<CustomTooltip />} />
                        <Area type="monotone" dataKey="revenue" stroke="#0d9488" fillOpacity={1} fill="url(#colorRevenue)" strokeWidth={2} name="Doanh thu" />
                    </AreaChart>
                    </ResponsiveContainer>
                </div>
            </div>

            {/* CHARTS ROW */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white p-4 md:p-6 rounded-xl shadow-sm border border-gray-100">
                    <h3 className="text-lg font-bold text-gray-800 mb-4 text-center">Số khách theo Tour</h3>
                    <div className="h-64">
                        <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={tourPaxData} margin={{ top: 20, right: 10, left: 0, bottom: 5 }}>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} />
                            <XAxis dataKey="name" tick={{fontSize: 10}} interval={0} />
                            <YAxis allowDecimals={false} width={30} tick={{fontSize: 12}} />
                            <Tooltip />
                            <Bar dataKey="value" fill="#3b82f6" radius={[4, 4, 0, 0]} barSize={30}>
                            {tourPaxData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                            </Bar>
                        </BarChart>
                        </ResponsiveContainer>
                    </div>
                </div>

                <div className="bg-white p-4 md:p-6 rounded-xl shadow-sm border border-gray-100">
                    <h3 className="text-lg font-bold text-gray-800 mb-4 text-center">Tỷ trọng doanh thu theo Sale</h3>
                    <div className="h-64">
                        <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                                <Pie
                                    data={saleRevenueData}
                                    cx="50%"
                                    cy="50%"
                                    innerRadius={60}
                                    outerRadius={80}
                                    paddingAngle={5}
                                    dataKey="value"
                                >
                                    {saleRevenueData.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                    ))}
                                </Pie>
                                <Tooltip formatter={(value: number) => formatCurrency(value)} />
                                <Legend verticalAlign="bottom" height={36} iconType="circle" />
                            </PieChart>
                        </ResponsiveContainer>
                    </div>
                </div>
            </div>

            {/* Debt Table */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
                <div className="p-4 border-b border-gray-100 flex justify-between items-center">
                    <h3 className="text-base md:text-lg font-bold text-gray-800 flex items-center">
                        <AlertCircle className="text-red-500 mr-2" size={18}/>
                        <span className="hidden md:inline">Khách hàng còn thiếu tiền</span>
                        <span className="md:hidden">Khách nợ top 5</span>
                    </h3>
                </div>
                <div className="divide-y divide-gray-100">
                    {debtors.map(b => (
                        <div key={b.id} className="p-4 flex justify-between items-center hover:bg-red-50/20 transition-colors">
                            <div className="flex-1">
                                <div className="font-bold text-gray-800">{b.customerName}</div>
                                <div className="text-xs text-gray-500">{bookings.find(x => x.id === b.id)?.phone}</div>
                            </div>
                            <div className="text-right flex items-center space-x-3">
                                <div className="flex flex-col items-end">
                                    <div className="text-red-600 font-bold">{formatCurrency(b.price - b.deposit)}</div>
                                    <Link to={`/tours/${b.tourInstanceId}`} className="text-xs text-blue-500 flex items-center justify-end">
                                        Chi tiết <ArrowRight size={10} className="ml-1"/>
                                    </Link>
                                </div>
                                {canApprovePayment && (
                                    <button 
                                        onClick={(e) => handleFullDepositClick(e, b.id)}
                                        className="hidden md:flex items-center px-3 py-1.5 bg-green-100 text-green-700 text-xs rounded-lg hover:bg-green-200 transition-colors font-bold shadow-sm"
                                        title="Xác nhận khách đã đóng đủ tiền"
                                    >
                                        <CheckCircle size={14} className="mr-1"/> Đã cọc đủ
                                    </button>
                                )}
                            </div>
                            {canApprovePayment && (
                                <button 
                                    onClick={(e) => handleFullDepositClick(e, b.id)}
                                    className="md:hidden ml-2 p-2 bg-green-50 text-green-600 rounded-full shadow-sm active:scale-95 transition-transform"
                                    title="Xác nhận đã đóng đủ"
                                >
                                    <CheckCircle size={20}/>
                                </button>
                            )}
                        </div>
                    ))}
                    {debtors.length === 0 && (
                        <div className="p-6 text-center text-green-600 text-sm font-medium flex flex-col items-center">
                            <CheckCircle size={32} className="mb-2 opacity-50"/>
                            Tuyệt vời! Không còn khoản nợ nào.
                        </div>
                    )}
                </div>
            </div>
        </div>

        {/* RIGHT COLUMN: SYSTEM ACTIVITY LOG (25% on Desktop) */}
        <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 h-full flex flex-col max-h-[800px] sticky top-6">
                <div className="p-4 border-b border-gray-100 bg-gray-50 rounded-t-xl flex justify-between items-center shrink-0">
                    <h3 className="font-bold text-gray-800 flex items-center">
                        <Activity size={18} className="mr-2 text-indigo-600"/> Lịch sử hoạt động
                    </h3>
                    {systemLogs.length > 10 && (
                        <button 
                            onClick={() => setIsLogModalOpen(true)}
                            className="text-xs text-indigo-600 font-medium hover:underline flex items-center"
                        >
                            <List size={12} className="mr-1"/> Xem tất cả
                        </button>
                    )}
                </div>
                
                <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar">
                    {widgetLogs.map(log => (
                        <div key={log.id} className="flex gap-3 items-start group">
                            <div className="flex-shrink-0 mt-1">
                                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white shadow-sm ${getLogColor(log.type).replace('text-', 'bg-').replace('bg-', 'text-white ')}`}>
                                    {log.userName.charAt(0)}
                                </div>
                            </div>
                            <div className="flex-1 min-w-0">
                                <div className="flex justify-between items-start">
                                    <span className="text-xs font-bold text-gray-900 truncate pr-1">{log.userName}</span>
                                    <span className="text-[10px] text-gray-400 whitespace-nowrap flex items-center">
                                        <Clock size={10} className="mr-1"/>
                                        {new Date(log.timestamp).toLocaleTimeString('vi-VN', {hour: '2-digit', minute:'2-digit'})}
                                    </span>
                                </div>
                                <div className="text-xs text-indigo-600 font-medium mt-0.5">
                                    {log.action} <span className="text-gray-600 font-normal"> - {log.target}</span>
                                </div>
                                {log.detail && (
                                    <div className="text-[11px] text-gray-500 mt-1 bg-gray-50 p-1.5 rounded border border-gray-100 italic truncate group-hover:whitespace-normal group-hover:text-clip">
                                        {log.detail}
                                    </div>
                                )}
                                <div className="text-[10px] text-gray-300 mt-1">
                                    {new Date(log.timestamp).toLocaleDateString('vi-VN')}
                                </div>
                            </div>
                        </div>
                    ))}
                    {systemLogs.length === 0 && (
                        <div className="text-center py-10 text-gray-400 text-sm">
                            Chưa có hoạt động nào.
                        </div>
                    )}
                    {/* View All Button inside list if not empty */}
                    {systemLogs.length > 10 && (
                         <button 
                             onClick={() => setIsLogModalOpen(true)}
                             className="w-full py-2 text-xs text-center text-gray-500 hover:bg-gray-50 rounded border border-dashed border-gray-200"
                         >
                             + Xem thêm {systemLogs.length - 10} hoạt động cũ hơn
                         </button>
                    )}
                </div>
            </div>
        </div>

      </div>

      {/* CONFIRMATION MODAL */}
      {confirmModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-[100] flex items-center justify-center p-4 animate-in fade-in duration-200">
             <div className="bg-white rounded-xl shadow-2xl w-full max-w-sm overflow-hidden transform scale-100 transition-all">
                <div className="p-6">
                    <div className="flex justify-between items-start mb-4">
                         <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                            <CheckCircle className="text-green-600 w-6 h-6" />
                         </div>
                         <button onClick={() => setConfirmModal(null)} className="text-gray-400 hover:text-gray-600">
                             <X size={20} />
                         </button>
                    </div>
                    
                    <h3 className="text-xl font-bold text-gray-800 mb-2">Xác nhận thanh toán?</h3>
                    <p className="text-gray-600 mb-2">
                        Khách hàng: <span className="font-bold text-gray-800">{confirmModal.customerName}</span>
                    </p>
                    <p className="text-gray-600 mb-6 bg-gray-50 p-3 rounded-lg border border-gray-100">
                        Số tiền còn thiếu sẽ được tự động cập nhật:
                        <span className="block text-2xl font-bold text-green-600 mt-1">{formatCurrency(confirmModal.missingAmount)}</span>
                    </p>

                    <div className="flex space-x-3">
                        <button 
                            onClick={() => setConfirmModal(null)}
                            className="flex-1 px-4 py-3 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 font-bold transition-colors"
                        >
                            Hủy bỏ
                        </button>
                        <button 
                            onClick={confirmAction}
                            className="flex-1 px-4 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 font-bold shadow-md transition-colors"
                        >
                            Xác nhận
                        </button>
                    </div>
                </div>
             </div>
        </div>
      )}

      {/* FULL LOGS MODAL */}
      {isLogModalOpen && (
          <div className="fixed inset-0 bg-black bg-opacity-50 z-[120] flex items-center justify-center p-4">
              <div className="bg-white w-full max-w-2xl h-[80vh] rounded-xl shadow-2xl flex flex-col">
                  <div className="p-4 border-b border-gray-100 flex justify-between items-center bg-gray-50 rounded-t-xl shrink-0">
                      <h3 className="font-bold text-gray-800 text-lg flex items-center">
                          <Activity size={20} className="mr-2 text-indigo-600"/> Toàn bộ lịch sử hoạt động
                      </h3>
                      <button onClick={() => setIsLogModalOpen(false)} className="p-2 bg-gray-200 rounded-full text-gray-600 hover:bg-gray-300">
                          <X size={20}/>
                      </button>
                  </div>
                  <div className="flex-1 overflow-y-auto p-6 space-y-4">
                      {systemLogs.map(log => (
                        <div key={log.id} className="flex gap-4 items-start border-b border-gray-100 pb-4 last:border-0">
                            <div className="flex-shrink-0 mt-1">
                                <div className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold text-white shadow-sm ${getLogColor(log.type).replace('text-', 'bg-').replace('bg-', 'text-white ')}`}>
                                    {log.userName.charAt(0)}
                                </div>
                            </div>
                            <div className="flex-1 min-w-0">
                                <div className="flex justify-between items-start">
                                    <div>
                                        <span className="text-sm font-bold text-gray-900 mr-2">{log.userName}</span>
                                        <span className="text-xs text-gray-500 bg-gray-100 px-2 py-0.5 rounded">{log.userRole}</span>
                                    </div>
                                    <span className="text-xs text-gray-400 whitespace-nowrap">
                                        {new Date(log.timestamp).toLocaleString('vi-VN')}
                                    </span>
                                </div>
                                <div className="text-sm text-indigo-700 font-bold mt-1">
                                    {log.action} <span className="text-gray-700 font-normal"> - {log.target}</span>
                                </div>
                                {log.detail && (
                                    <div className="text-sm text-gray-600 mt-1 bg-gray-50 p-2 rounded border border-gray-100">
                                        {log.detail}
                                    </div>
                                )}
                            </div>
                        </div>
                      ))}
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};
