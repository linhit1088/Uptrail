
import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, 
  Calendar, 
  Users, 
  FileText, 
  Wallet,
  Box,
  Handshake,
  CalendarClock,
  Send,
  MessageSquare,
  Clock
} from 'lucide-react';
import { useAppStore } from '../services/store';
import { TourNote, UserRole } from '../types';
import { BookingTable } from '../components/BookingTable';
import { FinanceTab } from '../components/FinanceTab';
import { ChecklistTab } from '../components/ChecklistTab';
import { PartnerTab } from '../components/PartnerTab';
import { PlanTab } from '../components/PlanTab';

export const TourDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { tours, bookings, currentUser, addTourNote } = useAppStore();
  
  const [activeTab, setActiveTab] = useState<'bookings' | 'info' | 'checklist' | 'partners' | 'finances' | 'plans'>('bookings');
  
  // Note/Chat State
  const [noteInput, setNoteInput] = useState('');
  const chatContainerRef = useRef<HTMLDivElement>(null);

  const tour = tours.find(t => t.id === id);
  const tourBookings = bookings.filter(b => b.tourInstanceId === id);

  // Auto-scroll to bottom of chat
  useEffect(() => {
      if (activeTab === 'info' && chatContainerRef.current) {
          chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
      }
  }, [tour?.notes, activeTab]);

  if (!tour) {
    return <div>Tour not found</div>;
  }

  const handleSendNote = (e: React.FormEvent) => {
      e.preventDefault();
      if (!noteInput.trim()) return;

      const newNote: TourNote = {
          id: Math.random().toString(36).substr(2, 9),
          content: noteInput,
          authorName: currentUser?.name || 'Ẩn danh',
          timestamp: new Date().toISOString()
      };

      addTourNote(tour.id, newNote);
      setNoteInput('');
  };

  const totalPax = tourBookings.filter(b => b.status === 'ACTIVE').length;
  const totalRevenue = tourBookings.filter(b => b.status === 'ACTIVE').reduce((sum, b) => sum + b.price, 0);
  const totalDeposit = tourBookings.filter(b => b.status === 'ACTIVE').reduce((sum, b) => sum + b.deposit, 0);
  const totalMissing = totalRevenue - totalDeposit;
  
  const canViewFinance = currentUser?.roles.some(r => [UserRole.ADMIN, UserRole.OPS, UserRole.ACCOUNTANT].includes(r));
  const canViewChecklist = !currentUser?.roles.every(r => r === UserRole.SALE);
  const canViewPartners = !currentUser?.roles.every(r => r === UserRole.SALE);
  const canViewPlans = true;

  // Combine old generalNote (legacy) with new notes array
  const allNotes = [...(tour.notes || [])];
  if (tour.generalNote && !tour.notes?.length) {
      // Legacy support: Show old general note as first message
      allNotes.unshift({
          id: 'legacy',
          content: tour.generalNote,
          authorName: 'Hệ thống (Cũ)',
          timestamp: tour.startDate // Approximate
      });
  }

  return (
    <div className="space-y-4 md:space-y-6 pb-20 md:pb-0">
      {/* Header */}
      <div className="flex flex-col space-y-3 md:space-y-4">
        <button 
          onClick={() => navigate('/tours')} 
          className="flex items-center text-gray-500 hover:text-gray-800 transition-colors w-fit text-sm md:text-base"
        >
          <ArrowLeft size={18} className="mr-1" /> Quay lại
        </button>

        <div className="bg-white rounded-xl p-4 md:p-6 shadow-sm border border-gray-100">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-4 md:mb-6">
            <div>
              <div className="flex flex-wrap items-center gap-2 mb-1">
                <h1 className="text-xl md:text-3xl font-bold text-gray-800 leading-tight">{tour.name}</h1>
                <span className="px-2 py-0.5 md:px-3 md:py-1 bg-teal-100 text-teal-800 rounded-full text-[10px] md:text-xs font-bold uppercase tracking-wide whitespace-nowrap">
                  {tour.status}
                </span>
              </div>
              <div className="flex flex-wrap items-center text-gray-500 gap-4 text-xs md:text-sm">
                <span className="flex items-center"><Calendar size={14} className="mr-1" /> {new Date(tour.startDate).toLocaleDateString('vi-VN')}</span>
                <span className="flex items-center font-mono bg-gray-100 px-2 py-0.5 rounded">{tour.code}</span>
              </div>
            </div>
            
            {/* Mobile Summary Row */}
            <div className="flex w-full md:w-auto overflow-x-auto gap-3 pb-1 md:pb-0">
                <div className="flex-1 bg-gray-50 p-2 md:p-3 rounded-lg min-w-[80px] text-center border border-gray-100">
                    <div className="text-[10px] md:text-xs text-gray-500 uppercase font-semibold">Khách</div>
                    <div className="text-lg md:text-xl font-bold text-gray-800">{totalPax}</div>
                </div>
                <div className="flex-1 bg-gray-50 p-2 md:p-3 rounded-lg min-w-[100px] text-center border border-gray-100">
                    <div className="text-[10px] md:text-xs text-gray-500 uppercase font-semibold">Thiếu</div>
                    <div className={`text-lg md:text-xl font-bold ${totalMissing > 0 ? 'text-red-600' : 'text-green-600'}`}>
                        {(totalMissing / 1000000).toFixed(1)}M
                    </div>
                </div>
            </div>
          </div>

          {/* Scrollable Tabs Navigation */}
          <div className="flex border-b border-gray-200 overflow-x-auto no-scrollbar -mx-4 px-4 md:mx-0 md:px-0">
            <button
              onClick={() => setActiveTab('bookings')}
              className={`flex-none flex items-center px-4 md:px-6 py-3 border-b-2 font-medium transition-colors text-sm md:text-base ${
                activeTab === 'bookings' 
                  ? 'border-teal-500 text-teal-600' 
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              <Users size={16} className="mr-2" />
              DS Khách
            </button>
            
            <button
              onClick={() => setActiveTab('info')}
              className={`flex-none flex items-center px-4 md:px-6 py-3 border-b-2 font-medium transition-colors text-sm md:text-base ${
                activeTab === 'info' 
                  ? 'border-teal-500 text-teal-600' 
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              <MessageSquare size={16} className="mr-2" />
              Thảo luận
            </button>

            {canViewChecklist && (
                <button
                onClick={() => setActiveTab('checklist')}
                className={`flex-none flex items-center px-4 md:px-6 py-3 border-b-2 font-medium transition-colors text-sm md:text-base ${
                    activeTab === 'checklist' 
                    ? 'border-teal-500 text-teal-600' 
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
                >
                <Box size={16} className="mr-2" />
                Checklist
                </button>
            )}

            {canViewPartners && (
                <button
                onClick={() => setActiveTab('partners')}
                className={`flex-none flex items-center px-4 md:px-6 py-3 border-b-2 font-medium transition-colors text-sm md:text-base ${
                    activeTab === 'partners' 
                    ? 'border-teal-500 text-teal-600' 
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
                >
                <Handshake size={16} className="mr-2" />
                Đối tác
                </button>
            )}
            
            {canViewFinance && (
              <button
                onClick={() => setActiveTab('finances')}
                className={`flex-none flex items-center px-4 md:px-6 py-3 border-b-2 font-medium transition-colors text-sm md:text-base ${
                  activeTab === 'finances' 
                    ? 'border-teal-500 text-teal-600' 
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                <Wallet size={16} className="mr-2" />
                Thu/Chi
              </button>
            )}

            {canViewPlans && (
              <button
                onClick={() => setActiveTab('plans')}
                className={`flex-none flex items-center px-4 md:px-6 py-3 border-b-2 font-medium transition-colors text-sm md:text-base ${
                  activeTab === 'plans' 
                    ? 'border-teal-500 text-teal-600' 
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                <CalendarClock size={16} className="mr-2" />
                Kế hoạch
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Content Area */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 min-h-[500px]">
        {activeTab === 'bookings' && <BookingTable tourId={tour.id} />}
        
        {activeTab === 'info' && (
          <div className="flex flex-col h-[600px]">
             {/* Chat Area */}
             <div 
                ref={chatContainerRef}
                className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50/50"
             >
                 {allNotes.length === 0 ? (
                     <div className="text-center text-gray-400 py-10 flex flex-col items-center">
                         <MessageSquare size={40} className="mb-2 opacity-20"/>
                         <p>Chưa có ghi chú nào. Hãy bắt đầu thảo luận.</p>
                     </div>
                 ) : (
                     allNotes.map((note) => {
                         const isMe = note.authorName === currentUser?.name;
                         return (
                             <div key={note.id} className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}>
                                 <div className={`flex items-baseline space-x-2 mb-1 px-1 ${isMe ? 'flex-row-reverse space-x-reverse' : ''}`}>
                                     <span className="text-xs font-bold text-gray-700">{note.authorName}</span>
                                     <span className="text-[10px] text-gray-400 flex items-center">
                                         {new Date(note.timestamp).toLocaleTimeString('vi-VN', {hour: '2-digit', minute:'2-digit'})} 
                                         <span className="mx-1">•</span> 
                                         {new Date(note.timestamp).toLocaleDateString('vi-VN', {day: '2-digit', month: '2-digit'})}
                                     </span>
                                 </div>
                                 <div className={`p-3 rounded-2xl max-w-[85%] md:max-w-[70%] text-sm whitespace-pre-wrap shadow-sm ${
                                     isMe 
                                     ? 'bg-teal-600 text-white rounded-tr-none' 
                                     : 'bg-white text-gray-800 border border-gray-200 rounded-tl-none'
                                 }`}>
                                     {note.content}
                                 </div>
                             </div>
                         );
                     })
                 )}
             </div>

             {/* Input Area */}
             <div className="p-4 bg-white border-t border-gray-200 shrink-0">
                 <form onSubmit={handleSendNote} className="flex gap-2">
                     <input 
                        type="text" 
                        className="flex-1 border border-gray-300 rounded-full px-4 py-2 text-sm focus:outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500"
                        placeholder="Nhập ghi chú điều hành..."
                        value={noteInput}
                        onChange={(e) => setNoteInput(e.target.value)}
                     />
                     <button 
                        type="submit" 
                        disabled={!noteInput.trim()}
                        className={`p-2 rounded-full transition-colors ${noteInput.trim() ? 'bg-teal-600 text-white hover:bg-teal-700 shadow-md' : 'bg-gray-100 text-gray-400'}`}
                     >
                         <Send size={20} className="ml-0.5"/>
                     </button>
                 </form>
             </div>
          </div>
        )}

        {canViewChecklist && activeTab === 'checklist' && <ChecklistTab tourId={tour.id} />}
        
        {canViewPartners && activeTab === 'partners' && <PartnerTab tourId={tour.id} />}

        {canViewFinance && activeTab === 'finances' && <FinanceTab tourId={tour.id} />}

        {canViewPlans && activeTab === 'plans' && <PlanTab tourId={tour.id} />}
      </div>
    </div>
  );
};
