
import React from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AppProvider, useAppStore } from './services/store';
import { Layout } from './components/Layout';
import { Dashboard } from './pages/Dashboard';
import { TourList } from './pages/TourList';
import { TourDetail } from './pages/TourDetail';
import { Login } from './pages/Login';
import { UserManagement } from './pages/UserManagement';
import { CustomerList } from './pages/CustomerList';
import { FinancePage } from './pages/FinancePage';
import { ReservationList } from './pages/ReservationList';

const ProtectedRoute: React.FC<{ children: React.ReactElement }> = ({ children }) => {
  const { isAuthenticated } = useAppStore();
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  return <Layout>{children}</Layout>;
};

const App: React.FC = () => {
  return (
    <AppProvider>
      <Router>
        <Routes>
          <Route path="/login" element={<Login />} />
          
          <Route path="/" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
          <Route path="/tours" element={<ProtectedRoute><TourList /></ProtectedRoute>} />
          <Route path="/tours/:id" element={<ProtectedRoute><TourDetail /></ProtectedRoute>} />
          <Route path="/finance" element={<ProtectedRoute><FinancePage /></ProtectedRoute>} />
          <Route path="/customers" element={<ProtectedRoute><CustomerList /></ProtectedRoute>} />
          <Route path="/settings" element={<ProtectedRoute><UserManagement /></ProtectedRoute>} />
          <Route path="/reservations" element={<ProtectedRoute><ReservationList /></ProtectedRoute>} />
          
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Router>
    </AppProvider>
  );
};

export default App;
