
import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { Booking, ExpenseItem, TourInstance, TourType, User, UserRole, ChecklistItem, Customer, Partner, PlanItem, GeneralExpense, TourNote, SystemLog } from '../types';
import { MOCK_BOOKINGS, MOCK_EXPENSES, MOCK_TOURS, MOCK_TOUR_TYPES, MOCK_USERS, MOCK_CHECKLIST, MOCK_CUSTOMERS, MOCK_PARTNERS, MOCK_PLANS, MOCK_GENERAL_EXPENSES, MOCK_SYSTEM_LOGS } from './mockData';

interface AppState {
  currentUser: User | null;
  users: User[];
  tourTypes: TourType[];
  tours: TourInstance[];
  bookings: Booking[];
  expenses: ExpenseItem[];
  generalExpenses: GeneralExpense[]; // New
  checklists: ChecklistItem[];
  customers: Customer[];
  partners: Partner[];
  plans: PlanItem[];
  systemLogs: SystemLog[]; // New
  isAuthenticated: boolean;
}

interface AppContextType extends AppState {
  login: (username: string, pass: string) => boolean;
  logout: () => void;
  addUser: (user: User) => void;
  updateUser: (user: User) => void;
  deleteUser: (id: string) => void;
  
  addTour: (tour: TourInstance) => void;
  updateTour: (tour: TourInstance) => void;
  deleteTour: (id: string) => void;
  addTourNote: (tourId: string, note: TourNote) => void; // New

  addBooking: (booking: Booking) => void;
  updateBooking: (booking: Booking) => void;
  deleteBooking: (id: string) => void;

  addExpense: (expense: ExpenseItem) => void;
  updateExpense: (expense: ExpenseItem) => void; // New method for better logging
  deleteExpense: (id: string) => void;

  addGeneralExpense: (expense: GeneralExpense) => void; // New
  deleteGeneralExpense: (id: string) => void; // New

  addChecklistItem: (item: ChecklistItem) => void;
  updateChecklistItem: (item: ChecklistItem) => void;
  deleteChecklistItem: (id: string) => void;

  addPartner: (partner: Partner) => void;
  deletePartner: (id: string) => void;

  addPlan: (plan: PlanItem) => void;
  deletePlan: (id: string) => void;

  updateCustomer: (customer: Customer) => void;
  deleteCustomer: (id: string) => void;
  
  addLog: (action: string, target: string, detail?: string, type?: 'info'|'warning'|'danger'|'success') => void; // New
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Auth State
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  
  // Data State
  const [users, setUsers] = useState<User[]>(MOCK_USERS);
  const [tourTypes] = useState<TourType[]>(MOCK_TOUR_TYPES);
  const [tours, setTours] = useState<TourInstance[]>(MOCK_TOURS);
  const [bookings, setBookings] = useState<Booking[]>(MOCK_BOOKINGS);
  const [expenses, setExpenses] = useState<ExpenseItem[]>(MOCK_EXPENSES);
  const [generalExpenses, setGeneralExpenses] = useState<GeneralExpense[]>(MOCK_GENERAL_EXPENSES);
  const [checklists, setChecklists] = useState<ChecklistItem[]>(MOCK_CHECKLIST);
  const [customers, setCustomers] = useState<Customer[]>(MOCK_CUSTOMERS);
  const [partners, setPartners] = useState<Partner[]>(MOCK_PARTNERS);
  const [plans, setPlans] = useState<PlanItem[]>(MOCK_PLANS);
  const [systemLogs, setSystemLogs] = useState<SystemLog[]>(MOCK_SYSTEM_LOGS);

  // Helper: Format Currency for Logs
  const formatMoney = (amount: number) => new Intl.NumberFormat('vi-VN').format(amount);

  // Helper: Add Log
  const addLog = (action: string, target: string, detail: string = '', type: 'info'|'warning'|'danger'|'success' = 'info') => {
      if (!currentUser) return;
      const newLog: SystemLog = {
          id: Math.random().toString(36).substr(2, 9),
          userId: currentUser.id,
          userName: currentUser.name,
          userRole: currentUser.roles[0], // Primary role
          action,
          target,
          detail,
          timestamp: new Date().toISOString(),
          type
      };
      setSystemLogs(prev => [newLog, ...prev]);
  };

  // Auth Actions
  const login = (username: string, pass: string) => {
    const user = users.find(u => u.username === username && u.password === pass);
    if (user) {
      setCurrentUser(user);
      setIsAuthenticated(true);
      
      const loginLog: SystemLog = {
          id: Math.random().toString(36).substr(2, 9),
          userId: user.id,
          userName: user.name,
          userRole: user.roles[0],
          action: 'Đăng nhập',
          target: 'Hệ thống',
          timestamp: new Date().toISOString(),
          type: 'info'
      };
      setSystemLogs(prev => [loginLog, ...prev]);
      return true;
    }
    return false;
  };

  const logout = () => {
    addLog('Đăng xuất', 'Hệ thống');
    setCurrentUser(null);
    setIsAuthenticated(false);
  };

  // User Management Actions
  const addUser = (user: User) => {
    setUsers(prev => [...prev, user]);
    addLog('Thêm User', user.name, `Role: ${user.roles.join(', ')}`);
  };

  const updateUser = (updatedUser: User) => {
    setUsers(prev => prev.map(u => u.id === updatedUser.id ? updatedUser : u));
    if (currentUser && currentUser.id === updatedUser.id) {
        setCurrentUser(updatedUser);
    }
    addLog('Cập nhật User', updatedUser.name);
  };

  const deleteUser = (id: string) => {
    const u = users.find(x => x.id === id);
    setUsers(prev => prev.filter(u => u.id !== id));
    addLog('Xóa User', u?.name || id, '', 'danger');
  };

  // Tour Actions
  const addTour = (tour: TourInstance) => {
    setTours(prev => [tour, ...prev]);
    addLog('Tạo Tour', tour.name, `Mã: ${tour.code}`, 'success');
  };

  const updateTour = (updatedTour: TourInstance) => {
    const oldTour = tours.find(t => t.id === updatedTour.id);
    setTours(prev => prev.map(t => t.id === updatedTour.id ? updatedTour : t));
    
    // Log details
    if(oldTour) {
        const changes: string[] = [];
        if(oldTour.name !== updatedTour.name) changes.push(`Tên: ${oldTour.name} -> ${updatedTour.name}`);
        if(oldTour.startDate !== updatedTour.startDate) changes.push(`Ngày: ${oldTour.startDate} -> ${updatedTour.startDate}`);
        if(oldTour.status !== updatedTour.status) changes.push(`Trạng thái: ${oldTour.status} -> ${updatedTour.status}`);
        if(oldTour.leaderId !== updatedTour.leaderId) {
            const oldLeader = users.find(u => u.id === oldTour.leaderId)?.name || 'Chưa có';
            const newLeader = users.find(u => u.id === updatedTour.leaderId)?.name || 'Chưa có';
            changes.push(`Leader: ${oldLeader} -> ${newLeader}`);
        }
        if(changes.length > 0) {
            addLog('Sửa Tour', updatedTour.code, changes.join('; '), 'warning');
        } else {
            addLog('Cập nhật Tour', updatedTour.code);
        }
    }
  };

  const deleteTour = (id: string) => {
    const t = tours.find(x => x.id === id);
    setTours(prev => prev.filter(t => t.id !== id));
    addLog('Xóa Tour', t?.code || id, t?.name, 'danger');
  };

  const addTourNote = (tourId: string, note: TourNote) => {
      setTours(prev => prev.map(t => {
          if (t.id === tourId) {
              return { ...t, notes: [...(t.notes || []), note] };
          }
          return t;
      }));
  };

  // Helper to sync booking to customer list
  const syncCustomerFromBooking = (booking: Booking, allCustomers: Customer[]) => {
    const existingIndex = allCustomers.findIndex(c => c.phone === booking.phone);
    if (existingIndex >= 0) {
        const updatedCustomers = [...allCustomers];
        updatedCustomers[existingIndex] = {
            ...updatedCustomers[existingIndex],
            name: booking.customerName,
            cccd: booking.cccd || updatedCustomers[existingIndex].cccd,
            birthDate: booking.birthDate || updatedCustomers[existingIndex].birthDate,
            hometown: booking.hometown || updatedCustomers[existingIndex].hometown,
        };
        return updatedCustomers;
    } else {
        const newCustomer: Customer = {
            id: Math.random().toString(36).substr(2, 9),
            name: booking.customerName,
            phone: booking.phone,
            cccd: booking.cccd,
            birthDate: booking.birthDate,
            hometown: booking.hometown,
            notes: booking.note,
        };
        return [newCustomer, ...allCustomers];
    }
  };

  // Booking Actions
  const addBooking = (booking: Booking) => {
    setBookings(prev => [booking, ...prev]);
    setCustomers(prev => syncCustomerFromBooking(booking, prev));
    
    const tour = tours.find(t => t.id === booking.tourInstanceId);
    addLog('Thêm Booking', booking.customerName, `Tour: ${tour?.code} | Giá: ${formatMoney(booking.price)}`, 'success');
  };

  const updateBooking = (updatedBooking: Booking) => {
    const oldBooking = bookings.find(b => b.id === updatedBooking.id);

    setBookings(prev => prev.map(b => b.id === updatedBooking.id ? updatedBooking : b));
    setCustomers(prev => syncCustomerFromBooking(updatedBooking, prev));
    
    // --- DETAILED LOGGING LOGIC ---
    if (oldBooking) {
         const oldTour = tours.find(t => t.id === oldBooking.tourInstanceId);
         const newTour = tours.find(t => t.id === updatedBooking.tourInstanceId);
         const changes: string[] = [];

         // 1. Status Changes
         if (oldBooking.status === 'ACTIVE' && updatedBooking.status === 'RESERVED') {
             addLog('Bảo lưu', updatedBooking.customerName, `Chuyển khách sang danh sách bảo lưu (Tour cũ: ${oldTour?.code})`, 'warning');
             return; // Exit early for major status changes
         } else if (oldBooking.status === 'RESERVED' && updatedBooking.status === 'ACTIVE') {
             addLog('Khôi phục', updatedBooking.customerName, `Khôi phục từ bảo lưu vào tour ${newTour?.code}`, 'success');
             return;
         }

         // 2. Transfer Tour
         if (oldBooking.tourInstanceId !== updatedBooking.tourInstanceId) {
             addLog('Chuyển Tour', updatedBooking.customerName, `${oldTour?.code} -> ${newTour?.code}`, 'warning');
             return;
         }

         // 3. Detail Changes
         if (oldBooking.customerName !== updatedBooking.customerName) {
             changes.push(`Tên: ${oldBooking.customerName} -> ${updatedBooking.customerName}`);
         }
         if (oldBooking.phone !== updatedBooking.phone) {
             changes.push(`SĐT: ${oldBooking.phone} -> ${updatedBooking.phone}`);
         }
         if (oldBooking.price !== updatedBooking.price) {
             changes.push(`Giá chốt: ${formatMoney(oldBooking.price)} -> ${formatMoney(updatedBooking.price)}`);
         }
         if (oldBooking.deposit !== updatedBooking.deposit) {
             changes.push(`Đã cọc: ${formatMoney(oldBooking.deposit)} -> ${formatMoney(updatedBooking.deposit)}`);
         }
         if (oldBooking.saleId !== updatedBooking.saleId) {
             const oldSale = users.find(u => u.id === oldBooking.saleId)?.name || 'Trống';
             const newSale = users.find(u => u.id === updatedBooking.saleId)?.name || 'Trống';
             changes.push(`Sale: ${oldSale} -> ${newSale}`);
         }
         if (oldBooking.pickupPoint !== updatedBooking.pickupPoint) {
             changes.push(`Điểm đón: ${oldBooking.pickupPoint || '---'} -> ${updatedBooking.pickupPoint || '---'}`);
         }
         if (oldBooking.note !== updatedBooking.note) {
             changes.push(`Ghi chú: "${oldBooking.note || ''}" -> "${updatedBooking.note || ''}"`);
         }
         if (oldBooking.cccd !== updatedBooking.cccd) {
             changes.push(`CCCD: ${oldBooking.cccd || '---'} -> ${updatedBooking.cccd || '---'}`);
         }

         if (changes.length > 0) {
             addLog('Sửa Booking', updatedBooking.customerName, changes.join('; '), 'info');
         }
    }
  };

  const deleteBooking = (id: string) => {
    const b = bookings.find(x => x.id === id);
    setBookings(prev => prev.filter(b => b.id !== id));
    addLog('Xóa Booking', b?.customerName || id, `Đã xóa khách khỏi tour`, 'danger');
  };

  // Expense Actions
  const addExpense = (expense: ExpenseItem) => {
    setExpenses(prev => [expense, ...prev]);
    const total = formatMoney(expense.quantity * expense.unitPrice);
    addLog('Thêm Chi phí', expense.name, `${expense.type}: ${total} (${expense.category})`, 'warning');
  };

  const updateExpense = (updatedExpense: ExpenseItem) => {
      const oldExpense = expenses.find(e => e.id === updatedExpense.id);
      setExpenses(prev => prev.map(e => e.id === updatedExpense.id ? updatedExpense : e));

      if (oldExpense) {
          const changes: string[] = [];
          const oldTotal = oldExpense.quantity * oldExpense.unitPrice;
          const newTotal = updatedExpense.quantity * updatedExpense.unitPrice;

          if (oldExpense.name !== updatedExpense.name) changes.push(`Tên: ${oldExpense.name} -> ${updatedExpense.name}`);
          if (oldTotal !== newTotal) changes.push(`Số tiền: ${formatMoney(oldTotal)} -> ${formatMoney(newTotal)}`);
          if (oldExpense.type !== updatedExpense.type) changes.push(`Loại: ${oldExpense.type} -> ${updatedExpense.type}`);
          if (oldExpense.category !== updatedExpense.category) changes.push(`Nhóm: ${oldExpense.category} -> ${updatedExpense.category}`);
          
          if (changes.length > 0) {
              addLog('Sửa Chi phí', updatedExpense.name, changes.join('; '), 'warning');
          }
      }
  };

  const deleteExpense = (id: string) => {
    const e = expenses.find(x => x.id === id);
    setExpenses(prev => prev.filter(e => e.id !== id));
    if (e) {
        const total = formatMoney(e.quantity * e.unitPrice);
        addLog('Xóa Chi phí', e.name, `Đã xóa khoản ${total}`, 'danger');
    }
  };

  // General Expense Actions
  const addGeneralExpense = (expense: GeneralExpense) => {
      setGeneralExpenses(prev => [expense, ...prev]);
      addLog('Thêm CP Chung', expense.name, `Số tiền: ${formatMoney(expense.amount)} (${expense.category})`, 'warning');
  };

  const deleteGeneralExpense = (id: string) => {
      const e = generalExpenses.find(x => x.id === id);
      setGeneralExpenses(prev => prev.filter(e => e.id !== id));
      addLog('Xóa CP Chung', e?.name || id, e ? `Số tiền: ${formatMoney(e.amount)}` : '', 'danger');
  };

  // Checklist Actions
  const addChecklistItem = (item: ChecklistItem) => {
    setChecklists(prev => [...prev, item]);
    addLog('Thêm Checklist', item.name);
  };

  const updateChecklistItem = (updatedItem: ChecklistItem) => {
    setChecklists(prev => prev.map(c => c.id === updatedItem.id ? updatedItem : c));
  };

  const deleteChecklistItem = (id: string) => {
    const c = checklists.find(i => i.id === id);
    setChecklists(prev => prev.filter(c => c.id !== id));
    if(c) addLog('Xóa Checklist', c.name);
  };

  // Partner Actions
  const addPartner = (partner: Partner) => {
    setPartners(prev => [...prev, partner]);
    addLog('Thêm Đối tác', partner.name, partner.category);
  };

  const deletePartner = (id: string) => {
    const p = partners.find(x => x.id === id);
    setPartners(prev => prev.filter(p => p.id !== id));
    addLog('Xóa Đối tác', p?.name || id, '', 'danger');
  };

  // Plan Actions
  const addPlan = (plan: PlanItem) => {
    setPlans(prev => [...prev, plan]);
    addLog('Thêm Kế hoạch', `Ngày ${plan.day} - ${plan.time}`, plan.content);
  };

  const deletePlan = (id: string) => {
    const p = plans.find(x => x.id === id);
    setPlans(prev => prev.filter(p => p.id !== id));
    if(p) addLog('Xóa Kế hoạch', `Ngày ${p.day}`, p.content, 'danger');
  };

  // Customer Actions
  const updateCustomer = (updatedCustomer: Customer) => {
    const oldCustomer = customers.find(c => c.id === updatedCustomer.id);
    setCustomers(prev => prev.map(c => c.id === updatedCustomer.id ? updatedCustomer : c));
    
    if (oldCustomer) {
        const changes: string[] = [];
        if(oldCustomer.name !== updatedCustomer.name) changes.push(`Tên: ${oldCustomer.name} -> ${updatedCustomer.name}`);
        if(oldCustomer.phone !== updatedCustomer.phone) changes.push(`SĐT: ${oldCustomer.phone} -> ${updatedCustomer.phone}`);
        if(oldCustomer.notes !== updatedCustomer.notes) changes.push(`Note: ${oldCustomer.notes} -> ${updatedCustomer.notes}`);
        
        if (changes.length > 0) addLog('Sửa HS Khách', updatedCustomer.name, changes.join('; '));
    }
  };

  const deleteCustomer = (id: string) => {
    const c = customers.find(x => x.id === id);
    setCustomers(prev => prev.filter(c => c.id !== id));
    addLog('Xóa HS Khách', c?.name || id, '', 'danger');
  };

  return (
    <AppContext.Provider value={{
      currentUser,
      users,
      tourTypes,
      tours,
      bookings,
      expenses,
      generalExpenses,
      checklists,
      customers,
      partners,
      plans,
      systemLogs,
      isAuthenticated,
      login,
      logout,
      addUser,
      updateUser,
      deleteUser,
      addTour,
      updateTour,
      deleteTour,
      addTourNote,
      addBooking,
      updateBooking,
      deleteBooking,
      addExpense,
      updateExpense,
      deleteExpense,
      addGeneralExpense,
      deleteGeneralExpense,
      addChecklistItem,
      updateChecklistItem,
      deleteChecklistItem,
      addPartner,
      deletePartner,
      addPlan,
      deletePlan,
      updateCustomer,
      deleteCustomer,
      addLog
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useAppStore = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useAppStore must be used within an AppProvider');
  }
  return context;
};
