import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Map, 
  Users, 
  Settings, 
  LogOut,
  Mountain,
  Menu,
  Banknote
} from 'lucide-react';
import { useAppStore } from '../services/store';
import { UserRole } from '../types';

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser, logout } = useAppStore();
  const location = useLocation();
  const navigate = useNavigate();

  // If not logged in, content shouldn't be visible
  if (!currentUser) return null;

  const isActive = (path: string) => location.pathname === path || (path !== '/' && location.pathname.startsWith(path));

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const navItems = [
    { path: '/', icon: LayoutDashboard, label: 'Tổng quan' },
    { path: '/tours', icon: Map, label: 'Tour' },
    { path: '/finance', icon: Banknote, label: 'Tài chính' },
    { path: '/customers', icon: Users, label: 'Khách' },
  ];

  return (
    <div className="flex h-screen bg-gray-50 flex-col md:flex-row">
      {/* Desktop Sidebar (Hidden on Mobile) */}
      <aside className="hidden md:flex w-64 bg-slate-900 text-white flex-col fixed h-full z-20">
        <div className="p-6 border-b border-slate-700">
           <div className="flex items-center space-x-2">
                <div className="bg-white p-1 rounded-lg">
                    <Mountain className="w-8 h-8 text-teal-700" />
                </div>
                <div className="flex flex-col">
                    <span className="font-bold text-lg leading-tight text-white tracking-wide">UPTRAIL OPS</span>
                    <span className="text-[10px] text-teal-400 uppercase tracking-widest">Adventure Management</span>
                </div>
           </div>
        </div>

        <nav className="flex-1 px-4 py-6 space-y-2">
          {navItems.map((item) => (
            <Link 
              key={item.path}
              to={item.path} 
              className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${isActive(item.path) ? 'bg-teal-600 text-white' : 'text-slate-300 hover:bg-slate-800 hover:text-white'}`}
            >
              <item.icon size={20} />
              <span>{item.label}</span>
            </Link>
          ))}
          
          {currentUser.roles.includes(UserRole.ADMIN) && (
            <Link 
              to="/settings" 
              className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${isActive('/settings') ? 'bg-teal-600 text-white' : 'text-slate-300 hover:bg-slate-800 hover:text-white'}`}
            >
              <Settings size={20} />
              <span>Cài đặt</span>
            </Link>
          )}
        </nav>

        <div className="p-4 border-t border-slate-700 bg-slate-800">
          <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2 overflow-hidden">
                <div className="w-8 h-8 rounded-full bg-teal-500 flex items-center justify-center font-bold flex-shrink-0 text-white">
                  {currentUser.name.charAt(0)}
                </div>
                <div className="text-left overflow-hidden">
                  <div className="text-sm font-medium truncate w-32">{currentUser.name}</div>
                  <div className="text-xs text-teal-400 truncate">{currentUser.roles.join(', ')}</div>
                </div>
              </div>
              <button onClick={handleLogout} className="text-slate-400 hover:text-white p-1" title="Đăng xuất">
                 <LogOut size={18} />
              </button>
          </div>
        </div>
      </aside>

      {/* Mobile Top Bar */}
      <div className="md:hidden fixed top-0 left-0 right-0 bg-slate-900 text-white z-20 px-4 py-3 flex justify-between items-center shadow-md">
           <div className="flex items-center space-x-2">
                <div className="bg-white p-1 rounded-lg">
                    <Mountain className="w-6 h-6 text-teal-700" />
                </div>
                <span className="font-bold text-lg">UPTRAIL OPS</span>
           </div>
           <div className="flex items-center space-x-3">
              <div className="w-8 h-8 rounded-full bg-teal-600 flex items-center justify-center text-sm font-bold">
                  {currentUser.name.charAt(0)}
              </div>
           </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 md:ml-64 p-4 md:p-8 overflow-y-auto mt-14 md:mt-0 pb-24 md:pb-8">
        {children}
      </main>

      {/* Mobile Bottom Navigation (Fixed) */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-30 flex justify-around items-center pb-safe pt-2 px-2 shadow-[0_-2px_10px_rgba(0,0,0,0.05)]">
        {navItems.map((item) => {
            const active = isActive(item.path);
            return (
                <Link 
                    key={item.path}
                    to={item.path} 
                    className={`flex flex-col items-center justify-center w-full py-2 ${active ? 'text-teal-600' : 'text-gray-400'}`}
                >
                    <item.icon size={24} strokeWidth={active ? 2.5 : 2} />
                    <span className="text-[10px] mt-1 font-medium">{item.label}</span>
                </Link>
            )
        })}
        {/* Menu More / Logout for Mobile */}
        <button 
            onClick={handleLogout}
            className="flex flex-col items-center justify-center w-full py-2 text-gray-400"
        >
             <LogOut size={24} />
             <span className="text-[10px] mt-1 font-medium">Thoát</span>
        </button>
      </nav>
    </div>
  );
};