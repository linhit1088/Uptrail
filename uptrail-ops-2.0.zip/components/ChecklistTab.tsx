
import React, { useState } from 'react';
import { Plus, Trash2, CheckSquare, Square, Box, ClipboardList, Edit2, Save, X } from 'lucide-react';
import { useAppStore } from '../services/store';
import { ChecklistItem } from '../types';

interface ChecklistTabProps {
  tourId: string;
}

export const ChecklistTab: React.FC<ChecklistTabProps> = ({ tourId }) => {
  const { checklists, addChecklistItem, updateChecklistItem, deleteChecklistItem } = useAppStore();
  const tourChecklist = checklists.filter(c => c.tourInstanceId === tourId);

  // Edit State
  const [editingItem, setEditingItem] = useState<ChecklistItem | null>(null);

  // Form State
  const [formData, setFormData] = useState<Partial<ChecklistItem>>({
    quantity: 1,
    isPrepared: false,
    isReturned: false,
    name: '',
    note: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name) return;

    if (editingItem) {
        updateChecklistItem({
            ...editingItem,
            ...formData
        } as ChecklistItem);
        setEditingItem(null);
    } else {
        addChecklistItem({
            ...formData,
            id: Math.random().toString(36).substr(2, 9),
            tourInstanceId: tourId,
        } as ChecklistItem);
    }

    setFormData({
        quantity: 1,
        isPrepared: false,
        isReturned: false,
        name: '',
        note: ''
    });
  };

  const startEdit = (item: ChecklistItem) => {
      setEditingItem(item);
      setFormData(item);
  };

  const cancelEdit = () => {
      setEditingItem(null);
      setFormData({
        quantity: 1,
        isPrepared: false,
        isReturned: false,
        name: '',
        note: ''
      });
  };

  const toggleStatus = (item: ChecklistItem, field: 'isPrepared' | 'isReturned') => {
    updateChecklistItem({
        ...item,
        [field]: !item[field]
    });
  };

  return (
    <div className="p-4 md:p-6">
        <div className="mb-6 bg-blue-50 border border-blue-100 p-4 rounded-lg flex items-start space-x-3">
            <ClipboardList className="text-blue-600 mt-1" size={20} />
            <div>
                <h4 className="font-bold text-blue-800">Checklist Vận Hành</h4>
                <p className="text-sm text-blue-600">Danh sách vật dụng cần chuẩn bị cho tour.</p>
            </div>
        </div>

      {/* Add/Edit Form */}
      <div className={`bg-gray-50 p-4 rounded-lg border mb-8 transition-colors ${editingItem ? 'border-teal-500 ring-1 ring-teal-500' : 'border-gray-200'}`}>
        <h4 className="font-bold text-gray-700 mb-3 text-sm uppercase flex justify-between items-center">
            {editingItem ? 'Chỉnh sửa vật dụng' : 'Thêm dụng cụ / vật dụng'}
            {editingItem && <button onClick={cancelEdit}><X size={16}/></button>}
        </h4>
        <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-12 gap-3 items-end">
          <div className="md:col-span-6">
            <label className="block text-xs text-gray-500 mb-1">Tên vật dụng</label>
            <input 
                type="text" 
                className="w-full border rounded p-2 text-sm outline-none focus:border-teal-500"
                required
                placeholder="VD: Đèn pin, Lều 4..."
                value={formData.name || ''}
                onChange={e => setFormData({...formData, name: e.target.value})}
            />
          </div>
          <div className="md:col-span-2">
             <label className="block text-xs text-gray-500 mb-1">SL</label>
             <input 
                type="number" 
                className="w-full border rounded p-2 text-sm outline-none focus:border-teal-500"
                min="1"
                value={formData.quantity}
                onChange={e => setFormData({...formData, quantity: parseInt(e.target.value)})}
             />
          </div>
          <div className="md:col-span-3">
             <label className="block text-xs text-gray-500 mb-1">Ghi chú</label>
             <input 
                type="text" 
                className="w-full border rounded p-2 text-sm outline-none focus:border-teal-500"
                value={formData.note || ''}
                onChange={e => setFormData({...formData, note: e.target.value})}
             />
          </div>
          <div className="md:col-span-1">
             <button type="submit" className={`w-full text-white p-2 rounded text-sm font-medium transition-colors h-[38px] flex items-center justify-center ${editingItem ? 'bg-teal-600 hover:bg-teal-700' : 'bg-blue-600 hover:bg-blue-700'}`}>
                {editingItem ? <Save size={18} /> : <Plus size={18} />}
             </button>
          </div>
        </form>
      </div>

      {/* Checklist Table */}
      <div className="border border-gray-200 rounded-lg overflow-hidden bg-white">
        <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
                <thead className="bg-gray-100 text-gray-600 font-semibold border-b border-gray-200">
                    <tr>
                        <th className="px-6 py-3 font-medium min-w-[150px]">Tên vật dụng</th>
                        <th className="px-4 py-3 font-medium text-center">Số lượng</th>
                        <th className="px-4 py-3 font-medium text-center">Đã lấy kho</th>
                        <th className="px-4 py-3 font-medium text-center">Đã trả về</th>
                        <th className="px-6 py-3 font-medium min-w-[150px]">Ghi chú</th>
                        <th className="px-4 py-3 text-center min-w-[100px]">Action</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                    {tourChecklist.map(item => (
                        <tr key={item.id} className="hover:bg-gray-50">
                            <td className="px-6 py-3 font-medium text-gray-800">{item.name}</td>
                            <td className="px-4 py-3 text-center font-mono text-gray-700">{item.quantity}</td>
                            <td className="px-4 py-3 text-center">
                                <button 
                                    onClick={() => toggleStatus(item, 'isPrepared')}
                                    className={`transition-colors p-1 rounded hover:bg-gray-100 ${item.isPrepared ? 'text-green-600' : 'text-gray-300'}`}
                                    title="Đánh dấu đã chuẩn bị"
                                >
                                    {item.isPrepared ? <CheckSquare size={22} /> : <Square size={22} />}
                                </button>
                            </td>
                            <td className="px-4 py-3 text-center">
                                <button 
                                    onClick={() => toggleStatus(item, 'isReturned')}
                                    className={`transition-colors p-1 rounded hover:bg-gray-100 ${item.isReturned ? 'text-purple-600' : 'text-gray-300'}`}
                                    title="Đánh dấu đã trả"
                                >
                                    {item.isReturned ? <CheckSquare size={22} /> : <Square size={22} />}
                                </button>
                            </td>
                            <td className="px-6 py-3 text-gray-500 italic">{item.note}</td>
                            <td className="px-4 py-3 text-center">
                                <div className="flex justify-center space-x-2">
                                    <button onClick={() => startEdit(item)} className="text-blue-400 hover:text-blue-600 p-1">
                                        <Edit2 size={16} />
                                    </button>
                                    <button onClick={() => deleteChecklistItem(item.id)} className="text-red-300 hover:text-red-600 p-1">
                                        <Trash2 size={16} />
                                    </button>
                                </div>
                            </td>
                        </tr>
                    ))}
                    
                    {tourChecklist.length === 0 && (
                        <tr>
                            <td colSpan={6} className="text-center py-10 text-gray-400">
                                Chưa có vật dụng nào trong checklist.
                            </td>
                        </tr>
                    )}
                </tbody>
            </table>
        </div>
      </div>
    </div>
  );
};
