
import React, { useState } from 'react';
import { Plus, Trash2, ArrowUpCircle, ArrowDownCircle, Download, Edit2, X, Save } from 'lucide-react';
import { useAppStore } from '../services/store';
import { ExpenseItem, formatCurrency } from '../types';

interface FinanceTabProps {
  tourId: string;
}

export const FinanceTab: React.FC<FinanceTabProps> = ({ tourId }) => {
  const { expenses, bookings, addExpense, deleteExpense, updateExpense, tours } = useAppStore();
  
  // State for Mobile Modal (Add/Edit)
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState<Partial<ExpenseItem> | null>(null);

  // Calculate Financials (CHỈ TÍNH KHÁCH ACTIVE)
  const tourBookings = bookings.filter(b => b.tourInstanceId === tourId && b.status === 'ACTIVE');
  
  // 1. Tổng giá trị Tour (Doanh thu dự kiến trên giấy tờ)
  const totalTourValue = tourBookings.reduce((sum, b) => sum + b.price, 0); 
  
  // 2. Tổng thực thu (Tiền đã về quỹ: bao gồm Cọc + Thanh toán thêm)
  // Lưu ý: Trong logic hiện tại, field 'deposit' đại diện cho số tiền khách đã đóng.
  const totalCollected = tourBookings.reduce((sum, b) => sum + b.deposit, 0); 

  // Calculate Expenses
  const tourExpenses = expenses.filter(e => e.tourInstanceId === tourId && e.type === 'CHI');
  const totalCost = tourExpenses.reduce((sum, e) => sum + (e.quantity * e.unitPrice), 0);
  
  // Lợi nhuận thực tế (Tiền túi) = Thực thu - Tổng chi
  const cashFlow = totalCollected - totalCost;
  
  // Lợi nhuận dự kiến = Tổng giá trị - Tổng chi
  const projectedProfit = totalTourValue - totalCost;

  const currentTour = tours.find(t => t.id === tourId);

  // --- FORM STATE ---
  const initialFormState: Partial<ExpenseItem> = {
      type: 'CHI',
      category: 'Ăn uống',
      quantity: 1,
      unitPrice: 0,
      paymentMethod: 'Tiền mặt',
      name: '',
      note: ''
  };

  // State cho Desktop Form (Inline)
  const [desktopForm, setDesktopForm] = useState<Partial<ExpenseItem>>(initialFormState);
  
  // State cho Mobile Form (Modal)
  const [mobileForm, setMobileForm] = useState<Partial<ExpenseItem>>(initialFormState);

  // --- HANDLERS ---

  // Desktop: Inline Add
  const handleDesktopAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if(!desktopForm.name) return;

    addExpense({
      ...desktopForm,
      id: Math.random().toString(36).substr(2, 9),
      tourInstanceId: tourId,
    } as ExpenseItem);

    setDesktopForm(initialFormState);
  };

  // Mobile/Modal: Add or Edit
  const handleModalSave = (e: React.FormEvent) => {
    e.preventDefault();
    if(!mobileForm.name) return;

    if (editingExpense && editingExpense.id) {
        // Edit Logic: Use updateExpense directly for better logging
        updateExpense({
            ...editingExpense,
            ...mobileForm,
            tourInstanceId: tourId
        } as ExpenseItem);
    } else {
        // Add New Logic
        addExpense({
            ...mobileForm,
            id: Math.random().toString(36).substr(2, 9),
            tourInstanceId: tourId,
        } as ExpenseItem);
    }
    
    setIsModalOpen(false);
  };

  const openMobileAdd = () => {
      setEditingExpense(null);
      setMobileForm(initialFormState);
      setIsModalOpen(true);
  };

  const openMobileEdit = (expense: ExpenseItem) => {
      setEditingExpense(expense);
      setMobileForm(expense);
      setIsModalOpen(true);
  };

  const openDesktopEdit = (expense: ExpenseItem) => {
      // Desktop also uses the modal for editing to keep the inline form strictly for "Quick Add"
      setEditingExpense(expense);
      setMobileForm(expense);
      setIsModalOpen(true);
  };

  const handleExportFinanceReport = () => {
    const summaryRows = [
        ["BAO CAO TAI CHINH TOUR"],
        [`Tour: ${currentTour?.name || ''}`],
        [`Ma Tour: ${currentTour?.code || ''}`],
        [],
        ["TONG QUAN"],
        ["Tong gia tri Tour (Doanh thu)", totalTourValue],
        ["Thuc thu (Tien mat/CK)", totalCollected],
        ["Tong chi phi", totalCost],
        ["Loi nhuan du kien", projectedProfit],
        ["Dong tien thuc te (Cashflow)", cashFlow],
        []
    ];

    const revenueRows = tourBookings.map(b => [
        `"${b.customerName}"`,
        `"${b.phone}"`,
        b.price,
        b.deposit,
        `"${b.note || ''}"`
    ]);

    const expenseRows = tourExpenses.map(e => [
        `"${e.category}"`,
        `"${e.name}"`,
        e.quantity,
        e.unitPrice,
        e.quantity * e.unitPrice,
        `"${e.paymentMethod}"`
    ]);

    const allRows = [
        ...summaryRows,
        ["CHI TIET THU (BOOKING)", "", "", "", ""],
        ["Khach hang", "SĐT", "Gia Tour", "Da Thanh Toan", "Ghi chu"],
        ...revenueRows,
        [],
        ["CHI TIET CHI PHI", "", "", "", "", ""],
        ["Phan loai", "Khoan muc", "So luong", "Don gia", "Thanh tien", "Hinh thuc"],
        ...expenseRows
    ];

    const csvContent = "\uFEFF" + allRows.map(e => e.join(",")).join("\n");
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `Tai_Chinh_${currentTour?.code || 'Tour'}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="p-4 md:p-6 pb-20 md:pb-6 relative">
      <div className="flex justify-between items-center mb-6">
          <h3 className="font-bold text-gray-800 text-lg">Quản lý Thu/Chi</h3>
          <button 
            onClick={handleExportFinanceReport}
            className="flex items-center space-x-2 bg-gray-100 hover:bg-gray-200 text-gray-700 px-3 py-2 rounded-lg text-sm font-medium transition-colors"
          >
              <Download size={16} />
              <span className="hidden md:inline">Xuất Báo cáo</span>
          </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-6 mb-8">
        <div className="bg-green-50 p-4 rounded-xl border border-green-100 col-span-2 md:col-span-1">
          <div className="text-green-600 font-bold text-xs uppercase mb-1 flex items-center">
            <ArrowUpCircle size={14} className="mr-1" /> Tổng Giá Tour
          </div>
          <div className="text-xl md:text-2xl font-bold text-green-700">{formatCurrency(totalTourValue)}</div>
          <div className="text-[10px] text-green-500 mt-1">Doanh thu dự kiến</div>
        </div>

        <div className="bg-teal-50 p-4 rounded-xl border border-teal-100 col-span-2 md:col-span-1">
          <div className="text-teal-600 font-bold text-xs uppercase mb-1 flex items-center">
            <ArrowUpCircle size={14} className="mr-1" /> Thực Thu
          </div>
          <div className="text-xl md:text-2xl font-bold text-teal-700">{formatCurrency(totalCollected)}</div>
          <div className="text-[10px] text-teal-500 mt-1">Tiền đã về quỹ</div>
        </div>

        <div className="bg-red-50 p-4 rounded-xl border border-red-100">
          <div className="text-red-600 font-bold text-xs uppercase mb-1 flex items-center">
             <ArrowDownCircle size={14} className="mr-1" /> Tổng Chi
          </div>
          <div className="text-xl md:text-2xl font-bold text-red-700">{formatCurrency(totalCost)}</div>
        </div>

        <div className="bg-blue-50 p-4 rounded-xl border border-blue-100">
          <div className="text-blue-600 font-bold text-xs uppercase mb-1">Lợi nhuận (Dự kiến)</div>
          <div className="text-xl md:text-2xl font-bold text-blue-700">{formatCurrency(projectedProfit)}</div>
          <div className="text-[10px] text-blue-500 mt-1">Cashflow: {formatCurrency(cashFlow)}</div>
        </div>
      </div>

      {/* DESKTOP: INLINE FORM (Restored "Old" Style) */}
      <div className="hidden md:block bg-white p-4 rounded-lg border border-gray-200 mb-6 shadow-sm">
        <form onSubmit={handleDesktopAdd} className="space-y-3">
            <div className="grid grid-cols-12 gap-4 items-end">
                <div className="col-span-1">
                    <label className="block text-xs text-gray-500 mb-1">Loại</label>
                    <select 
                        className="w-full border rounded p-2 text-sm bg-gray-50 outline-none focus:border-teal-500"
                        value={desktopForm.type}
                        onChange={e => setDesktopForm({...desktopForm, type: e.target.value as any})}
                    >
                        <option value="CHI">CHI</option>
                        <option value="THU">THU</option>
                    </select>
                </div>
                <div className="col-span-2">
                    <label className="block text-xs text-gray-500 mb-1">Nhóm</label>
                    <select 
                        className="w-full border rounded p-2 text-sm outline-none focus:border-teal-500"
                        value={desktopForm.category}
                        onChange={e => setDesktopForm({...desktopForm, category: e.target.value as any})}
                    >
                        <option value="Ăn uống">Ăn uống</option>
                        <option value="Di chuyển">Di chuyển</option>
                        <option value="Local">Local/Porter</option>
                        <option value="Vé/Ngủ">Vé/Ngủ</option>
                        <option value="Khác">Khác</option>
                    </select>
                </div>
                <div className="col-span-4">
                    <label className="block text-xs text-gray-500 mb-1">Khoản mục</label>
                    <input 
                        type="text" 
                        placeholder="VD: Homestay / Xe / Porter..."
                        className="w-full border rounded p-2 text-sm outline-none focus:border-teal-500"
                        required
                        value={desktopForm.name || ''}
                        onChange={e => setDesktopForm({...desktopForm, name: e.target.value})}
                    />
                </div>
                <div className="col-span-1">
                    <label className="block text-xs text-gray-500 mb-1">SL</label>
                    <input 
                        type="number" 
                        className="w-full border rounded p-2 text-sm outline-none focus:border-teal-500"
                        min="1"
                        value={desktopForm.quantity}
                        onChange={e => setDesktopForm({...desktopForm, quantity: parseInt(e.target.value)})}
                    />
                </div>
                <div className="col-span-2">
                    <label className="block text-xs text-gray-500 mb-1">Đơn giá</label>
                    <input 
                        type="number" 
                        className="w-full border rounded p-2 text-sm outline-none focus:border-teal-500"
                        value={desktopForm.unitPrice}
                        onChange={e => setDesktopForm({...desktopForm, unitPrice: parseInt(e.target.value)})}
                    />
                </div>
                <div className="col-span-2">
                    <button type="submit" className="w-full bg-teal-600 text-white p-2 rounded hover:bg-teal-700 text-sm font-bold transition-colors h-[38px]">
                        + Thêm
                    </button>
                </div>
            </div>
            
            <div className="grid grid-cols-12 gap-4">
                <div className="col-span-3">
                    <label className="block text-xs text-gray-500 mb-1">Hình thức</label>
                    <select 
                        className="w-full border rounded p-2 text-sm outline-none focus:border-teal-500"
                        value={desktopForm.paymentMethod}
                        onChange={e => setDesktopForm({...desktopForm, paymentMethod: e.target.value as any})}
                    >
                        <option value="Tiền mặt">Tiền mặt</option>
                        <option value="Chuyển khoản">Chuyển khoản</option>
                    </select>
                </div>
                <div className="col-span-9">
                    <label className="block text-xs text-gray-500 mb-1">Ghi chú</label>
                    <input 
                        type="text" 
                        placeholder="Tuỳ chọn"
                        className="w-full border rounded p-2 text-sm outline-none focus:border-teal-500"
                        value={desktopForm.note || ''}
                        onChange={e => setDesktopForm({...desktopForm, note: e.target.value})}
                    />
                </div>
            </div>
        </form>
      </div>

      {/* Expense List */}
      <div>
        <h4 className="font-bold text-gray-700 mb-3 flex items-center justify-between">
            <span>Chi tiết chi phí ({tourExpenses.length})</span>
        </h4>
        
        {/* MOBILE VIEW: Cards (One-handed friendly) */}
        <div className="md:hidden space-y-3 pb-24">
            {tourExpenses.map(e => (
                <div key={e.id} onClick={() => openMobileEdit(e)} className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm flex justify-between items-center active:bg-gray-50">
                    <div>
                        <div className="text-xs font-bold text-gray-500 uppercase mb-1">{e.category}</div>
                        <div className="font-bold text-gray-800">{e.name}</div>
                        <div className="text-sm text-gray-500 mt-1">
                            {e.quantity} x {formatCurrency(e.unitPrice)}
                        </div>
                    </div>
                    <div className="text-right">
                        <div className="font-bold text-red-600 text-lg">{formatCurrency(e.quantity * e.unitPrice)}</div>
                        <div className="text-xs text-gray-400 bg-gray-100 px-2 py-0.5 rounded inline-block mt-1">{e.paymentMethod}</div>
                    </div>
                </div>
            ))}
            {tourExpenses.length === 0 && <div className="text-center py-8 text-gray-400">Chưa có chi phí nào</div>}
        </div>

        {/* DESKTOP VIEW: Table */}
        <div className="hidden md:block overflow-x-auto border border-gray-200 rounded-lg bg-white">
          <table className="w-full text-sm text-left">
             <thead className="bg-gray-100 text-gray-600 font-semibold">
                <tr>
                    <th className="p-3">Nhóm</th>
                    <th className="p-3">Khoản mục</th>
                    <th className="p-3 text-right">SL</th>
                    <th className="p-3 text-right">Đơn giá</th>
                    <th className="p-3 text-right">Thành tiền</th>
                    <th className="p-3">Hình thức</th>
                    <th className="p-3">Ghi chú</th>
                    <th className="p-3 text-center w-24">Hành động</th>
                </tr>
             </thead>
             <tbody className="divide-y divide-gray-100">
                {tourExpenses.map(e => (
                    <tr key={e.id} className="hover:bg-gray-50 cursor-pointer" onClick={() => openDesktopEdit(e)}>
                        <td className="p-3">
                            <span className="px-2 py-1 bg-gray-200 rounded text-xs text-gray-700">{e.category}</span>
                        </td>
                        <td className="p-3 font-medium text-gray-800">{e.name}</td>
                        <td className="p-3 text-right text-gray-600">{e.quantity}</td>
                        <td className="p-3 text-right text-gray-600">{formatCurrency(e.unitPrice)}</td>
                        <td className="p-3 text-right font-medium text-gray-800">{formatCurrency(e.quantity * e.unitPrice)}</td>
                        <td className="p-3 text-gray-500 text-xs">{e.paymentMethod}</td>
                        <td className="p-3 text-gray-500 text-xs italic max-w-xs truncate">{e.note}</td>
                        <td className="p-3 text-center">
                            <button onClick={(ev) => {ev.stopPropagation(); deleteExpense(e.id);}} className="text-red-400 hover:text-red-600 p-1">
                                <Trash2 size={16} />
                            </button>
                        </td>
                    </tr>
                ))}
                {tourExpenses.length === 0 && (
                    <tr>
                        <td colSpan={8} className="p-8 text-center text-gray-400">Chưa có chi phí nào</td>
                    </tr>
                )}
             </tbody>
          </table>
        </div>
      </div>

      {/* MOBILE ONLY: FAB Add Button */}
      <button 
        onClick={openMobileAdd}
        className="md:hidden fixed bottom-20 right-4 w-14 h-14 bg-teal-600 text-white rounded-full shadow-lg flex items-center justify-center z-40 active:bg-teal-700 active:scale-95 transition-all"
      >
        <Plus size={28} />
      </button>

      {/* Modal (Used for Mobile Add/Edit AND Desktop Edit) */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-white md:bg-black md:bg-opacity-50 z-[70] flex items-end md:items-center justify-center md:p-4">
             <div className="bg-white w-full h-full md:h-auto md:max-w-lg md:rounded-xl shadow-xl flex flex-col">
                <div className="p-4 border-b border-gray-100 flex justify-between items-center bg-gray-50 md:rounded-t-xl shrink-0">
                    <h2 className="text-lg font-bold text-gray-800">{editingExpense ? 'Sửa chi phí' : 'Thêm chi phí mới'}</h2>
                    <button onClick={() => setIsModalOpen(false)} className="p-2 bg-gray-200 rounded-full text-gray-600"><X size={20}/></button>
                </div>
                
                <form onSubmit={handleModalSave} className="flex-1 overflow-y-auto p-4 space-y-4">
                     <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Loại chi phí</label>
                        <select 
                            className="w-full border rounded-lg p-3 text-sm bg-white outline-none focus:ring-2 focus:ring-teal-500"
                            value={mobileForm.category}
                            onChange={e => setMobileForm({...mobileForm, category: e.target.value as any})}
                        >
                            <option value="Ăn uống">Ăn uống</option>
                            <option value="Di chuyển">Di chuyển</option>
                            <option value="Local">Local/Porter</option>
                            <option value="Vé/Ngủ">Vé/Ngủ</option>
                            <option value="Khác">Khác</option>
                        </select>
                     </div>

                     <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Tên khoản mục</label>
                        <input 
                            type="text" 
                            className="w-full border rounded-lg p-3 text-sm outline-none focus:ring-2 focus:ring-teal-500"
                            placeholder="VD: Ăn tối..."
                            required
                            value={mobileForm.name}
                            onChange={e => setMobileForm({...mobileForm, name: e.target.value})}
                        />
                     </div>

                     <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Số lượng</label>
                            <input 
                                type="number" 
                                className="w-full border rounded-lg p-3 text-sm outline-none focus:ring-2 focus:ring-teal-500"
                                min="1"
                                value={mobileForm.quantity}
                                onChange={e => setMobileForm({...mobileForm, quantity: parseInt(e.target.value)})}
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Đơn giá</label>
                            <input 
                                type="number" 
                                className="w-full border rounded-lg p-3 text-sm outline-none focus:ring-2 focus:ring-teal-500"
                                value={mobileForm.unitPrice}
                                onChange={e => setMobileForm({...mobileForm, unitPrice: parseInt(e.target.value)})}
                            />
                        </div>
                     </div>

                     <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Hình thức thanh toán</label>
                        <div className="flex gap-4">
                             <label className="flex items-center">
                                 <input 
                                    type="radio" 
                                    name="paymentMethod" 
                                    value="Tiền mặt" 
                                    checked={mobileForm.paymentMethod === 'Tiền mặt'}
                                    onChange={() => setMobileForm({...mobileForm, paymentMethod: 'Tiền mặt'})}
                                    className="mr-2"
                                /> Tiền mặt
                             </label>
                             <label className="flex items-center">
                                 <input 
                                    type="radio" 
                                    name="paymentMethod" 
                                    value="Chuyển khoản" 
                                    checked={mobileForm.paymentMethod === 'Chuyển khoản'}
                                    onChange={() => setMobileForm({...mobileForm, paymentMethod: 'Chuyển khoản'})}
                                    className="mr-2"
                                /> Chuyển khoản
                             </label>
                        </div>
                     </div>

                     <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Ghi chú</label>
                        <input 
                            type="text" 
                            className="w-full border rounded-lg p-3 text-sm outline-none focus:ring-2 focus:ring-teal-500"
                            value={mobileForm.note || ''}
                            onChange={e => setMobileForm({...mobileForm, note: e.target.value})}
                        />
                     </div>

                     <div className="mt-8 pt-4">
                         <button type="submit" className="w-full bg-teal-600 text-white py-3 rounded-lg font-bold shadow-lg flex items-center justify-center">
                             <Save size={20} className="mr-2"/> Lưu chi phí
                         </button>
                         {editingExpense && (
                             <button 
                                type="button" 
                                onClick={() => {
                                    if(window.confirm('Xóa khoản này?')) {
                                        deleteExpense(editingExpense.id!);
                                        setIsModalOpen(false);
                                    }
                                }}
                                className="w-full mt-3 text-red-600 py-3 rounded-lg font-bold hover:bg-red-50"
                             >
                                 Xóa khoản này
                             </button>
                         )}
                     </div>
                </form>
             </div>
        </div>
      )}
    </div>
  );
};
