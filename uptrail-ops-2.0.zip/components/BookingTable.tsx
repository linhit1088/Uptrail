
import React, { useState } from 'react';
import { 
  Plus, 
  Search, 
  Download, 
  Edit2, 
  Trash2, 
  Check,
  AlertTriangle,
  X,
  Phone,
  MessageCircle,
  Banknote,
  User as UserIcon,
  MapPin,
  Save,
  Archive,
  RefreshCw,
  History,
  StickyNote,
  Calendar
} from 'lucide-react';
import { useAppStore } from '../services/store';
import { Booking, formatCurrency, calculateAge, UserRole, formatNumberInput, TourStatus, BookingHistoryLog } from '../types';

interface BookingTableProps {
  tourId: string;
}

export const BookingTable: React.FC<BookingTableProps> = ({ tourId }) => {
  const { bookings, users, currentUser, deleteBooking, updateBooking, tours } = useAppStore();
  
  // State quản lý Modal thêm/sửa
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingBooking, setEditingBooking] = useState<Booking | null>(null);
  
  // State quản lý Modal Chuyển Tour
  const [transferBooking, setTransferBooking] = useState<Booking | null>(null);
  const [targetTourId, setTargetTourId] = useState('');

  // State quản lý Modal xác nhận xóa & Bảo lưu
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [reserveId, setReserveId] = useState<string | null>(null);

  const [searchTerm, setSearchTerm] = useState('');

  const currentTour = tours.find(t => t.id === tourId);

  // Lọc chỉ hiển thị khách trong tour này và đang ACTIVE
  const tourBookings = bookings.filter(b => b.tourInstanceId === tourId && (!b.status || b.status === 'ACTIVE'));
  const filteredBookings = tourBookings.filter(b => 
    b.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    b.phone.includes(searchTerm)
  );

  // Danh sách các tour available để chuyển (Open/Running và không phải tour hiện tại)
  const availableTours = tours.filter(t => 
      t.id !== tourId && 
      (t.status === TourStatus.OPEN || t.status === TourStatus.RUNNING) &&
      !t.isHidden
  );

  const handleEdit = (booking: Booking) => {
    setEditingBooking(booking);
    setIsModalOpen(true);
  };

  const handleAdd = () => {
    setEditingBooking(null);
    setIsModalOpen(true);
  };

  const confirmDelete = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setDeleteId(id);
  };

  const handleDeleteAction = () => {
    if (deleteId) {
      deleteBooking(deleteId);
      setDeleteId(null);
    }
  };

  // Logic Bảo lưu: Mở modal xác nhận
  const openReserveModal = (e: React.MouseEvent, id: string) => {
      e.stopPropagation();
      setReserveId(id);
  };

  // Thực hiện bảo lưu
  const handleReserveAction = () => {
      if (!reserveId) return;
      const booking = bookings.find(b => b.id === reserveId);
      if (booking) {
          // Log history
          const log: BookingHistoryLog = {
              id: Math.random().toString(36).substr(2, 9),
              timestamp: new Date().toISOString(),
              action: 'RESERVE',
              detail: `Chuyển sang danh sách bảo lưu từ tour ${currentTour?.code}`,
              performerName: currentUser?.name || 'Unknown'
          };
          
          updateBooking({
              ...booking,
              status: 'RESERVED',
              historyLogs: [...(booking.historyLogs || []), log]
          });
      }
      setReserveId(null);
  };

  // Logic Mở Modal Chuyển Tour
  const openTransferModal = (e: React.MouseEvent, booking: Booking) => {
      e.stopPropagation();
      setTransferBooking(booking);
      setTargetTourId('');
  };

  // Logic Thực hiện Chuyển Tour
  const handleTransferAction = () => {
      if (!transferBooking || !targetTourId) return;
      
      const targetTour = tours.find(t => t.id === targetTourId);

      // Log history
      const log: BookingHistoryLog = {
          id: Math.random().toString(36).substr(2, 9),
          timestamp: new Date().toISOString(),
          action: 'TRANSFER',
          detail: `Chuyển từ tour ${currentTour?.code} sang tour ${targetTour?.code}`,
          performerName: currentUser?.name || 'Unknown'
      };

      updateBooking({
          ...transferBooking,
          tourInstanceId: targetTourId,
          status: 'ACTIVE',
          historyLogs: [...(transferBooking.historyLogs || []), log]
      });
      setTransferBooking(null);
      setTargetTourId('');
  };

  const handleExportExcel = () => {
      // Cập nhật header thêm CCCD
      const headers = ["Tên khách", "SĐT", "CCCD", "Ngày sinh", "Tuổi", "Điểm đón", "Giá chốt", "Đã cọc", "Còn thiếu", "Sale", "Ghi chú"];
      const rows = filteredBookings.map(b => {
        const sale = users.find(u => u.id === b.saleId);
        return [
          `"${b.customerName}"`,
          `"${b.phone}"`,
          `"${b.cccd || ''}"`, // Thêm dữ liệu CCCD vào hàng
          b.birthDate,
          calculateAge(b.birthDate),
          `"${b.pickupPoint || ''}"`,
          b.price,
          b.deposit,
          b.price - b.deposit,
          `"${sale?.name || ''}"`,
          `"${b.note || ''}"`
        ];
      });

      const csvContent = "\uFEFF" + [
        headers.join(","),
        ...rows.map(r => r.join(","))
      ].join("\n");

      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.setAttribute("href", url);
      link.setAttribute("download", `danh_sach_khach_${tourId}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
  };

  const handleCall = (e: React.MouseEvent, phone: string) => {
      e.stopPropagation();
      window.location.href = `tel:${phone}`;
  };

  return (
    <div className="p-4 md:p-6 pb-20 md:pb-6 relative">
      {/* Header Actions */}
      <div className="flex flex-col md:flex-row justify-between items-center mb-4 gap-3">
        <div className="flex w-full md:w-auto gap-2">
            <div className="relative flex-1 md:w-64">
                <Search className="absolute left-3 top-2.5 text-gray-400" size={18} />
                <input 
                    type="text" 
                    placeholder="Tìm tên, SĐT..." 
                    className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>
            <button 
                type="button"
                onClick={handleExportExcel}
                className="md:hidden flex-none flex items-center justify-center w-10 h-10 border border-gray-300 rounded-lg text-gray-700 hover:bg-green-50 hover:text-green-700 bg-white shadow-sm"
                title="Xuất Excel"
            >
                <Download size={20} />
            </button>
        </div>

        <div className="hidden md:flex space-x-2">
            <button 
              type="button"
              onClick={handleExportExcel}
              className="flex items-center space-x-2 px-3 py-2 border border-gray-300 rounded-lg text-gray-700 text-sm hover:bg-green-50 hover:text-green-700"
            >
                <Download size={16} />
                <span>Xuất Excel</span>
            </button>
            <button 
                type="button"
                onClick={handleAdd}
                className="flex items-center space-x-2 px-4 py-2 bg-teal-600 text-white rounded-lg text-sm hover:bg-teal-700 shadow-sm"
            >
                <Plus size={16} />
                <span>Thêm khách</span>
            </button>
        </div>
      </div>

      {/* DESKTOP TABLE VIEW */}
      <div className="hidden md:block overflow-x-auto border border-gray-200 rounded-lg bg-white">
        <table className="w-full text-sm text-left">
          <thead className="bg-gray-50 text-gray-700 font-semibold uppercase text-xs sticky top-0 z-10">
            <tr>
              <th className="px-4 py-3 border-b w-10">#</th>
              <th className="px-4 py-3 border-b">Họ Tên</th>
              <th className="px-4 py-3 border-b">Ngày sinh / Tuổi</th>
              <th className="px-4 py-3 border-b">SĐT</th>
              <th className="px-4 py-3 border-b">Điểm đón</th>
              <th className="px-4 py-3 border-b text-right">Giá chốt</th>
              <th className="px-4 py-3 border-b text-right">Cọc</th>
              <th className="px-4 py-3 border-b text-right">Còn thiếu</th>
              <th className="px-4 py-3 border-b w-48">Ghi chú</th>
              <th className="px-4 py-3 border-b text-center w-40">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {filteredBookings.map((b, index) => {
               const remaining = b.price - b.deposit;
               const age = calculateAge(b.birthDate);
               const sale = users.find(u => u.id === b.saleId);
               
               return (
                <tr key={b.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3 text-gray-500">{index + 1}</td>
                  <td className="px-4 py-3 font-medium text-gray-900">
                    <div>{b.customerName}</div>
                    {b.nickname && <div className="text-xs text-gray-400 italic">"{b.nickname}"</div>}
                    <div className="text-[10px] text-gray-400 md:hidden">Sale: {sale?.name || '-'}</div>
                  </td>
                  <td className="px-4 py-3 text-gray-600">
                      {b.birthDate ? (
                          <div className="flex flex-col">
                              <span>{new Date(b.birthDate).toLocaleDateString('vi-VN')}</span>
                              <span className="text-xs text-gray-400">{age} tuổi</span>
                          </div>
                      ) : '-'}
                  </td>
                  {/* UPDATE: SĐT Đổi màu nổi bật */}
                  <td className="px-4 py-3 text-blue-700 font-bold font-mono">{b.phone}</td>
                  <td className="px-4 py-3 text-gray-600">{b.pickupPoint || '-'}</td>
                  <td className="px-4 py-3 text-right">{formatCurrency(b.price)}</td>
                  <td className="px-4 py-3 text-right text-teal-600">{formatCurrency(b.deposit)}</td>
                  <td className="px-4 py-3 text-right">
                    {remaining <= 0 ? (
                        <span className="text-green-600 font-bold text-xs"><Check size={12}/> Đủ</span>
                    ) : (
                        <span className="font-bold text-red-600">{formatCurrency(remaining)}</span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-gray-500 text-xs italic max-w-xs truncate" title={b.note}>
                      {b.note || '-'}
                  </td>
                  <td className="px-4 py-3 text-center">
                      <div className="flex justify-center space-x-1">
                          <button type="button" onClick={(e) => openTransferModal(e, b)} className="text-indigo-600 hover:bg-indigo-50 p-1.5 rounded" title="Đổi tour">
                              <RefreshCw size={16}/>
                          </button>
                          <button type="button" onClick={(e) => openReserveModal(e, b.id)} className="text-orange-600 hover:bg-orange-50 p-1.5 rounded" title="Bảo lưu">
                              <Archive size={16}/>
                          </button>
                          <button type="button" onClick={() => handleEdit(b)} className="text-blue-600 hover:bg-blue-50 p-1.5 rounded" title="Sửa">
                              <Edit2 size={16}/>
                          </button>
                          <button type="button" onClick={(e) => confirmDelete(e, b.id)} className="text-red-600 hover:bg-red-50 p-1.5 rounded" title="Xóa">
                              <Trash2 size={16}/>
                          </button>
                      </div>
                  </td>
                </tr>
               )
            })}
          </tbody>
        </table>
      </div>

      {/* MOBILE CARD VIEW */}
      <div className="md:hidden space-y-3">
        {filteredBookings.map((b) => {
             const remaining = b.price - b.deposit;
             const isPaid = remaining <= 0;
             const age = calculateAge(b.birthDate);
             const sale = users.find(u => u.id === b.saleId);

             return (
                <div key={b.id} onClick={() => handleEdit(b)} className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 active:bg-gray-50 transition-colors relative">
                    <div className={`absolute top-4 right-4 text-xs font-bold px-2 py-1 rounded-full flex items-center ${isPaid ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                        {isPaid ? <><Check size={12} className="mr-1"/> Đủ</> : <>{formatCurrency(remaining)}</>}
                    </div>

                    <div className="pr-16">
                        <h3 className="text-lg font-bold text-gray-900 leading-tight">{b.customerName}</h3>
                        {b.nickname && <div className="text-sm text-gray-500 italic mb-1">"{b.nickname}"</div>}
                        
                        <div className="flex flex-col space-y-1 mt-2 text-sm text-gray-600">
                             <div className="flex items-center"><UserIcon size={14} className="mr-2 text-gray-400 w-4"/> {b.birthDate ? `${age} tuổi` : 'Chưa có NS'}</div>
                             <div className="flex items-center"><MapPin size={14} className="mr-2 text-gray-400 w-4"/> {b.pickupPoint || 'Chưa có điểm đón'}</div>
                             <div className="flex items-center"><UserIcon size={14} className="mr-2 text-gray-400 w-4"/> Sale: {sale ? sale.name.split(' ').pop() : '---'}</div>
                        </div>

                        {b.note && (
                             <div className="flex items-start mt-2 text-xs text-orange-600 bg-orange-50 p-1.5 rounded">
                                 <StickyNote size={12} className="mr-1 mt-0.5 flex-shrink-0"/>
                                 <span className="truncate">{b.note}</span>
                             </div>
                        )}

                        <div className="mt-3 flex items-center space-x-4 text-sm">
                             <div><span className="text-xs text-gray-400 uppercase block">Giá chốt</span><span className="font-medium">{formatCurrency(b.price)}</span></div>
                             <div><span className="text-xs text-gray-400 uppercase block">Đã cọc</span><span className="font-medium text-teal-600">{formatCurrency(b.deposit)}</span></div>
                        </div>
                    </div>
                    
                    <div className="mt-4 pt-3 border-t border-gray-50 flex justify-between items-center">
                         <div className="flex space-x-2">
                            <button type="button" onClick={(e) => handleCall(e, b.phone)} className="flex items-center px-2 py-1.5 bg-green-50 text-green-700 rounded-lg text-xs font-bold"><Phone size={14} className="mr-1"/> Gọi</button>
                            <a href={`https://zalo.me/${b.phone}`} target="_blank" rel="noreferrer" onClick={(e) => e.stopPropagation()} className="flex items-center px-2 py-1.5 bg-blue-50 text-blue-700 rounded-lg text-xs font-bold"><MessageCircle size={14} className="mr-1"/> Zalo</a>
                         </div>
                         <div className="flex space-x-2">
                             <button type="button" onClick={(e) => openTransferModal(e, b)} className="p-2 bg-indigo-50 text-indigo-600 rounded-lg"><RefreshCw size={14} /></button>
                             <button type="button" onClick={(e) => openReserveModal(e, b.id)} className="p-2 bg-orange-50 text-orange-600 rounded-lg"><Archive size={14} /></button>
                         </div>
                    </div>
                </div>
             )
        })}
        {filteredBookings.length === 0 && <div className="text-center py-10 text-gray-400">Chưa có khách nào. Bấm nút + để thêm.</div>}
      </div>

      <button onClick={handleAdd} className="md:hidden fixed bottom-20 right-4 w-14 h-14 bg-teal-600 text-white rounded-full shadow-lg flex items-center justify-center z-40 active:bg-teal-700 active:scale-95 transition-all">
        <Plus size={28} />
      </button>

      {/* Delete Modal */}
      {deleteId && (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-[60] flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-sm p-6 text-center animate-in zoom-in-95 duration-200">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <AlertTriangle className="text-red-600 w-8 h-8" />
              </div>
              <h3 className="text-lg font-bold text-gray-800 mb-2">Xóa khách này?</h3>
              <p className="text-gray-500 mb-6 text-sm">Hành động này không thể hoàn tác.</p>
              <div className="flex space-x-3">
                <button type="button" onClick={() => setDeleteId(null)} className="flex-1 py-3 bg-gray-100 text-gray-700 rounded-xl font-bold">Hủy</button>
                <button type="button" onClick={handleDeleteAction} className="flex-1 py-3 bg-red-600 text-white rounded-xl font-bold">Xóa</button>
              </div>
          </div>
        </div>
      )}

      {/* Reserve Modal */}
      {reserveId && (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-[60] flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-sm p-6 text-center animate-in zoom-in-95 duration-200">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Archive className="text-orange-600 w-8 h-8" />
              </div>
              <h3 className="text-lg font-bold text-gray-800 mb-2">Bảo lưu khách này?</h3>
              <p className="text-gray-500 mb-6 text-sm">Khách sẽ được chuyển sang danh sách Bảo lưu và ẩn khỏi tour hiện tại.</p>
              <div className="flex space-x-3">
                <button type="button" onClick={() => setReserveId(null)} className="flex-1 py-3 bg-gray-100 text-gray-700 rounded-xl font-bold">Hủy</button>
                <button type="button" onClick={handleReserveAction} className="flex-1 py-3 bg-orange-600 text-white rounded-xl font-bold">Bảo lưu</button>
              </div>
          </div>
        </div>
      )}

      {/* Transfer Tour Modal */}
      {transferBooking && (
          <div className="fixed inset-0 bg-black bg-opacity-60 z-[65] flex items-center justify-center p-4">
              <div className="bg-white rounded-xl shadow-2xl w-full max-w-md p-6 animate-in zoom-in-95 duration-200">
                  <div className="flex justify-between items-center mb-4">
                      <h3 className="text-lg font-bold text-gray-800">Đổi tour cho khách</h3>
                      <button type="button" onClick={() => setTransferBooking(null)} className="text-gray-400 hover:text-gray-600"><X size={20}/></button>
                  </div>
                  
                  <div className="mb-4">
                      <p className="text-sm text-gray-600 mb-1">Khách hàng:</p>
                      <div className="font-bold text-gray-800">{transferBooking.customerName}</div>
                  </div>

                  <div className="mb-6">
                      <label className="block text-sm font-medium text-gray-700 mb-2">Chọn tour muốn chuyển đến:</label>
                      {availableTours.length > 0 ? (
                          <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                              {availableTours.map(t => (
                                  <label key={t.id} className={`flex items-center justify-between p-3 border rounded-lg cursor-pointer transition-colors ${targetTourId === t.id ? 'border-indigo-500 bg-indigo-50' : 'border-gray-200 hover:bg-gray-50'}`}>
                                      <div className="flex items-center">
                                          <input 
                                              type="radio" 
                                              name="targetTour" 
                                              className="mr-3 text-indigo-600 focus:ring-indigo-500"
                                              checked={targetTourId === t.id}
                                              onChange={() => setTargetTourId(t.id)}
                                          />
                                          <div>
                                              <div className="font-medium text-gray-900 text-sm">{t.name}</div>
                                              <div className="text-xs text-gray-500 flex items-center mt-0.5">
                                                  <Calendar size={10} className="mr-1"/> 
                                                  {new Date(t.startDate).toLocaleDateString('vi-VN')}
                                                  <span className="mx-1">•</span>
                                                  {t.code}
                                              </div>
                                          </div>
                                      </div>
                                  </label>
                              ))}
                          </div>
                      ) : (
                          <div className="text-center p-4 bg-gray-50 rounded-lg text-gray-500 text-sm italic">
                              Không còn tour nào khác đang nhận khách.
                          </div>
                      )}
                  </div>

                  <div className="flex space-x-3">
                      <button type="button" onClick={() => setTransferBooking(null)} className="flex-1 py-2.5 bg-gray-100 text-gray-700 rounded-lg font-bold">Hủy</button>
                      <button 
                          type="button"
                          onClick={handleTransferAction} 
                          disabled={!targetTourId}
                          className={`flex-1 py-2.5 text-white rounded-lg font-bold flex items-center justify-center ${!targetTourId ? 'bg-gray-300 cursor-not-allowed' : 'bg-indigo-600 hover:bg-indigo-700 shadow-md'}`}
                      >
                          <RefreshCw size={18} className="mr-2"/> Xác nhận đổi
                      </button>
                  </div>
              </div>
          </div>
      )}

      {/* Add/Edit Modal (Responsive) */}
      {isModalOpen && (
        <BookingModal 
          isOpen={isModalOpen} 
          onClose={() => setIsModalOpen(false)} 
          booking={editingBooking}
          tourId={tourId}
        />
      )}
    </div>
  );
};

// Internal Modal Component Exported for Reuse
export const BookingModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  booking: Booking | null;
  tourId: string;
}> = ({ isOpen, onClose, booking, tourId }) => {
  const { addBooking, updateBooking, currentUser, users } = useAppStore();
  const [keepAdding, setKeepAdding] = useState(false);
  
  // Logic default SaleId
  const defaultSaleId = currentUser?.roles.includes(UserRole.SALE) 
      ? currentUser.id 
      : users.find(u => u.roles.includes(UserRole.SALE))?.id || '';

  // Form State
  const initialForm = {
      tourInstanceId: tourId,
      customerName: '',
      gender: 'Nam',
      birthDate: '', 
      phone: '',
      price: 0,
      deposit: 0,
      saleId: defaultSaleId,
      note: '',
      pickupPoint: '',
      cccd: '',
      nickname: '',
      status: 'ACTIVE',
      historyLogs: []
  };

  const [formData, setFormData] = useState<Partial<Booking>>(booking || initialForm as any);

  // Local state for Money Inputs to handle formatting
  const [priceInput, setPriceInput] = useState(formatNumberInput(formData.price));
  const [depositInput, setDepositInput] = useState(formatNumberInput(formData.deposit));

  const handlePriceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const rawValue = e.target.value.replace(/\./g, '');
      if (!isNaN(Number(rawValue))) {
          const numVal = parseInt(rawValue || '0', 10);
          setFormData({...formData, price: numVal});
          setPriceInput(new Intl.NumberFormat('vi-VN').format(numVal));
      }
  };

  const handleDepositChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const rawValue = e.target.value.replace(/\./g, '');
      if (!isNaN(Number(rawValue))) {
          const numVal = parseInt(rawValue || '0', 10);
          setFormData({...formData, deposit: numVal});
          setDepositInput(new Intl.NumberFormat('vi-VN').format(numVal));
      }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.customerName) return alert('Nhập tên khách');

    const newBooking = {
      ...formData,
      id: booking ? booking.id : Math.random().toString(36).substr(2, 9),
      status: formData.status || 'ACTIVE'
    } as Booking;

    if (booking) {
      updateBooking(newBooking);
      onClose();
    } else {
      addBooking(newBooking);
      if (keepAdding) {
          // Reset form but keep common fields
          setFormData({
              ...initialForm,
              price: formData.price, // Keep price same
              saleId: formData.saleId,
          } as any);
          setPriceInput(formatNumberInput(formData.price)); // Reset display input for price
          setDepositInput('0');
          // Focus back to name (simple way is allow React re-render)
          alert("Đã lưu! Nhập khách tiếp theo."); 
      } else {
          onClose();
      }
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-white md:bg-black md:bg-opacity-50 z-[70] flex items-end md:items-center justify-center md:p-4">
      <div className="bg-white w-full h-full md:h-auto md:max-w-2xl md:rounded-xl shadow-xl flex flex-col">
        {/* Modal Header */}
        <div className="p-4 border-b border-gray-100 flex justify-between items-center bg-gray-50 md:rounded-t-xl shrink-0">
          <h2 className="text-lg font-bold text-gray-800">{booking ? 'Sửa thông tin' : 'Thêm khách mới'}</h2>
          <button type="button" onClick={onClose} className="p-2 bg-gray-200 rounded-full text-gray-600 hover:bg-gray-300">
            <X size={20} />
          </button>
        </div>
        
        {/* Scrollable Form Content */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-4 md:p-6 space-y-5">
          {/* Section 1: Định danh */}
          <div className="space-y-4">
            <div>
                <label className="text-xs font-bold uppercase text-gray-500 block mb-1">Họ và tên *</label>
                <input 
                    type="text" 
                    required
                    className="w-full text-lg font-semibold border-b-2 border-gray-300 py-2 focus:border-teal-600 outline-none rounded-none bg-transparent"
                    placeholder="Nguyễn Văn A"
                    value={formData.customerName}
                    onChange={e => setFormData({...formData, customerName: e.target.value})}
                />
            </div>

            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="text-xs font-bold uppercase text-gray-500 block mb-1">Số điện thoại</label>
                    <input 
                        type="tel" 
                        inputMode="tel"
                        className="w-full text-lg border-b-2 border-gray-300 py-2 focus:border-teal-600 outline-none rounded-none bg-transparent"
                        placeholder="09..."
                        value={formData.phone}
                        onChange={e => setFormData({...formData, phone: e.target.value})}
                    />
                </div>
                <div>
                     <label className="text-xs font-bold uppercase text-gray-500 block mb-1">CCCD</label>
                     <input 
                        type="text" 
                        className="w-full text-lg border-b-2 border-gray-300 py-2 focus:border-teal-600 outline-none rounded-none bg-transparent"
                        placeholder="0010..."
                        value={formData.cccd || ''}
                        onChange={e => setFormData({...formData, cccd: e.target.value})}
                    />
                </div>
            </div>
          </div>

          {/* Section 2: Tài chính (Quan trọng nhất) */}
          <div className="bg-gray-50 p-4 rounded-xl border border-gray-200 grid grid-cols-2 gap-4">
                <div className="col-span-2 flex items-center mb-1 text-teal-800 font-bold text-sm">
                    <Banknote size={16} className="mr-2"/> Tài chính
                </div>
                <div>
                    <label className="text-xs text-gray-500 block mb-1">Giá chốt</label>
                    <input 
                        type="text" 
                        inputMode="numeric"
                        className="w-full border rounded-lg px-3 py-3 text-gray-800 font-medium focus:ring-2 focus:ring-teal-500 outline-none bg-white"
                        placeholder="0"
                        value={priceInput}
                        onChange={handlePriceChange}
                    />
                </div>
                <div className="relative">
                    <label className="text-xs text-gray-500 block mb-1">Đã cọc</label>
                    <input 
                        type="text" 
                        inputMode="numeric"
                        className="w-full border rounded-lg px-3 py-3 text-teal-700 font-bold focus:ring-2 focus:ring-teal-500 outline-none bg-white"
                        placeholder="0"
                        value={depositInput}
                        onChange={handleDepositChange}
                    />
                    {/* Nút Auto Fill: Thanh toán hết */}
                    {(formData.price || 0) > (formData.deposit || 0) && (
                        <button 
                            type="button"
                            onClick={() => {
                                setFormData(prev => ({...prev, deposit: prev.price}));
                                setDepositInput(formatNumberInput(formData.price));
                            }}
                            className="absolute right-0 top-0 text-[10px] text-blue-600 hover:text-blue-800 font-bold uppercase py-1 px-1 bg-blue-50 rounded"
                            title="Tự động điền số tiền bằng giá chốt"
                        >
                            Thanh toán hết
                        </button>
                    )}
                </div>
                <div className="col-span-2">
                     <div className="flex justify-between items-center text-sm p-2 bg-white rounded border border-gray-200">
                        <span className="text-gray-500">Còn thiếu:</span>
                        <span className={`font-bold text-lg ${(formData.price || 0) - (formData.deposit || 0) > 0 ? 'text-red-600' : 'text-green-600'}`}>
                            {formatCurrency((formData.price || 0) - (formData.deposit || 0))}
                        </span>
                     </div>
                </div>
                <div className="col-span-2">
                     <label className="text-xs text-gray-500 block mb-1">Sale phụ trách</label>
                     <select
                        className="w-full border rounded-lg px-3 py-2 text-sm outline-none bg-white"
                        value={formData.saleId}
                        onChange={e => setFormData({...formData, saleId: e.target.value})}
                     >
                         {users.filter(u => u.roles.includes(UserRole.SALE) || u.roles.includes(UserRole.ADMIN)).map(u => (
                             <option key={u.id} value={u.id}>{u.name}</option>
                         ))}
                     </select>
                </div>
          </div>

          {/* Section 3: Thông tin phụ */}
          <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="text-xs font-bold uppercase text-gray-500 block mb-1">Ngày sinh</label>
                    <div className="flex items-center space-x-2">
                        <input 
                            type="date" 
                            className="w-full border rounded-lg px-3 py-2 text-sm outline-none focus:border-teal-500"
                            value={formData.birthDate || ''}
                            onChange={e => setFormData({...formData, birthDate: e.target.value})}
                        />
                    </div>
                    {formData.birthDate && (
                         <div className="text-xs text-teal-600 mt-1 font-medium text-right">
                             {calculateAge(formData.birthDate)} tuổi
                         </div>
                    )}
                </div>
                <div>
                    <label className="text-xs font-bold uppercase text-gray-500 block mb-1">Giới tính</label>
                    <select 
                        className="w-full border rounded-lg px-3 py-2 text-sm outline-none bg-white"
                        value={formData.gender}
                        onChange={e => setFormData({...formData, gender: e.target.value as any})}
                    >
                        <option value="Nam">Nam</option>
                        <option value="Nữ">Nữ</option>
                        <option value="Khác">Khác</option>
                    </select>
                </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
                <div>
                   <label className="text-xs font-bold uppercase text-gray-500 block mb-1">Điểm đón</label>
                   <input 
                       type="text" 
                       className="w-full border rounded-lg px-3 py-2 outline-none focus:border-teal-500"
                       placeholder="ĐH Quốc Gia..."
                       value={formData.pickupPoint || ''}
                       onChange={e => setFormData({...formData, pickupPoint: e.target.value})}
                   />
               </div>
               <div>
                     <label className="text-xs font-bold uppercase text-gray-500 block mb-1">Huy hiệu/Nick</label>
                     <input 
                        type="text" 
                        className="w-full border rounded-lg px-3 py-2 outline-none focus:border-teal-500"
                        placeholder="Iron man"
                        value={formData.nickname || ''}
                        onChange={e => setFormData({...formData, nickname: e.target.value})}
                    />
                </div>
           </div>
           
           <div>
               <label className="text-xs font-bold uppercase text-gray-500 block mb-1">Ghi chú (Ăn chay/Dị ứng)</label>
               <textarea 
                   rows={2}
                   className="w-full border rounded-lg px-3 py-2 outline-none focus:border-teal-500"
                   value={formData.note || ''}
                   onChange={e => setFormData({...formData, note: e.target.value})}
               />
           </div>

           {/* History Logs View */}
           {formData.historyLogs && formData.historyLogs.length > 0 && (
                <div className="mt-4 pt-4 border-t border-gray-100">
                    <h4 className="text-xs font-bold uppercase text-gray-500 mb-2 flex items-center">
                        <History size={14} className="mr-1"/> Lịch sử thay đổi
                    </h4>
                    <div className="space-y-2 max-h-32 overflow-y-auto bg-gray-50 p-2 rounded text-xs">
                        {formData.historyLogs.map(log => (
                            <div key={log.id} className="flex flex-col border-b border-gray-100 pb-1 last:border-0 last:pb-0">
                                <div className="flex justify-between text-gray-400">
                                    <span>{new Date(log.timestamp).toLocaleString('vi-VN')}</span>
                                    <span className="font-medium">{log.performerName}</span>
                                </div>
                                <div className="text-gray-700 font-medium">
                                    <span className={`px-1 rounded text-[10px] mr-1 ${
                                        log.action === 'TRANSFER' ? 'bg-indigo-100 text-indigo-700' : 
                                        log.action === 'RESERVE' ? 'bg-orange-100 text-orange-700' : 'bg-gray-200'
                                    }`}>
                                        {log.action}
                                    </span>
                                    {log.detail}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
           )}

           {/* Mobile Only: Save & Next Option */}
           {!booking && (
               <div className="flex items-center space-x-2 pt-2">
                   <input 
                        type="checkbox" 
                        id="keepAdding" 
                        className="w-5 h-5 rounded text-teal-600 focus:ring-teal-500"
                        checked={keepAdding}
                        onChange={e => setKeepAdding(e.target.checked)}
                   />
                   <label htmlFor="keepAdding" className="text-sm font-medium text-gray-700">Lưu xong nhập tiếp người nữa</label>
               </div>
           )}

           {/* Spacer for bottom bar on mobile */}
           <div className="h-20 md:hidden"></div>
        </form>

        {/* Footer Actions */}
        <div className="p-4 border-t border-gray-100 bg-white md:rounded-b-xl flex space-x-3 shrink-0 fixed bottom-0 left-0 right-0 md:static z-[80]">
            <button type="button" onClick={onClose} className="flex-1 py-3 bg-gray-100 text-gray-700 font-bold rounded-xl md:rounded-lg">Hủy</button>
            <button 
                type="button" 
                onClick={handleSubmit} 
                className="flex-[2] py-3 bg-teal-600 text-white font-bold rounded-xl md:rounded-lg shadow-lg flex items-center justify-center"
            >
                <Save size={20} className="mr-2"/> {booking ? 'Lưu thay đổi' : 'Lưu khách hàng'}
            </button>
        </div>
      </div>
    </div>
  );
};
