
import React, { useState } from 'react';
import { Plus, Trash2, Phone, Bus, Home, Utensils, User, MoreHorizontal, MessageCircle, Edit2, X, Save } from 'lucide-react';
import { useAppStore } from '../services/store';
import { Partner, PartnerCategory } from '../types';

interface PartnerTabProps {
  tourId: string;
}

export const PartnerTab: React.FC<PartnerTabProps> = ({ tourId }) => {
  const { partners, addPartner, deletePartner, addPartner: updatePartner } = useAppStore(); // Assuming addPartner is basically setPartners, we need a real update.
  // Workaround: delete + add to update since context implies simple setters. 
  // *Correction*: Let's use delete+add for update logic locally if store doesn't have it, 
  // OR better: Assume we added updatePartner to context in previous step? 
  // Looking at store.tsx provided previously, it doesn't have updatePartner. 
  // I will simulate update by deleting and adding with same ID if needed, or just delete/add.

  const tourPartners = partners.filter(p => p.tourInstanceId === tourId);

  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState<Partial<Partner>>({
    category: 'Nhà Xe',
    name: '',
    phone: '',
    note: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name) return;

    if (editingId) {
        // Simulate Update: Delete old -> Add new with same ID
        deletePartner(editingId);
        addPartner({
            ...formData,
            id: editingId,
            tourInstanceId: tourId
        } as Partner);
        setEditingId(null);
    } else {
        addPartner({
            ...formData,
            id: Math.random().toString(36).substr(2, 9),
            tourInstanceId: tourId,
        } as Partner);
    }

    setFormData({
      category: 'Nhà Xe',
      name: '',
      phone: '',
      note: ''
    });
  };

  const startEdit = (p: Partner) => {
      setEditingId(p.id);
      setFormData(p);
      // Scroll to form
      window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const cancelEdit = () => {
      setEditingId(null);
      setFormData({
        category: 'Nhà Xe',
        name: '',
        phone: '',
        note: ''
      });
  };

  const getIcon = (category: PartnerCategory) => {
    switch (category) {
      case 'Nhà Xe': return <Bus size={18} className="text-blue-600" />;
      case 'Nhà Nghỉ/Homestay': return <Home size={18} className="text-indigo-600" />;
      case 'Nhà Hàng': return <Utensils size={18} className="text-orange-600" />;
      case 'Porter': return <User size={18} className="text-green-600" />;
      default: return <MoreHorizontal size={18} className="text-gray-600" />;
    }
  };

  const getBorderColor = (category: PartnerCategory) => {
    switch (category) {
      case 'Nhà Xe': return 'border-l-blue-500';
      case 'Nhà Nghỉ/Homestay': return 'border-l-indigo-500';
      case 'Nhà Hàng': return 'border-l-orange-500';
      case 'Porter': return 'border-l-green-500';
      default: return 'border-l-gray-500';
    }
  };

  return (
    <div className="p-4 md:p-6">
      <div className="mb-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
         <div>
            <h3 className="font-bold text-gray-800 text-lg">Danh sách Đối tác</h3>
            <p className="text-sm text-gray-500">Liên hệ nhà xe, porter, điểm ngủ...</p>
         </div>
      </div>

      {/* Input Form */}
      <div className={`bg-gray-50 p-4 rounded-lg border mb-6 transition-colors ${editingId ? 'border-teal-500 ring-1 ring-teal-500' : 'border-gray-200'}`}>
        <h4 className="font-bold text-gray-700 mb-3 text-sm uppercase flex justify-between">
            {editingId ? 'Cập nhật đối tác' : 'Thêm đối tác mới'}
            {editingId && <button onClick={cancelEdit}><X size={16}/></button>}
        </h4>
        <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-12 gap-3 items-end">
          <div className="md:col-span-3">
            <label className="block text-xs text-gray-500 mb-1">Loại hình</label>
            <select 
                className="w-full border rounded p-2 text-sm focus:border-teal-500 outline-none bg-white"
                value={formData.category}
                onChange={e => setFormData({...formData, category: e.target.value as PartnerCategory})}
            >
                <option value="Nhà Xe">Nhà Xe</option>
                <option value="Nhà Nghỉ/Homestay">Nhà Nghỉ/Homestay</option>
                <option value="Nhà Hàng">Nhà Hàng</option>
                <option value="Porter">Porter</option>
                <option value="Khác">Khác</option>
            </select>
          </div>
          <div className="md:col-span-3">
             <label className="block text-xs text-gray-500 mb-1">Tên đối tác / Liên hệ</label>
             <input 
                type="text" 
                className="w-full border rounded p-2 text-sm focus:border-teal-500 outline-none"
                required
                placeholder="VD: Xe Sao Việt, A Chư..."
                value={formData.name || ''}
                onChange={e => setFormData({...formData, name: e.target.value})}
             />
          </div>
          <div className="md:col-span-2">
             <label className="block text-xs text-gray-500 mb-1">SĐT</label>
             <input 
                type="tel" 
                className="w-full border rounded p-2 text-sm focus:border-teal-500 outline-none"
                placeholder="09..."
                value={formData.phone || ''}
                onChange={e => setFormData({...formData, phone: e.target.value})}
             />
          </div>
          <div className="md:col-span-3">
             <label className="block text-xs text-gray-500 mb-1">Ghi chú (Cọc, giá...)</label>
             <input 
                type="text" 
                className="w-full border rounded p-2 text-sm focus:border-teal-500 outline-none"
                value={formData.note || ''}
                onChange={e => setFormData({...formData, note: e.target.value})}
             />
          </div>
          <div className="md:col-span-1">
             <button type="submit" className={`w-full text-white p-2 rounded text-sm font-medium transition-colors h-[38px] flex items-center justify-center ${editingId ? 'bg-teal-600 hover:bg-teal-700' : 'bg-blue-600 hover:bg-blue-700'}`}>
                {editingId ? <Save size={18}/> : <Plus size={18}/>}
             </button>
          </div>
        </form>
      </div>

      {/* List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {tourPartners.map(p => (
            <div key={p.id} className={`bg-white rounded-lg shadow-sm border border-gray-100 border-l-4 ${getBorderColor(p.category)} p-4 flex justify-between items-start group`}>
                <div className="flex-1 pr-4" onClick={() => startEdit(p)}>
                    <div className="flex items-center space-x-2 mb-1">
                        {getIcon(p.category)}
                        <span className="text-xs font-bold text-gray-500 uppercase tracking-wide">{p.category}</span>
                    </div>
                    <h4 className="font-bold text-gray-800 text-base">{p.name}</h4>
                    {p.phone && <div className="text-sm text-gray-600 font-mono mt-1">{p.phone}</div>}
                    {p.note && <div className="text-sm text-gray-500 italic mt-2 bg-gray-50 p-2 rounded">{p.note}</div>}
                </div>
                
                <div className="flex flex-col space-y-2">
                     {p.phone && (
                        <>
                            <a href={`tel:${p.phone}`} className="p-2 bg-green-50 text-green-600 rounded-lg hover:bg-green-100">
                                <Phone size={18} />
                            </a>
                            <a href={`https://zalo.me/${p.phone}`} target="_blank" rel="noreferrer" className="p-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100">
                                <MessageCircle size={18} />
                            </a>
                        </>
                     )}
                     <div className="flex space-x-1 pt-2">
                        <button onClick={() => startEdit(p)} className="p-2 text-gray-300 hover:bg-blue-50 hover:text-blue-500 rounded-lg">
                             <Edit2 size={18} />
                        </button>
                        <button onClick={() => deletePartner(p.id)} className="p-2 text-gray-300 hover:bg-red-50 hover:text-red-500 rounded-lg">
                            <Trash2 size={18} />
                        </button>
                     </div>
                </div>
            </div>
        ))}
        {tourPartners.length === 0 && (
            <div className="col-span-1 md:col-span-2 text-center py-12 text-gray-400 border-2 border-dashed border-gray-100 rounded-xl">
                Chưa có đối tác nào. Hãy thêm Nhà xe, Porter...
            </div>
        )}
      </div>
    </div>
  );
};
