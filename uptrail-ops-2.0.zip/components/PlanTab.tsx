
import React, { useState } from 'react';
import { Plus, Trash2, CalendarClock, Clock, MapPin, Edit2, X, Save } from 'lucide-react';
import { useAppStore } from '../services/store';
import { PlanItem } from '../types';

interface PlanTabProps {
  tourId: string;
}

export const PlanTab: React.FC<PlanTabProps> = ({ tourId }) => {
  const { plans, addPlan, deletePlan } = useAppStore();
  const tourPlans = plans
    .filter(p => p.tourInstanceId === tourId)
    .sort((a, b) => {
        if (a.day !== b.day) return a.day - b.day;
        return a.time.localeCompare(b.time);
    });

  // Edit State
  const [editingId, setEditingId] = useState<string | null>(null);

  // Group plans by Day
  const groupedPlans = tourPlans.reduce((groups, plan) => {
    const day = plan.day;
    if (!groups[day]) groups[day] = [];
    groups[day].push(plan);
    return groups;
  }, {} as Record<number, PlanItem[]>);

  // Form State
  const [formData, setFormData] = useState<Partial<PlanItem>>({
    day: 1,
    time: '07:00',
    content: '',
    note: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.content) return;

    if (editingId) {
        // Simulate update
        deletePlan(editingId);
        addPlan({
            ...formData,
            id: editingId,
            tourInstanceId: tourId,
        } as PlanItem);
        setEditingId(null);
    } else {
        addPlan({
            ...formData,
            id: Math.random().toString(36).substr(2, 9),
            tourInstanceId: tourId,
        } as PlanItem);
    }

    setFormData({
      ...formData,
      content: '', // Keep day/time for faster entry
      note: ''
    });
  };

  const startEdit = (plan: PlanItem) => {
      setEditingId(plan.id);
      setFormData(plan);
      window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const cancelEdit = () => {
      setEditingId(null);
      setFormData({
        day: 1,
        time: '07:00',
        content: '',
        note: ''
      });
  };

  return (
    <div className="p-4 md:p-6">
       <div className="mb-6 bg-indigo-50 border border-indigo-100 p-4 rounded-lg flex items-start space-x-3">
            <CalendarClock className="text-indigo-600 mt-1" size={20} />
            <div>
                <h4 className="font-bold text-indigo-800">Kế hoạch tổ chức</h4>
                <p className="text-sm text-indigo-600">Timeline chi tiết các hoạt động trong chuyến đi.</p>
            </div>
        </div>

      {/* Input Form */}
      <div className={`bg-gray-50 p-4 rounded-lg border mb-8 sticky top-0 z-10 shadow-sm transition-colors ${editingId ? 'border-indigo-500 ring-1 ring-indigo-500' : 'border-gray-200'}`}>
        <h4 className="font-bold text-gray-700 mb-3 text-sm uppercase flex justify-between">
            {editingId ? 'Chỉnh sửa hoạt động' : 'Thêm hoạt động'}
            {editingId && <button onClick={cancelEdit}><X size={16}/></button>}
        </h4>
        <form onSubmit={handleSubmit} className="grid grid-cols-2 md:grid-cols-12 gap-3 items-end">
          <div className="col-span-1 md:col-span-2">
             <label className="block text-xs text-gray-500 mb-1">Ngày</label>
             <select 
                className="w-full border rounded p-2 text-sm focus:border-indigo-500 outline-none bg-white"
                value={formData.day}
                onChange={e => setFormData({...formData, day: parseInt(e.target.value)})}
             >
                {[1, 2, 3, 4, 5].map(d => <option key={d} value={d}>Ngày {d}</option>)}
             </select>
          </div>
          <div className="col-span-1 md:col-span-2">
             <label className="block text-xs text-gray-500 mb-1">Giờ</label>
             <input 
                type="time" 
                className="w-full border rounded p-2 text-sm focus:border-indigo-500 outline-none"
                value={formData.time}
                onChange={e => setFormData({...formData, time: e.target.value})}
             />
          </div>
          <div className="col-span-2 md:col-span-5">
             <label className="block text-xs text-gray-500 mb-1">Nội dung hoạt động</label>
             <input 
                type="text" 
                className="w-full border rounded p-2 text-sm focus:border-indigo-500 outline-none"
                required
                placeholder="VD: Tập trung tại điểm hẹn..."
                value={formData.content || ''}
                onChange={e => setFormData({...formData, content: e.target.value})}
             />
          </div>
          <div className="col-span-2 md:col-span-3">
             <label className="block text-xs text-gray-500 mb-1">Lưu ý</label>
             <div className="flex space-x-2">
                <input 
                    type="text" 
                    className="w-full border rounded p-2 text-sm focus:border-indigo-500 outline-none"
                    placeholder="Note..."
                    value={formData.note || ''}
                    onChange={e => setFormData({...formData, note: e.target.value})}
                />
                <button type="submit" className={`text-white p-2 rounded transition-colors w-10 flex items-center justify-center ${editingId ? 'bg-teal-600 hover:bg-teal-700' : 'bg-indigo-600 hover:bg-indigo-700'}`}>
                    {editingId ? <Save size={20} /> : <Plus size={20}/>}
                </button>
             </div>
          </div>
        </form>
      </div>

      {/* Timeline View */}
      <div className="space-y-8">
        {Object.keys(groupedPlans).map(day => (
            <div key={day} className="relative">
                <div className="sticky top-0 bg-white z-0 py-2 mb-2 border-b border-gray-100">
                    <h3 className="text-lg font-bold text-indigo-700 uppercase">Ngày {day}</h3>
                </div>
                
                <div className="ml-4 border-l-2 border-indigo-100 space-y-6 pb-4">
                    {groupedPlans[parseInt(day)].map(plan => (
                        <div key={plan.id} className="relative pl-6 group">
                            {/* Dot */}
                            <div className="absolute -left-[9px] top-1.5 w-4 h-4 rounded-full bg-white border-4 border-indigo-400 group-hover:border-indigo-600 transition-colors"></div>
                            
                            <div 
                                className="flex justify-between items-start group-hover:bg-gray-50 p-2 rounded-lg -ml-2 -mt-2 transition-colors cursor-pointer"
                                onClick={() => startEdit(plan)}
                            >
                                <div className="flex-1">
                                    <div className="flex items-center text-sm font-bold text-gray-800 mb-1">
                                        <Clock size={14} className="mr-1 text-gray-400"/>
                                        {plan.time}
                                    </div>
                                    <div className="text-gray-900 font-medium">
                                        {plan.content}
                                    </div>
                                    {plan.note && (
                                        <div className="text-sm text-red-500 italic mt-1 flex items-start">
                                            <span className="mr-1">*</span> {plan.note}
                                        </div>
                                    )}
                                </div>
                                <div className="flex space-x-1 opacity-100 md:opacity-0 group-hover:opacity-100 transition-opacity">
                                    <button 
                                        onClick={(e) => {e.stopPropagation(); startEdit(plan);}}
                                        className="text-gray-300 hover:text-blue-500 p-1"
                                    >
                                        <Edit2 size={16} />
                                    </button>
                                    <button 
                                        onClick={(e) => {e.stopPropagation(); deletePlan(plan.id);}}
                                        className="text-gray-300 hover:text-red-500 p-1"
                                    >
                                        <Trash2 size={16} />
                                    </button>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        ))}
        
        {tourPlans.length === 0 && (
            <div className="text-center py-10 text-gray-400">
                Chưa có kế hoạch nào.
            </div>
        )}
      </div>
    </div>
  );
};
